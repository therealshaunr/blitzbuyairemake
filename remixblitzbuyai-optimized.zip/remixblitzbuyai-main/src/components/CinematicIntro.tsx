import { useEffect, useState } from "react";
import { Sparkles, Camera, Zap, Users, ArrowRight } from "lucide-react";

// localStorage = show intro once EVER (not every new tab like sessionStorage did)
const STORAGE_KEY = "blitzbuyai_intro_seen";

const CinematicIntro = ({ onDone }: { onDone: () => void }) => {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      const t = setTimeout(() => finish(), 500);
      return () => clearTimeout(t);
    }
    // Shortened from 10s to 6s total — snappy, still cinematic
    const timers = [
      setTimeout(() => setPhase(1), 1200),
      setTimeout(() => setPhase(2), 2400),
      setTimeout(() => setPhase(3), 4400),
      setTimeout(() => setPhase(4), 5600),
      setTimeout(() => finish(), 6200),
    ];
    return () => timers.forEach(clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const finish = () => {
    localStorage.setItem(STORAGE_KEY, "1");
    onDone();
  };

  return (
    <div
      className={`fixed inset-0 z-[100] grid place-items-center overflow-hidden bg-background transition-opacity duration-700 ${
        phase >= 4 ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
      role="dialog"
      aria-label="BlitzBuy.AI intro"
    >
      <div className="absolute inset-0 grid-bg opacity-60" />
      <div className="absolute -top-40 left-1/2 -translate-x-1/2 h-[600px] w-[800px] rounded-full bg-primary/30 blur-[140px] animate-glow-pulse" />
      <div className="absolute -bottom-40 right-0 h-[500px] w-[500px] rounded-full bg-accent/25 blur-[140px] animate-glow-pulse" style={{ animationDelay: "1s" }} />

      <button onClick={finish} className="absolute top-5 right-5 sm:top-8 sm:right-8 z-10 px-4 py-2 rounded-xl glass text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
        Skip intro
      </button>

      <div className="relative z-10 text-center px-6 max-w-3xl">
        <div className={`flex flex-col items-center transition-all duration-1000 ${phase >= 1 ? "scale-90 -translate-y-4 opacity-70" : "scale-100 opacity-100"}`}>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-primary blur-3xl opacity-60 animate-pulse" />
            <div className="relative h-24 w-24 sm:h-32 sm:w-32 rounded-3xl bg-gradient-primary grid place-items-center shadow-glow animate-fade-up">
              <Sparkles className="h-12 w-12 sm:h-16 sm:w-16 text-primary-foreground" />
            </div>
          </div>
          <h1 className="mt-6 font-display font-bold text-4xl sm:text-6xl tracking-tight animate-fade-up" style={{ animationDelay: "0.4s" }}>
            Blitz<span className="text-gradient-brand">Buy.AI</span>
          </h1>
        </div>

        {phase >= 1 && phase < 3 && (
          <p className="mt-4 sm:mt-6 font-display text-lg sm:text-2xl text-muted-foreground animate-fade-up">
            Deals that <span className="text-gradient-brand font-bold">hit fast.</span>
          </p>
        )}

        {phase >= 2 && phase < 3 && (
          <div className="mt-8 sm:mt-12 grid grid-cols-3 gap-3 sm:gap-6">
            {[
              { icon: Camera, label: "Snap", desc: "AI Listings" },
              { icon: Zap, label: "Blitz", desc: "Fast Auctions" },
              { icon: Users, label: "Meet", desc: "Local Pickups" },
            ].map((v, i) => (
              <div key={v.label} className="glass rounded-2xl p-4 sm:p-6 animate-fade-up" style={{ animationDelay: `${i * 0.15}s` }}>
                <div className="h-10 w-10 sm:h-12 sm:w-12 mx-auto rounded-xl bg-gradient-primary grid place-items-center mb-2 sm:mb-3 shadow-glow">
                  <v.icon className="h-5 w-5 sm:h-6 sm:w-6 text-primary-foreground" />
                </div>
                <div className="font-display font-bold text-base sm:text-xl">{v.label}</div>
                <div className="text-[10px] sm:text-xs text-muted-foreground">{v.desc}</div>
              </div>
            ))}
          </div>
        )}

        {phase >= 3 && (
          <div className="mt-8 animate-fade-up">
            <p className="font-display text-2xl sm:text-4xl font-bold mb-6">
              Welcome to <span className="text-gradient-brand">the blitz</span>.
            </p>
            <button onClick={finish} className="inline-flex items-center gap-2 rounded-2xl bg-gradient-primary px-6 sm:px-8 py-3 sm:py-4 font-display font-semibold text-primary-foreground shadow-glow hover:scale-105 active:scale-95 transition-transform text-base sm:text-lg">
              Enter the marketplace
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export const shouldShowIntro = () => {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(STORAGE_KEY) !== "1";
};

export default CinematicIntro;
