import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";

const AdminLegal = () => {
  const [docs, setDocs] = useState<any[]>([]);
  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("legal_agreements").select("*").order("doc_type", { ascending: true }).order("effective_at", { ascending: false });
      setDocs(data ?? []);
    })();
  }, []);
  return (
    <AdminLayout title="Legal Documents">
      <div className="space-y-3">
        {docs.map((d) => (
          <div key={d.id} className="glass rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="outline">{d.doc_type}</Badge>
              <Badge>v{d.version}</Badge>
              {d.is_current && <Badge className="bg-success/20 text-success border-success/40">current</Badge>}
              <span className="text-xs text-muted-foreground ml-auto">Effective {new Date(d.effective_at).toLocaleDateString()}</span>
            </div>
            <div className="font-display font-semibold">{d.title}</div>
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{d.body.slice(0, 300)}…</p>
          </div>
        ))}
      </div>
      <p className="text-xs text-muted-foreground mt-6">Publishing a new version requires a database migration. Reach out to engineering to draft one.</p>
    </AdminLayout>
  );
};

export default AdminLegal;
