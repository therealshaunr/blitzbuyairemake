import { Link } from "react-router-dom";
import { Sparkles, Camera, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const CTASell = () => {
  return (
    <section className="py-16 sm:py-24 relative">
      <div className="container">
        <div className="relative glass-strong rounded-2xl sm:rounded-3xl p-7 sm:p-12 lg:p-16 overflow-hidden shadow-elevated">
          <div className="absolute -top-32 -right-32 h-72 w-72 sm:h-96 sm:w-96 rounded-full bg-primary/30 blur-[100px] pointer-events-none" />
          <div className="absolute -bottom-32 -left-32 h-72 w-72 sm:h-96 sm:w-96 rounded-full bg-accent/20 blur-[100px] pointer-events-none" />

          <div className="relative max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-primary/15 border border-primary/30 rounded-full px-3 py-1 mb-5 sm:mb-6">
              <Sparkles className="h-3.5 w-3.5 text-primary-glow" />
              <span className="text-xs font-medium text-primary-glow">Powered by AI</span>
            </div>
            <h2 className="font-display text-3xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-5 sm:mb-6">
              Got something to sell?
              <br />
              <span className="text-gradient-brand">Let AI list it for you.</span>
            </h2>
            <p className="text-base sm:text-lg text-muted-foreground mb-7 sm:mb-8">
              Skip the typing, the photo editing, the price research. Just point your camera. We handle the rest — auction, buy now, or local — your call.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Link to="/sell" className="w-full sm:w-auto">
                <Button size="lg" className="rounded-xl bg-gradient-primary hover:opacity-90 shadow-glow h-12 px-6 font-medium w-full">
                  <Camera className="h-4 w-4" />
                  List your first item
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/auth" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="rounded-xl glass h-12 px-6 font-medium w-full">
                  Create free account
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASell;
