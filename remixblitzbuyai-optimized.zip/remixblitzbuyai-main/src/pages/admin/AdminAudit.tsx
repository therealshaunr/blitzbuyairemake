import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";

const AdminAudit = () => {
  const [items, setItems] = useState<any[]>([]);
  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("audit_log").select("*").order("created_at", { ascending: false }).limit(200);
      setItems(data ?? []);
    })();
  }, []);
  return (
    <AdminLayout title="Audit Log">
      <div className="glass rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-card/60 text-xs uppercase text-muted-foreground">
              <tr><th className="text-left p-3">Time</th><th className="text-left p-3">Actor</th><th className="text-left p-3">Action</th><th className="text-left p-3">Target</th><th className="text-left p-3">Details</th></tr>
            </thead>
            <tbody>
              {items.map((a) => (
                <tr key={a.id} className="border-t border-border">
                  <td className="p-3 text-xs whitespace-nowrap">{new Date(a.created_at).toLocaleString()}</td>
                  <td className="p-3 text-xs">{a.actor_id?.slice(0, 8) ?? "—"}</td>
                  <td className="p-3"><Badge variant="outline">{a.action}</Badge></td>
                  <td className="p-3 text-xs">{a.target_type}: {a.target_id?.slice(0, 8) ?? "—"}</td>
                  <td className="p-3 text-xs text-muted-foreground"><pre className="whitespace-pre-wrap font-mono text-[11px]">{a.details ? JSON.stringify(a.details) : "—"}</pre></td>
                </tr>
              ))}
              {items.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">No activity.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminAudit;
