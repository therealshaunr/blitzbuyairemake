import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Sparkles } from "lucide-react";

const AcceptInvite = () => {
  const [params] = useSearchParams();
  const token = params.get("token");
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [inv, setInv] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!token) return;
    (async () => {
      const { data } = await supabase.from("admin_invitations").select("*").eq("token", token).maybeSingle();
      setInv(data);
    })();
  }, [token]);

  const accept = async () => {
    if (!user || !inv) return;
    setBusy(true);
    try {
      if (inv.accepted_at) { toast({ title: "Already accepted", variant: "destructive" }); return; }
      if (new Date(inv.expires_at) < new Date()) { toast({ title: "Invitation expired", variant: "destructive" }); return; }
      if (user.email?.toLowerCase() !== inv.email.toLowerCase()) {
        toast({ title: "Wrong account", description: `Sign in as ${inv.email}`, variant: "destructive" });
        return;
      }
      const { error: e1 } = await supabase.from("user_roles").insert({ user_id: user.id, role: inv.role, granted_by: inv.invited_by });
      if (e1) throw e1;
      await supabase.from("admin_invitations").update({ accepted_at: new Date().toISOString(), accepted_by: user.id }).eq("id", inv.id);
      await supabase.from("audit_log").insert({ actor_id: user.id, action: "role.accepted", target_type: "user", target_id: user.id, details: { role: inv.role } });
      toast({ title: `Welcome to the team — role: ${inv.role}` });
      navigate("/admin");
    } catch (e: any) {
      toast({ title: "Failed", description: e.message, variant: "destructive" });
    } finally { setBusy(false); }
  };

  if (loading) return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;
  if (!user) {
    return (
      <div className="min-h-screen grid place-items-center p-6">
        <div className="glass rounded-2xl p-8 text-center max-w-md">
          <Sparkles className="h-10 w-10 mx-auto text-primary mb-3" />
          <h1 className="font-display font-bold text-2xl mb-2">Sign in to accept</h1>
          <p className="text-sm text-muted-foreground mb-4">You must sign in (or create an account) using the email this invitation was sent to.</p>
          <Button onClick={() => navigate("/auth")} className="rounded-xl bg-gradient-primary shadow-glow">Go to sign in</Button>
        </div>
      </div>
    );
  }
  if (!inv) return <div className="min-h-screen grid place-items-center text-muted-foreground">Invitation not found.</div>;

  return (
    <div className="min-h-screen grid place-items-center p-6">
      <div className="glass rounded-2xl p-8 text-center max-w-md">
        <Sparkles className="h-10 w-10 mx-auto text-primary mb-3" />
        <h1 className="font-display font-bold text-2xl mb-2">You've been invited</h1>
        <p className="text-sm text-muted-foreground mb-1">Role: <span className="font-semibold capitalize">{inv.role.replace("_", " ")}</span></p>
        <p className="text-xs text-muted-foreground mb-6">Invitation for {inv.email}</p>
        <Button onClick={accept} disabled={busy} className="rounded-xl bg-gradient-primary shadow-glow w-full">
          {busy ? "Accepting…" : "Accept role"}
        </Button>
      </div>
    </div>
  );
};

export default AcceptInvite;
