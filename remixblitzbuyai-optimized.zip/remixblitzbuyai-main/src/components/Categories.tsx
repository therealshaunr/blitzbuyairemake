import { Link } from "react-router-dom";

const categories = [
  { name: "Electronics", icon: "📱", count: "12.4k", slug: "electronics" },
  { name: "Sneakers", icon: "👟", count: "8.2k", slug: "sneakers" },
  { name: "Fashion", icon: "👗", count: "21.1k", slug: "fashion" },
  { name: "Collectibles", icon: "🃏", count: "5.7k", slug: "collectibles" },
  { name: "Home", icon: "🛋️", count: "9.8k", slug: "home" },
  { name: "Gaming", icon: "🎮", count: "6.3k", slug: "gaming" },
  { name: "Watches", icon: "⌚", count: "2.1k", slug: "watches" },
  { name: "Cameras", icon: "📷", count: "1.9k", slug: "cameras" },
];

const Categories = () => {
  return (
    <section className="py-14 sm:py-20 relative">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-12">
          <h2 className="font-display text-3xl sm:text-5xl font-bold mb-4">
            Shop by <span className="text-gradient-brand">category</span>
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg">From sneakers to silicon, find what you love.</p>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-8 gap-2.5 sm:gap-3">
          {categories.map((c) => (
            <Link
              key={c.slug}
              to={`/browse?cat=${c.slug}`}
              className="glass rounded-2xl p-4 sm:p-5 text-center group hover:border-primary/40 hover:-translate-y-1 transition-all shadow-card active:scale-[0.97] min-h-[44px]"
            >
              <div className="text-3xl sm:text-4xl mb-2 group-hover:scale-110 transition-transform">{c.icon}</div>
              <div className="font-display font-semibold text-xs sm:text-sm">{c.name}</div>
              <div className="text-[10px] sm:text-xs text-muted-foreground">{c.count} items</div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;
