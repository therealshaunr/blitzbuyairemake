import { render, screen } from "@testing-library/react";
import Demo from "./Demo";

test("demo page renders and shows demo header", () => {
  render(<Demo />);
  expect(screen.getByText(/Live Demo/i)).toBeInTheDocument();
});
