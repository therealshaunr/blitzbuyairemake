import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { AlertTriangle } from "lucide-react";

const AdminAuctions = () => {
  const { user: me } = useAuth();
  const [items, setItems] = useState<any[]>([]);
  const [flags, setFlags] = useState<Record<string, any[]>>({});
  const { toast } = useToast();

  const load = async () => {
    const { data: auctions } = await supabase
      .from("listings")
      .select("id,title,current_bid_cents,bid_count,auction_ends_at,is_paused,pause_reason,seller_id")
      .eq("listing_type", "auction")
      .in("status", ["active", "approved"])
      .order("auction_ends_at", { ascending: true })
      .limit(50);
    setItems(auctions ?? []);
    if (auctions && auctions.length) {
      const ids = auctions.map((a) => a.id);
      const { data: f } = await supabase.from("bid_anomaly_flags").select("*").in("listing_id", ids).eq("resolved", false);
      const grouped: Record<string, any[]> = {};
      (f ?? []).forEach((flag: any) => {
        grouped[flag.listing_id] ??= [];
        grouped[flag.listing_id].push(flag);
      });
      setFlags(grouped);
    }
  };

  useEffect(() => { load(); }, []);

  const togglePause = async (l: any) => {
    if (!me) return;
    const next = !l.is_paused;
    const reason = next ? prompt("Pause reason?") : null;
    if (next && !reason) return;
    await supabase.from("listings").update({ is_paused: next, pause_reason: reason }).eq("id", l.id);
    await supabase.from("audit_log").insert({
      actor_id: me.id, action: next ? "auction.paused" : "auction.resumed",
      target_type: "listing", target_id: l.id, details: { reason },
    });
    toast({ title: next ? "Auction paused" : "Auction resumed" });
    load();
  };

  return (
    <AdminLayout title="Auctions Monitor">
      <div className="space-y-3">
        {items.map((l) => {
          const lflags = flags[l.id] ?? [];
          const hasCritical = lflags.some((f) => f.severity === "critical");
          return (
            <div key={l.id} className={`glass rounded-2xl p-4 sm:p-5 ${hasCritical ? "border-destructive/50" : ""}`}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-display font-semibold">{l.title}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    ${((l.current_bid_cents ?? 0) / 100).toFixed(2)} · {l.bid_count} bids · ends {l.auction_ends_at ? new Date(l.auction_ends_at).toLocaleString() : "—"}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {l.is_paused && <Badge className="bg-warning/15 text-warning border-warning/40">Paused</Badge>}
                  {hasCritical && <Badge className="bg-destructive/20 text-destructive border-destructive/40"><AlertTriangle className="h-3 w-3 mr-1" />Critical flag</Badge>}
                  <Button size="sm" variant="outline" onClick={() => togglePause(l)}>{l.is_paused ? "Resume" : "Pause"}</Button>
                </div>
              </div>
              {lflags.length > 0 && (
                <div className="mt-3 space-y-1 text-xs">
                  {lflags.map((f) => (
                    <div key={f.id} className="flex items-center gap-2">
                      <Badge variant="outline" className="text-[10px]">{f.severity}</Badge>
                      <span className="text-muted-foreground">{f.flag_type}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
        {items.length === 0 && <div className="glass rounded-2xl p-10 text-center text-muted-foreground">No live auctions.</div>}
      </div>
    </AdminLayout>
  );
};

export default AdminAuctions;
