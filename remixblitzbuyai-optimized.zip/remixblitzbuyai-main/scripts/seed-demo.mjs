#!/usr/bin/env node
/*
  Seeder for BlitzBuyAI demo data.

  Usage (run locally; DO NOT commit your service key):
    SUPABASE_URL=https://<project>.supabase.co \
    SUPABASE_SERVICE_ROLE_KEY=<service-role-key> \
    node ./scripts/seed-demo.mjs

  Notes:
  - This script requires a Supabase service_role key (server-only secret).
  - It creates demo users via the admin API and inserts listings tied to those users.
  - The repository does NOT store or log secrets. Run this only on a safe machine.
*/

import { createClient } from '@supabase/supabase-js';

const URL = process.env.SUPABASE_URL;
const SRK = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!URL || !SRK) {
  console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in environment.');
  console.error('Example: SUPABASE_URL=https://<project>.supabase.co SUPABASE_SERVICE_ROLE_KEY=xyz node ./scripts/seed-demo.mjs');
  process.exit(1);
}

const supabase = createClient(URL, SRK, { auth: { persistSession: false } });

const demoUsers = [
  { email: 'riffmaster+demo@example.com', password: 'DemoPass123!', display_name: 'RiffMaster' },
  { email: 'janedoe+demo@example.com', password: 'DemoPass123!', display_name: 'JaneDoe' },
  { email: 'hoopsfan+demo@example.com', password: 'DemoPass123!', display_name: 'HoopsFan' },
];

const demoListings = [
  {
    title: 'Vintage Fender Stratocaster — Sunburst',
    description: 'A beautifully aged 1978 Fender Stratocaster with original pickups. Plays like butter.',
    price_cents: 2499900,
    listing_type: 'buy_now',
    status: 'active'
  },
  {
    title: 'Apple MacBook Pro 14 — M1 Pro',
    description: 'Lightly used M1 Pro, 16GB RAM, 1TB SSD. Perfect for production workloads.',
    price_cents: 1799900,
    listing_type: 'buy_now',
    status: 'active'
  },
  {
    title: 'Signed Basketball — Limited Edition',
    description: "Collector's item. Comes with COA and original box.",
    price_cents: 49900,
    listing_type: 'auction',
    status: 'active'
  }
];

async function createOrGetUser(u) {
  // Try to find by email in auth.users
  const { data: existing, error: lookupErr } = await supabase.rpc('auth_get_user_by_email', { _email: u.email }).catch(() => ({ data: null, error: null }));

  if (lookupErr) {
    // Ignore RPC lookup error — fall back to create
  }

  // Supabase doesn't provide a public RPC by default to lookup auth.users; simplify by attempting to create and handle conflict
  try {
    const { data, error } = await supabase.auth.admin.createUser({
      email: u.email,
      password: u.password,
      email_confirm: true,
      user_metadata: { display_name: u.display_name }
    });
    if (error) {
      if (error.message && error.message.includes('already exists')) {
        // fetch existing user list via admin list (best-effort)
        const { data: list } = await supabase.auth.admin.listUsers();
        const found = (list?.users || []).find((x) => x.email === u.email);
        if (found) return found;
      }
      console.warn('createUser warning:', error.message || error);
    }
    return data.user ?? data;
  } catch (err) {
    console.error('createUser failed', err);
    throw err;
  }
}

async function seed() {
  console.log('Starting demo seed...');

  // Create users
  const created = [];
  for (const u of demoUsers) {
    try {
      const user = await createOrGetUser(u);
      console.log('User created/found:', user?.email ?? u.email);
      created.push(user);
    } catch (e) {
      console.error('Failed to create user', u.email, e?.message ?? e);
    }
  }

  // Insert listings tied to the created users (round-robin)
  const listingsToInsert = demoListings.map((l, i) => ({ ...l, seller_id: created[i % created.length].id }));
  const { data: inserted, error: insertErr } = await supabase.from('listings').insert(listingsToInsert).select();
  if (insertErr) {
    console.error('Error inserting listings:', insertErr);
  } else {
    console.log('Inserted listings:', (inserted || []).map((x) => x.id));
  }

  console.log('Seeder finished.');
  console.log('Reminder: rotate or revoke this service role key when you are done, and do not commit it.');
}

seed().catch((err) => {
  console.error('Seeder failed', err);
  process.exit(1);
});
