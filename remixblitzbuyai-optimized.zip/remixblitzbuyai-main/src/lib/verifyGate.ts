import { supabase } from "@/integrations/supabase/client";

/**
 * Returns true if the current user is authenticated AND has a verified email.
 * Email verification is REQUIRED to buy or sell on BlitzBuy.AI.
 */
export async function isEmailVerified(): Promise<boolean> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;
  // Supabase sets email_confirmed_at when the user clicks the verify link.
  return Boolean((user as any).email_confirmed_at);
}

export type VerifyGateResult =
  | { ok: true }
  | { ok: false; reason: "not_signed_in" | "email_unverified" };

export async function checkBuyOrSellGate(): Promise<VerifyGateResult> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { ok: false, reason: "not_signed_in" };
  if (!(user as any).email_confirmed_at) return { ok: false, reason: "email_unverified" };
  return { ok: true };
}
