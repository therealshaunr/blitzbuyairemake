import React from "react";
import { demoListings } from "@/demo/demoData";

const centsToUsd = (c?: number) => {
  if (!c && c !== 0) return "—";
  return `$${(c / 100).toFixed(2)}`;
};

const DemoCard = ({ item }: { item: typeof demoListings[0] }) => (
  <div className="border rounded-lg p-4 shadow-sm">
    <div className="h-40 bg-slate-100 rounded-md mb-3 flex items-center justify-center">
      {item.images && item.images.length ? (
        <img src={item.images[0]} alt={item.title} className="max-h-36 object-contain" />
      ) : (
        <div className="text-slate-400">No image</div>
      )}
    </div>
    <h3 className="text-lg font-semibold">{item.title}</h3>
    <p className="text-sm text-slate-600 mt-2">{item.description}</p>
    <div className="mt-3 flex items-center justify-between">
      <div className="text-sm text-slate-700">Seller: {item.seller_display}</div>
      <div className="text-lg font-bold">{centsToUsd(item.price_cents)}</div>
    </div>
  </div>
);

const Demo = () => {
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">BlitzBuyAI — Live Demo</h1>
      <p className="text-slate-600 mb-6">Demo mode: this page uses local demo data and does not require Supabase.</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {demoListings.map((d) => (
          <DemoCard key={d.id} item={d} />
        ))}
      </div>
    </div>
  );
};

export default Demo;
