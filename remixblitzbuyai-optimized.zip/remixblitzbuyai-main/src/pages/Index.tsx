import { useState } from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import HowItWorks from "@/components/HowItWorks";
import LiveAuctions from "@/components/LiveAuctions";
import Categories from "@/components/Categories";
import CTASell from "@/components/CTASell";
import Footer from "@/components/Footer";
import BottomTabBar from "@/components/BottomTabBar";
import CinematicIntro, { shouldShowIntro } from "@/components/CinematicIntro";

const Index = () => {
  const [showIntro, setShowIntro] = useState(() => shouldShowIntro());

  return (
    <div className="min-h-screen">
      {showIntro && <CinematicIntro onDone={() => setShowIntro(false)} />}
      <Navbar />
      <main className="pb-28 md:pb-0">
        <Hero />
        <HowItWorks />
        <LiveAuctions />
        <Categories />
        <CTASell />
      </main>
      <Footer />
      <BottomTabBar />
    </div>
  );
};

export default Index;
