

# BlitzBuy.AI — Rebrand + Phase 1 (Trust & Verified Signup)

Approved roadmap. Starting with a full rebrand from AuraSellAI → **BlitzBuy.AI**, then immediately into Phase 1 (verified signup + Twilio phone OTP + server-side anti-fraud).

## Part A — Rebrand to BlitzBuy.AI

Replace every user-visible "AuraSellAI" / "AuraSell" / "FutureSell" reference with **BlitzBuy.AI**. Brand mark renders as `Blitz` + gradient `Buy.AI`.

Files touched:
- `index.html` — `<title>`, meta description, OG tags, theme-color
- `src/components/Navbar.tsx`, `Footer.tsx`, `Hero.tsx`, `CTASell.tsx`, `HowItWorks.tsx`, `CinematicIntro.tsx`, `EmailVerifyBanner.tsx`, `BottomTabBar.tsx`
- `src/pages/Auth.tsx`, `Account.tsx`, `Index.tsx`, `NotFound.tsx`, `Demo.tsx`
- `src/pages/legal/LegalDoc.tsx` + any seeded legal copy referencing the old name
- `src/pages/admin/*` headers
- `README.md`, `ONBOARDING.md`, `AGENT_CONTEXT.md`, `.lovable/plan.md`, `package.json` name field
- `public/robots.txt` if it references the brand

No DB rename needed — table names are generic. NextGen membership name stays (it's a tier, not the brand).

## Part B — Phase 1: Trust & Verified Signup

### B1. Connect Twilio
Use the standard Twilio connector. After connect, recommend the user enable **SMS Pumping Protection** + restrict **SMS Geo Permissions** to US only (anti-fraud).

### B2. Database additions
Migration adds:
- `signup_attempts` index on `(ip_address, created_at)` for fast rate-limit lookups (table already exists)
- `phone_otps` insert/update policies for service role only (table exists, policies missing)
- Seed `disposable_email_domains` with ~3000 known throwaway domains (mailinator, tempmail, guerrillamail, 10minutemail, etc.)
- Helper SQL function `count_recent_signups_by_ip(ip text, since timestamptz)` for the rate limiter

### B3. Edge functions (4 new)

| Function | Purpose |
|---|---|
| `signup-precheck` | Server-side gate **before** `supabase.auth.signUp`. Captures IP, checks: disposable email blocklist, IP rate limit (≤3 signups/24h), unique phone, normalized name+address soft-duplicate → writes `duplicate_review_queue`. Returns `{ ok, reason }`. |
| `send-phone-otp` | Generates 6-digit code, hashes with bcrypt, stores in `phone_otps` (10-min expiry), sends via Twilio gateway. Rate-limited: 1 send / 60s, 5 sends / hour per phone+IP. |
| `verify-phone-otp` | Validates code, increments `attempts` (lock at 5), on success sets `profiles.phone_verified_at = now()`. |
| `record-signup-attempt` | Logs every signup outcome (success/fail) with IP for the throttle to read. |

All four use the corsHeaders pattern, validate input with Zod, and inject `LOVABLE_API_KEY` + `TWILIO_API_KEY` from env.

### B4. Frontend rewires

- **`src/pages/Auth.tsx`**: signup now calls `signup-precheck` first; on `ok`, runs `supabase.auth.signUp`, then `record-signup-attempt`. Removes the client-side phone-uniqueness query (moved server-side).
- **New component `src/components/PhoneVerifyCard.tsx`**: shown in Account → Settings + as an inline blocker on `/sell` until verified. Two-step: enter phone → enter 6-digit code. Resend timer.
- **`src/pages/Account.tsx`**: surfaces `PhoneVerifyCard` when `!phone_verified_at`. "List item" button is disabled (with tooltip) until phone verified AND seller agreement accepted.
- **New helper `src/lib/verifyGate.ts`** (extend existing): `requireVerified()` returns `{ canSell, missing: ['email'|'phone'|'agreement'] }`.

### B5. Seller Agreement acceptance
Lightweight modal triggered on first visit to `/sell` that renders the current `legal_agreements` row where `doc_type='seller_agreement' AND is_current=true`, captures `signed_name`, writes `user_agreement_acceptances` + sets `profiles.seller_agreement_accepted_at`.

## What you'll see when this ships

1. Brand is BlitzBuy.AI everywhere — title bar, nav, hero, footer, emails, legal docs, admin
2. Signup is hardened: disposable emails blocked server-side, IPs throttled to 3/day, duplicate name+address flows to admin review queue (not auto-blocked)
3. New users get a phone verification card in Account — enter phone → SMS code → verified
4. "List item" CTA is gated until phone verified + seller agreement signed

## What's NOT in this batch (queued for Phase 2)
- The `/sell` page itself + AI listing generator — next message
- `/browse` + listing detail — Phase 3
- Stripe / payments / NextGen subscription — Phase 4

## Open items I need from you before I start

1. **Twilio**: I'll trigger the connector — you'll click through to authorize it. You confirmed earlier you have an account. Good to go?
2. **SMS sender**: do you have a Twilio phone number provisioned for the `From` field, or should I have the function read it from a `TWILIO_FROM_NUMBER` secret you'll add?
3. **Geo restriction**: lock OTP sends to US numbers only for launch (cheapest + lowest fraud), or allow international from day one?

