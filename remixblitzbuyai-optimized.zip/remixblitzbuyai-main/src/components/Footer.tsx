import { Sparkles } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="border-t border-border/60 py-10 sm:py-12 mt-8 sm:mt-12">
      <div className="container">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 mb-10">
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="h-9 w-9 rounded-xl bg-gradient-primary grid place-items-center shadow-glow">
                <Sparkles className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="font-display font-bold text-lg">
                Blitz<span className="text-gradient-brand">Buy.AI</span>
              </span>
            </Link>
            <p className="text-sm text-muted-foreground max-w-xs">Deals that hit fast. AI-first, fee-fair, lightning-quick.</p>
          </div>

          <div>
            <h4 className="font-display font-semibold mb-3 text-sm">Marketplace</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/browse" className="hover:text-foreground transition-colors">Browse all</Link></li>
              <li><Link to="/browse?type=auction" className="hover:text-foreground transition-colors">Auctions</Link></li>
              <li><Link to="/browse?type=buy-now" className="hover:text-foreground transition-colors">Buy now</Link></li>
              <li><Link to="/browse?type=local" className="hover:text-foreground transition-colors">Local pickup</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold mb-3 text-sm">Sell</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/sell" className="hover:text-foreground transition-colors">Start a listing</Link></li>
              <li><Link to="/account" className="hover:text-foreground transition-colors">Seller dashboard</Link></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Fees</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Seller tips</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold mb-3 text-sm">Company</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-foreground transition-colors">About</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Trust & safety</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Help center</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Contact</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-border/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-muted-foreground">
          <p>© {new Date().getFullYear()} BlitzBuy.AI. Deals that hit fast.</p>
          <div className="flex items-center gap-6">
            <a href="#" className="hover:text-foreground transition-colors">Privacy</a>
            <a href="#" className="hover:text-foreground transition-colors">Terms</a>
            <a href="#" className="hover:text-foreground transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
