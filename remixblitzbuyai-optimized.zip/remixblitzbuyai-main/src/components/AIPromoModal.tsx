import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Sparkles, Zap, Mic, Camera, X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

const STORAGE_KEY = "blitzbuy.ai.promo.dismissed.v1";

export default function AIPromoModal() {
  const [open, setOpen] = useState(false);
  const { user, loading } = useAuth();
  const location = useLocation();

  useEffect(() => {
    if (loading) return;
    // Don't pop on auth or admin pages
    if (location.pathname.startsWith("/auth") || location.pathname.startsWith("/admin")) return;
    const dismissed = typeof window !== "undefined" && localStorage.getItem(STORAGE_KEY);
    if (dismissed) return;
    const t = setTimeout(() => setOpen(true), 1200);
    return () => clearTimeout(t);
  }, [loading, location.pathname]);

  const dismiss = () => {
    localStorage.setItem(STORAGE_KEY, new Date().toISOString());
    setOpen(false);
  };

  if (!open) return null;

  const ctaTo = user ? "/sell" : "/auth";
  const ctaLabel = user ? "List something in 10 seconds" : "Sign up — list in 10 seconds";

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-lg bg-zinc-950 border border-yellow-400/40 rounded-3xl p-8 shadow-[0_0_60px_-10px_rgba(234,179,8,0.4)] animate-in zoom-in-95">
        <button
          onClick={dismiss}
          className="absolute top-4 right-4 text-zinc-500 hover:text-white transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="inline-flex items-center gap-2 bg-yellow-400/10 border border-yellow-400/30 rounded-full px-3 py-1 mb-5">
          <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
          <span className="text-xs font-semibold text-yellow-400 uppercase tracking-wider">
            World's First AI-Native Marketplace
          </span>
        </div>

        <h2 className="text-3xl md:text-4xl font-bold text-white mb-3 leading-tight">
          List your stuff in <span className="text-yellow-400">seconds</span>.
          <br />Not minutes. Not hours.
        </h2>

        <p className="text-zinc-400 text-base mb-6">
          BlitzBuy.AI is the most powerful all-in-one selling platform — auctions,
          local pickups, and shipped sales — supercharged by AI that writes your
          listing for you.
        </p>

        <div className="grid grid-cols-3 gap-3 mb-7">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-center">
            <Camera className="w-5 h-5 text-yellow-400 mx-auto mb-1.5" />
            <div className="text-xs text-zinc-300 font-medium">Snap a photo</div>
          </div>
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-center">
            <Mic className="w-5 h-5 text-yellow-400 mx-auto mb-1.5" />
            <div className="text-xs text-zinc-300 font-medium">Or just talk</div>
          </div>
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-center">
            <Zap className="w-5 h-5 text-yellow-400 mx-auto mb-1.5" />
            <div className="text-xs text-zinc-300 font-medium">AI does the rest</div>
          </div>
        </div>

        <Link
          to={ctaTo}
          onClick={dismiss}
          className="block w-full text-center bg-yellow-400 hover:bg-yellow-300 transition text-black font-semibold text-lg px-6 py-4 rounded-2xl"
        >
          {ctaLabel} ⚡
        </Link>

        <button
          onClick={dismiss}
          className="block w-full text-center text-zinc-500 hover:text-zinc-300 text-sm mt-3 transition"
        >
          Maybe later
        </button>
      </div>
    </div>
  );
}
