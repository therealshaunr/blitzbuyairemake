import { supabase } from "@/integrations/supabase/client";

export async function isDisposableEmail(email: string): Promise<boolean> {
  const domain = email.split("@")[1]?.toLowerCase().trim();
  if (!domain) return false;
  const { data } = await supabase
    .from("disposable_email_domains")
    .select("domain")
    .eq("domain", domain)
    .maybeSingle();
  return !!data;
}
