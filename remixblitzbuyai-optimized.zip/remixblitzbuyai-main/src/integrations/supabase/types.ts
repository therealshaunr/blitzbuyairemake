export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      account_actions: {
        Row: {
          action: string
          created_at: string
          duration_days: number | null
          expires_at: string | null
          id: string
          performed_by: string | null
          reason: string
          user_id: string
        }
        Insert: {
          action: string
          created_at?: string
          duration_days?: number | null
          expires_at?: string | null
          id?: string
          performed_by?: string | null
          reason: string
          user_id: string
        }
        Update: {
          action?: string
          created_at?: string
          duration_days?: number | null
          expires_at?: string | null
          id?: string
          performed_by?: string | null
          reason?: string
          user_id?: string
        }
        Relationships: []
      }
      admin_invitations: {
        Row: {
          accepted_at: string | null
          accepted_by: string | null
          created_at: string
          email: string
          expires_at: string
          id: string
          invited_by: string
          role: Database["public"]["Enums"]["app_role"]
          token: string
        }
        Insert: {
          accepted_at?: string | null
          accepted_by?: string | null
          created_at?: string
          email: string
          expires_at: string
          id?: string
          invited_by: string
          role: Database["public"]["Enums"]["app_role"]
          token: string
        }
        Update: {
          accepted_at?: string | null
          accepted_by?: string | null
          created_at?: string
          email?: string
          expires_at?: string
          id?: string
          invited_by?: string
          role?: Database["public"]["Enums"]["app_role"]
          token?: string
        }
        Relationships: []
      }
      audit_log: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          details: Json | null
          id: string
          ip_address: string | null
          target_id: string | null
          target_type: string | null
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          target_id?: string | null
          target_type?: string | null
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          target_id?: string | null
          target_type?: string | null
        }
        Relationships: []
      }
      bid_anomaly_flags: {
        Row: {
          bid_id: string | null
          bidder_id: string | null
          created_at: string
          details: Json | null
          flag_type: string
          id: string
          listing_id: string
          resolution_notes: string | null
          resolved: boolean
          resolved_at: string | null
          resolved_by: string | null
          severity: Database["public"]["Enums"]["flag_severity"]
        }
        Insert: {
          bid_id?: string | null
          bidder_id?: string | null
          created_at?: string
          details?: Json | null
          flag_type: string
          id?: string
          listing_id: string
          resolution_notes?: string | null
          resolved?: boolean
          resolved_at?: string | null
          resolved_by?: string | null
          severity?: Database["public"]["Enums"]["flag_severity"]
        }
        Update: {
          bid_id?: string | null
          bidder_id?: string | null
          created_at?: string
          details?: Json | null
          flag_type?: string
          id?: string
          listing_id?: string
          resolution_notes?: string | null
          resolved?: boolean
          resolved_at?: string | null
          resolved_by?: string | null
          severity?: Database["public"]["Enums"]["flag_severity"]
        }
        Relationships: [
          {
            foreignKeyName: "bid_anomaly_flags_bid_id_fkey"
            columns: ["bid_id"]
            isOneToOne: false
            referencedRelation: "bids"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bid_anomaly_flags_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "listings"
            referencedColumns: ["id"]
          },
        ]
      }
      bids: {
        Row: {
          amount_cents: number
          bidder_id: string
          created_at: string
          id: string
          ip_address: string | null
          is_voided: boolean
          listing_id: string
          user_agent: string | null
          void_reason: string | null
          voided_by: string | null
        }
        Insert: {
          amount_cents: number
          bidder_id: string
          created_at?: string
          id?: string
          ip_address?: string | null
          is_voided?: boolean
          listing_id: string
          user_agent?: string | null
          void_reason?: string | null
          voided_by?: string | null
        }
        Update: {
          amount_cents?: number
          bidder_id?: string
          created_at?: string
          id?: string
          ip_address?: string | null
          is_voided?: boolean
          listing_id?: string
          user_agent?: string | null
          void_reason?: string | null
          voided_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bids_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "listings"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          buyer_id: string
          buyer_paid_unlock: boolean
          contact_unlocked: boolean
          created_at: string
          id: string
          last_message_at: string | null
          listing_id: string | null
          seller_id: string
          seller_paid_unlock: boolean
        }
        Insert: {
          buyer_id: string
          buyer_paid_unlock?: boolean
          contact_unlocked?: boolean
          created_at?: string
          id?: string
          last_message_at?: string | null
          listing_id?: string | null
          seller_id: string
          seller_paid_unlock?: boolean
        }
        Update: {
          buyer_id?: string
          buyer_paid_unlock?: boolean
          contact_unlocked?: boolean
          created_at?: string
          id?: string
          last_message_at?: string | null
          listing_id?: string | null
          seller_id?: string
          seller_paid_unlock?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "conversations_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "listings"
            referencedColumns: ["id"]
          },
        ]
      }
      disposable_email_domains: {
        Row: {
          added_at: string
          domain: string
        }
        Insert: {
          added_at?: string
          domain: string
        }
        Update: {
          added_at?: string
          domain?: string
        }
        Relationships: []
      }
      duplicate_review_queue: {
        Row: {
          created_at: string
          decision: string | null
          id: string
          match_details: Json | null
          match_reason: string
          matched_user_id: string | null
          reviewed: boolean
          reviewed_at: string | null
          reviewed_by: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          decision?: string | null
          id?: string
          match_details?: Json | null
          match_reason: string
          matched_user_id?: string | null
          reviewed?: boolean
          reviewed_at?: string | null
          reviewed_by?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          decision?: string | null
          id?: string
          match_details?: Json | null
          match_reason?: string
          matched_user_id?: string | null
          reviewed?: boolean
          reviewed_at?: string | null
          reviewed_by?: string | null
          user_id?: string
        }
        Relationships: []
      }
      legal_agreements: {
        Row: {
          body: string
          created_at: string
          created_by: string | null
          doc_type: string
          effective_at: string
          id: string
          is_current: boolean
          title: string
          version: string
        }
        Insert: {
          body: string
          created_at?: string
          created_by?: string | null
          doc_type: string
          effective_at?: string
          id?: string
          is_current?: boolean
          title: string
          version: string
        }
        Update: {
          body?: string
          created_at?: string
          created_by?: string | null
          doc_type?: string
          effective_at?: string
          id?: string
          is_current?: boolean
          title?: string
          version?: string
        }
        Relationships: []
      }
      listing_images: {
        Row: {
          created_at: string
          id: string
          listing_id: string
          position: number
          url: string
        }
        Insert: {
          created_at?: string
          id?: string
          listing_id: string
          position?: number
          url: string
        }
        Update: {
          created_at?: string
          id?: string
          listing_id?: string
          position?: number
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "listing_images_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "listings"
            referencedColumns: ["id"]
          },
        ]
      }
      listings: {
        Row: {
          ai_assist_enabled: boolean
          ai_review_notes: string | null
          ai_review_score: number | null
          auction_duration_days: number | null
          auction_ends_at: string | null
          bid_count: number
          category: string | null
          city: string | null
          condition: string | null
          created_at: string
          current_bid_cents: number | null
          current_bidder_id: string | null
          description: string | null
          id: string
          is_paused: boolean
          listing_type: Database["public"]["Enums"]["listing_type"]
          pause_reason: string | null
          price_cents: number | null
          rejection_reason: string | null
          reserve_cents: number | null
          reviewed_at: string | null
          reviewed_by: string | null
          seller_id: string
          starting_bid_cents: number | null
          state: string | null
          status: Database["public"]["Enums"]["listing_status"]
          tags: string[] | null
          title: string
          updated_at: string
          view_count: number
          watch_count: number
          zip: string | null
        }
        Insert: {
          ai_assist_enabled?: boolean
          ai_review_notes?: string | null
          ai_review_score?: number | null
          auction_duration_days?: number | null
          auction_ends_at?: string | null
          bid_count?: number
          category?: string | null
          city?: string | null
          condition?: string | null
          created_at?: string
          current_bid_cents?: number | null
          current_bidder_id?: string | null
          description?: string | null
          id?: string
          is_paused?: boolean
          listing_type?: Database["public"]["Enums"]["listing_type"]
          pause_reason?: string | null
          price_cents?: number | null
          rejection_reason?: string | null
          reserve_cents?: number | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          seller_id: string
          starting_bid_cents?: number | null
          state?: string | null
          status?: Database["public"]["Enums"]["listing_status"]
          tags?: string[] | null
          title: string
          updated_at?: string
          view_count?: number
          watch_count?: number
          zip?: string | null
        }
        Update: {
          ai_assist_enabled?: boolean
          ai_review_notes?: string | null
          ai_review_score?: number | null
          auction_duration_days?: number | null
          auction_ends_at?: string | null
          bid_count?: number
          category?: string | null
          city?: string | null
          condition?: string | null
          created_at?: string
          current_bid_cents?: number | null
          current_bidder_id?: string | null
          description?: string | null
          id?: string
          is_paused?: boolean
          listing_type?: Database["public"]["Enums"]["listing_type"]
          pause_reason?: string | null
          price_cents?: number | null
          rejection_reason?: string | null
          reserve_cents?: number | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          seller_id?: string
          starting_bid_cents?: number | null
          state?: string | null
          status?: Database["public"]["Enums"]["listing_status"]
          tags?: string[] | null
          title?: string
          updated_at?: string
          view_count?: number
          watch_count?: number
          zip?: string | null
        }
        Relationships: []
      }
      messages: {
        Row: {
          body: string
          conversation_id: string
          created_at: string
          id: string
          is_system: boolean
          read_at: string | null
          sender_id: string
        }
        Insert: {
          body: string
          conversation_id: string
          created_at?: string
          id?: string
          is_system?: boolean
          read_at?: string | null
          sender_id: string
        }
        Update: {
          body?: string
          conversation_id?: string
          created_at?: string
          id?: string
          is_system?: boolean
          read_at?: string | null
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      phone_otps: {
        Row: {
          attempts: number
          code_hash: string
          created_at: string
          expires_at: string
          id: string
          phone_e164: string
          user_id: string | null
          verified_at: string | null
        }
        Insert: {
          attempts?: number
          code_hash: string
          created_at?: string
          expires_at: string
          id?: string
          phone_e164: string
          user_id?: string | null
          verified_at?: string | null
        }
        Update: {
          attempts?: number
          code_hash?: string
          created_at?: string
          expires_at?: string
          id?: string
          phone_e164?: string
          user_id?: string | null
          verified_at?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          account_status: Database["public"]["Enums"]["account_status"]
          ai_assist_enabled_global: boolean
          avatar_url: string | null
          bio: string | null
          buyer_rating: number | null
          city: string | null
          country: string | null
          created_at: string
          display_name: string | null
          email_verified_at: string | null
          full_name: string | null
          id: string
          nextgen_credit_cents: number
          nextgen_renews_at: string | null
          nextgen_status: Database["public"]["Enums"]["nextgen_status"]
          phone_e164: string | null
          phone_verified_at: string | null
          restricted_until: string | null
          restriction_reason: string | null
          seller_agreement_accepted_at: string | null
          seller_agreement_version: string | null
          seller_rating: number | null
          signup_ip: string | null
          state: string | null
          street_address: string | null
          total_sales: number | null
          unpaid_fee_balance_cents: number
          updated_at: string
          zip: string | null
        }
        Insert: {
          account_status?: Database["public"]["Enums"]["account_status"]
          ai_assist_enabled_global?: boolean
          avatar_url?: string | null
          bio?: string | null
          buyer_rating?: number | null
          city?: string | null
          country?: string | null
          created_at?: string
          display_name?: string | null
          email_verified_at?: string | null
          full_name?: string | null
          id: string
          nextgen_credit_cents?: number
          nextgen_renews_at?: string | null
          nextgen_status?: Database["public"]["Enums"]["nextgen_status"]
          phone_e164?: string | null
          phone_verified_at?: string | null
          restricted_until?: string | null
          restriction_reason?: string | null
          seller_agreement_accepted_at?: string | null
          seller_agreement_version?: string | null
          seller_rating?: number | null
          signup_ip?: string | null
          state?: string | null
          street_address?: string | null
          total_sales?: number | null
          unpaid_fee_balance_cents?: number
          updated_at?: string
          zip?: string | null
        }
        Update: {
          account_status?: Database["public"]["Enums"]["account_status"]
          ai_assist_enabled_global?: boolean
          avatar_url?: string | null
          bio?: string | null
          buyer_rating?: number | null
          city?: string | null
          country?: string | null
          created_at?: string
          display_name?: string | null
          email_verified_at?: string | null
          full_name?: string | null
          id?: string
          nextgen_credit_cents?: number
          nextgen_renews_at?: string | null
          nextgen_status?: Database["public"]["Enums"]["nextgen_status"]
          phone_e164?: string | null
          phone_verified_at?: string | null
          restricted_until?: string | null
          restriction_reason?: string | null
          seller_agreement_accepted_at?: string | null
          seller_agreement_version?: string | null
          seller_rating?: number | null
          signup_ip?: string | null
          state?: string | null
          street_address?: string | null
          total_sales?: number | null
          unpaid_fee_balance_cents?: number
          updated_at?: string
          zip?: string | null
        }
        Relationships: []
      }
      reports: {
        Row: {
          action_taken: string | null
          assigned_to: string | null
          category: string
          created_at: string
          description: string | null
          evidence_url: string | null
          id: string
          reported_listing_id: string | null
          reported_user_id: string | null
          reporter_id: string
          resolution_notes: string | null
          resolved_at: string | null
          status: Database["public"]["Enums"]["report_status"]
          updated_at: string
        }
        Insert: {
          action_taken?: string | null
          assigned_to?: string | null
          category: string
          created_at?: string
          description?: string | null
          evidence_url?: string | null
          id?: string
          reported_listing_id?: string | null
          reported_user_id?: string | null
          reporter_id: string
          resolution_notes?: string | null
          resolved_at?: string | null
          status?: Database["public"]["Enums"]["report_status"]
          updated_at?: string
        }
        Update: {
          action_taken?: string | null
          assigned_to?: string | null
          category?: string
          created_at?: string
          description?: string | null
          evidence_url?: string | null
          id?: string
          reported_listing_id?: string | null
          reported_user_id?: string | null
          reporter_id?: string
          resolution_notes?: string | null
          resolved_at?: string | null
          status?: Database["public"]["Enums"]["report_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "reports_reported_listing_id_fkey"
            columns: ["reported_listing_id"]
            isOneToOne: false
            referencedRelation: "listings"
            referencedColumns: ["id"]
          },
        ]
      }
      signup_attempts: {
        Row: {
          created_at: string
          email: string | null
          id: string
          ip_address: string
          success: boolean
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          ip_address: string
          success?: boolean
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          ip_address?: string
          success?: boolean
        }
        Relationships: []
      }
      support_ticket_messages: {
        Row: {
          body: string
          created_at: string
          id: string
          is_staff_reply: boolean
          sender_id: string
          ticket_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          is_staff_reply?: boolean
          sender_id: string
          ticket_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          is_staff_reply?: boolean
          sender_id?: string
          ticket_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "support_ticket_messages_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "support_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      support_tickets: {
        Row: {
          assigned_to: string | null
          body: string
          category: string | null
          created_at: string
          id: string
          priority: string | null
          status: Database["public"]["Enums"]["ticket_status"]
          subject: string
          updated_at: string
          user_id: string
        }
        Insert: {
          assigned_to?: string | null
          body: string
          category?: string | null
          created_at?: string
          id?: string
          priority?: string | null
          status?: Database["public"]["Enums"]["ticket_status"]
          subject: string
          updated_at?: string
          user_id: string
        }
        Update: {
          assigned_to?: string | null
          body?: string
          category?: string | null
          created_at?: string
          id?: string
          priority?: string | null
          status?: Database["public"]["Enums"]["ticket_status"]
          subject?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_agreement_acceptances: {
        Row: {
          accepted_at: string
          agreement_id: string
          doc_type: string
          id: string
          ip_address: string | null
          signed_name: string | null
          user_agent: string | null
          user_id: string
          version: string
        }
        Insert: {
          accepted_at?: string
          agreement_id: string
          doc_type: string
          id?: string
          ip_address?: string | null
          signed_name?: string | null
          user_agent?: string | null
          user_id: string
          version: string
        }
        Update: {
          accepted_at?: string
          agreement_id?: string
          doc_type?: string
          id?: string
          ip_address?: string | null
          signed_name?: string | null
          user_agent?: string | null
          user_id?: string
          version?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_agreement_acceptances_agreement_id_fkey"
            columns: ["agreement_id"]
            isOneToOne: false
            referencedRelation: "legal_agreements"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          granted_by: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          granted_by?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          granted_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_staff: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      account_status: "active" | "restricted" | "locked" | "disabled" | "banned"
      app_role: "admin" | "support" | "report_generator" | "moderator" | "user"
      flag_severity: "info" | "warn" | "critical"
      listing_status:
        | "draft"
        | "pending_review"
        | "approved"
        | "rejected"
        | "active"
        | "sold"
        | "expired"
        | "removed"
      listing_type: "auction" | "buy_now" | "local"
      nextgen_status: "none" | "active" | "canceled" | "past_due"
      report_status: "open" | "investigating" | "resolved" | "dismissed"
      ticket_status:
        | "open"
        | "in_progress"
        | "waiting_user"
        | "resolved"
        | "closed"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      account_status: ["active", "restricted", "locked", "disabled", "banned"],
      app_role: ["admin", "support", "report_generator", "moderator", "user"],
      flag_severity: ["info", "warn", "critical"],
      listing_status: [
        "draft",
        "pending_review",
        "approved",
        "rejected",
        "active",
        "sold",
        "expired",
        "removed",
      ],
      listing_type: ["auction", "buy_now", "local"],
      nextgen_status: ["none", "active", "canceled", "past_due"],
      report_status: ["open", "investigating", "resolved", "dismissed"],
      ticket_status: [
        "open",
        "in_progress",
        "waiting_user",
        "resolved",
        "closed",
      ],
    },
  },
} as const
