import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { z } from "zod";
import { Sparkles, Mail, Lock, User as UserIcon, Phone, MapPin, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { isDisposableEmail } from "@/lib/disposableEmail";

const signupSchema = z.object({
  email: z.string().trim().email("Invalid email").max(255),
  password: z.string().min(8, "Min 8 characters").max(128),
  full_name: z.string().trim().min(2, "Required").max(100),
  display_name: z.string().trim().min(2, "Required").max(50),
  phone: z.string().trim().regex(/^\+[1-9]\d{6,14}$/, "Use E.164 format e.g. +15551234567"),
  street_address: z.string().trim().min(3, "Required").max(200),
  city: z.string().trim().min(1, "Required").max(100),
  state: z.string().trim().min(2, "Required").max(50),
  zip: z.string().trim().min(3, "Required").max(20),
});

const loginSchema = z.object({
  email: z.string().trim().email("Invalid email").max(255),
  password: z.string().min(1, "Required"),
});

const Auth = () => {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const [form, setForm] = useState({
    email: "",
    password: "",
    full_name: "",
    display_name: "",
    phone: "",
    street_address: "",
    city: "",
    state: "",
    zip: "",
  });

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "login") {
        const parsed = loginSchema.safeParse(form);
        if (!parsed.success) {
          toast({ title: "Check your inputs", description: parsed.error.issues[0].message, variant: "destructive" });
          return;
        }
        const { error } = await supabase.auth.signInWithPassword({
          email: parsed.data.email,
          password: parsed.data.password,
        });
        if (error) {
          toast({ title: "Login failed", description: error.message, variant: "destructive" });
          return;
        }
        // Check account status
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data: prof } = await supabase.from("profiles").select("account_status, restriction_reason").eq("id", user.id).maybeSingle();
          if (prof && prof.account_status === "banned") {
            await supabase.auth.signOut();
            toast({ title: "Account banned", description: prof.restriction_reason || "Contact support.", variant: "destructive" });
            return;
          }
          if (prof && prof.account_status === "disabled") {
            await supabase.auth.signOut();
            toast({ title: "Account disabled", description: prof.restriction_reason || "Contact support.", variant: "destructive" });
            return;
          }
        }
        toast({ title: "Welcome back" });
        navigate("/account");
      } else {
        const parsed = signupSchema.safeParse(form);
        if (!parsed.success) {
          toast({ title: "Check your inputs", description: parsed.error.issues[0].message, variant: "destructive" });
          return;
        }
        // disposable email check
        if (await isDisposableEmail(parsed.data.email)) {
          toast({ title: "Email blocked", description: "Disposable email domains are not allowed.", variant: "destructive" });
          return;
        }
        // unique phone check
        const { data: existingPhone } = await supabase.from("profiles").select("id").eq("phone_e164", parsed.data.phone).maybeSingle();
        if (existingPhone) {
          toast({ title: "Phone already in use", description: "Each phone number can only be used once.", variant: "destructive" });
          return;
        }

        const { error } = await supabase.auth.signUp({
          email: parsed.data.email,
          password: parsed.data.password,
          options: {
            emailRedirectTo: `${window.location.origin}/account`,
            data: {
              full_name: parsed.data.full_name,
              display_name: parsed.data.display_name,
            },
          },
        });
        if (error) {
          toast({ title: "Signup failed", description: error.message, variant: "destructive" });
          return;
        }
        // Update profile with the rest of the verification data
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase.from("profiles").update({
            full_name: parsed.data.full_name,
            display_name: parsed.data.display_name,
            phone_e164: parsed.data.phone,
            street_address: parsed.data.street_address,
            city: parsed.data.city,
            state: parsed.data.state,
            zip: parsed.data.zip,
          }).eq("id", user.id);
        }
        toast({
          title: "Account created",
          description: "Check your email to verify. Phone verification will be required to sell.",
        });
        navigate("/account");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-8 pb-12 px-4">
      <div className="container max-w-md">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="h-4 w-4" />
          Back home
        </Link>

        <div className="text-center mb-8">
          <div className="inline-flex h-14 w-14 rounded-2xl bg-gradient-primary grid place-items-center shadow-glow mb-4">
            <Sparkles className="h-7 w-7 text-primary-foreground" />
          </div>
          <h1 className="font-display text-3xl font-bold">
            {mode === "login" ? "Welcome back" : "Join "}
            {mode === "signup" && (
              <span>
                Blitz<span className="text-gradient-brand">Buy.AI</span>
              </span>
            )}
          </h1>
          <p className="text-sm text-muted-foreground mt-2">
            {mode === "login" ? "Sign in to keep selling smart." : "Free to join. Verified to sell."}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="glass rounded-2xl p-6 space-y-4 shadow-card">
          <div className="space-y-2">
            <Label htmlFor="email"><Mail className="inline h-3.5 w-3.5 mr-1" />Email</Label>
            <Input id="email" type="email" required value={form.email} onChange={set("email")} placeholder="you@example.com" autoComplete="email" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password"><Lock className="inline h-3.5 w-3.5 mr-1" />Password</Label>
            <Input id="password" type="password" required value={form.password} onChange={set("password")} placeholder={mode === "signup" ? "Min 8 characters" : ""} autoComplete={mode === "signup" ? "new-password" : "current-password"} />
          </div>

          {mode === "signup" && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="full_name"><UserIcon className="inline h-3.5 w-3.5 mr-1" />Full name</Label>
                  <Input id="full_name" required value={form.full_name} onChange={set("full_name")} placeholder="Legal name" autoComplete="name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="display_name">Display name</Label>
                  <Input id="display_name" required value={form.display_name} onChange={set("display_name")} placeholder="Public handle" autoComplete="username" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone"><Phone className="inline h-3.5 w-3.5 mr-1" />Phone (E.164)</Label>
                <Input id="phone" required value={form.phone} onChange={set("phone")} placeholder="+15551234567" autoComplete="tel" />
                <p className="text-[11px] text-muted-foreground">SMS verification required before selling.</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="street_address"><MapPin className="inline h-3.5 w-3.5 mr-1" />Street address</Label>
                <Input id="street_address" required value={form.street_address} onChange={set("street_address")} placeholder="123 Main St" autoComplete="street-address" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input id="city" required value={form.city} onChange={set("city")} autoComplete="address-level2" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="state">State</Label>
                  <Input id="state" required value={form.state} onChange={set("state")} autoComplete="address-level1" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="zip">ZIP</Label>
                  <Input id="zip" required value={form.zip} onChange={set("zip")} autoComplete="postal-code" />
                </div>
              </div>
              <p className="text-[11px] text-muted-foreground">
                By signing up you agree to our <Link to="/legal/terms" className="underline">Terms</Link> and <Link to="/legal/community-guidelines" className="underline">Community Guidelines</Link>. To sell, you'll also accept the <Link to="/legal/seller-agreement" className="underline">Seller Agreement</Link>.
              </p>
            </>
          )}

          <Button type="submit" disabled={loading} className="w-full rounded-xl bg-gradient-primary hover:opacity-90 shadow-glow h-12 font-medium">
            {loading ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
          </Button>

          <button
            type="button"
            onClick={() => setMode(mode === "login" ? "signup" : "login")}
            className="block w-full text-center text-sm text-muted-foreground hover:text-foreground"
          >
            {mode === "login" ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Auth;
