import { Sparkles } from "lucide-react";
import { Link } from "react-router-dom";

export default function AIBanner() {
  return (
    <div className="bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-400 text-black">
      <Link
        to="/sell"
        className="max-w-7xl mx-auto px-6 py-2 flex items-center justify-center gap-2 text-sm font-semibold hover:opacity-90 transition"
      >
        <Sparkles className="w-4 h-4" />
        <span>
          The first AI-native marketplace — list any item in seconds, not hours.
        </span>
        <span className="hidden sm:inline underline">Try it →</span>
      </Link>
    </div>
  );
}
