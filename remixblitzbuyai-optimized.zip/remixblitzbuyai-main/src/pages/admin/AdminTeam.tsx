import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

const AdminTeam = () => {
  const { user: me } = useAuth();
  const { toast } = useToast();
  const [staff, setStaff] = useState<any[]>([]);
  const [invitations, setInvitations] = useState<any[]>([]);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"admin" | "support" | "moderator" | "report_generator">("support");

  const load = async () => {
    const { data: roles } = await supabase
      .from("user_roles")
      .select("user_id, role, created_at, profiles!inner(display_name, full_name)")
      .in("role", ["admin", "support", "moderator", "report_generator"]);
    setStaff(roles ?? []);
    const { data: inv } = await supabase
      .from("admin_invitations")
      .select("*")
      .is("accepted_at", null)
      .order("created_at", { ascending: false });
    setInvitations(inv ?? []);
  };
  useEffect(() => { load(); }, []);

  const invite = async () => {
    if (!email.trim() || !me) return;
    const token = crypto.randomUUID() + "-" + crypto.randomUUID();
    const expires = new Date(Date.now() + 7 * 24 * 3600_000).toISOString();
    const { error } = await supabase.from("admin_invitations").insert({
      email: email.toLowerCase().trim(), role, token, invited_by: me.id, expires_at: expires,
    });
    if (error) { toast({ title: "Failed", description: error.message, variant: "destructive" }); return; }
    const inviteUrl = `${window.location.origin}/admin/accept?token=${token}`;
    await navigator.clipboard.writeText(inviteUrl).catch(() => {});
    toast({ title: "Invitation created", description: "Link copied to clipboard. Send it to the new staff member." });
    setEmail("");
    load();
  };

  const revoke = async (userId: string, r: string) => {
    if (!me) return;
    if (!confirm(`Revoke ${r} role?`)) return;
    await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", r as "admin" | "moderator" | "support" | "report_generator" | "user");
    await supabase.from("audit_log").insert({ actor_id: me.id, action: "role.revoked", target_type: "user", target_id: userId, details: { role: r } });
    toast({ title: "Role revoked" });
    load();
  };

  return (
    <AdminLayout title="Team">
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="glass rounded-2xl p-5">
          <h3 className="font-display font-bold mb-3">Invite a new staff member</h3>
          <div className="space-y-3">
            <div>
              <Label>Email</Label>
              <Input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="newhire@example.com" />
            </div>
            <div>
              <Label>Role</Label>
              <Select value={role} onValueChange={(v: any) => setRole(v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin — full control</SelectItem>
                  <SelectItem value="moderator">Moderator — listings, bids, reports</SelectItem>
                  <SelectItem value="support">Support — tickets, view-only on the rest</SelectItem>
                  <SelectItem value="report_generator">Report Generator — exports only</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={invite} className="rounded-xl bg-gradient-primary shadow-glow">Generate invite link</Button>
            <p className="text-xs text-muted-foreground">The recipient creates an account, then accepts the invitation.</p>
          </div>

          {invitations.length > 0 && (
            <div className="mt-6">
              <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Pending</div>
              <div className="space-y-2">
                {invitations.map((i) => (
                  <div key={i.id} className="flex items-center justify-between text-sm p-2 rounded-lg bg-secondary/30">
                    <span>{i.email}</span>
                    <Badge variant="outline">{i.role}</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="glass rounded-2xl p-5">
          <h3 className="font-display font-bold mb-3">Active staff</h3>
          <div className="space-y-2">
            {staff.map((s: any) => (
              <div key={`${s.user_id}-${s.role}`} className="flex items-center justify-between text-sm p-3 rounded-lg bg-secondary/30">
                <div>
                  <div className="font-medium">{s.profiles?.display_name || s.profiles?.full_name || s.user_id.slice(0, 8)}</div>
                  <div className="text-xs text-muted-foreground capitalize">{s.role.replace("_", " ")}</div>
                </div>
                <Button size="sm" variant="outline" onClick={() => revoke(s.user_id, s.role)}>Revoke</Button>
              </div>
            ))}
            {staff.length === 0 && <div className="text-sm text-muted-foreground">No staff yet.</div>}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminTeam;
