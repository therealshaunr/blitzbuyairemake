
-- ============= ENUMS =============
CREATE TYPE public.app_role AS ENUM ('admin', 'support', 'report_generator', 'moderator', 'user');
CREATE TYPE public.account_status AS ENUM ('active', 'restricted', 'locked', 'disabled', 'banned');
CREATE TYPE public.listing_status AS ENUM ('draft', 'pending_review', 'approved', 'rejected', 'active', 'sold', 'expired', 'removed');
CREATE TYPE public.listing_type AS ENUM ('auction', 'buy_now', 'local');
CREATE TYPE public.nextgen_status AS ENUM ('none', 'active', 'canceled', 'past_due');
CREATE TYPE public.flag_severity AS ENUM ('info', 'warn', 'critical');
CREATE TYPE public.report_status AS ENUM ('open', 'investigating', 'resolved', 'dismissed');
CREATE TYPE public.ticket_status AS ENUM ('open', 'in_progress', 'waiting_user', 'resolved', 'closed');

-- ============= TIMESTAMP TRIGGER FUNCTION =============
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- ============= PROFILES =============
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  full_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  phone_e164 TEXT UNIQUE,
  phone_verified_at TIMESTAMPTZ,
  email_verified_at TIMESTAMPTZ,
  street_address TEXT,
  city TEXT,
  state TEXT,
  zip TEXT,
  country TEXT DEFAULT 'US',
  account_status public.account_status NOT NULL DEFAULT 'active',
  restriction_reason TEXT,
  restricted_until TIMESTAMPTZ,
  nextgen_status public.nextgen_status NOT NULL DEFAULT 'none',
  nextgen_renews_at TIMESTAMPTZ,
  nextgen_credit_cents INTEGER NOT NULL DEFAULT 0,
  unpaid_fee_balance_cents INTEGER NOT NULL DEFAULT 0,
  seller_agreement_accepted_at TIMESTAMPTZ,
  seller_agreement_version TEXT,
  seller_rating NUMERIC(3,2) DEFAULT 0,
  buyer_rating NUMERIC(3,2) DEFAULT 0,
  total_sales INTEGER DEFAULT 0,
  signup_ip TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============= USER ROLES =============
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  granted_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Security definer role checker (prevents recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.is_staff(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND role IN ('admin','support','moderator','report_generator')
  )
$$;

-- ============= ADMIN INVITATIONS =============
CREATE TABLE public.admin_invitations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  role public.app_role NOT NULL,
  token TEXT NOT NULL UNIQUE,
  invited_by UUID NOT NULL REFERENCES auth.users(id),
  expires_at TIMESTAMPTZ NOT NULL,
  accepted_at TIMESTAMPTZ,
  accepted_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_invitations ENABLE ROW LEVEL SECURITY;

-- ============= LISTINGS =============
CREATE TABLE public.listings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT,
  condition TEXT,
  tags TEXT[],
  listing_type public.listing_type NOT NULL DEFAULT 'buy_now',
  status public.listing_status NOT NULL DEFAULT 'draft',
  price_cents INTEGER,
  starting_bid_cents INTEGER,
  reserve_cents INTEGER,
  current_bid_cents INTEGER,
  current_bidder_id UUID REFERENCES auth.users(id),
  bid_count INTEGER NOT NULL DEFAULT 0,
  auction_ends_at TIMESTAMPTZ,
  auction_duration_days INTEGER,
  zip TEXT,
  city TEXT,
  state TEXT,
  ai_review_score NUMERIC(3,2),
  ai_review_notes TEXT,
  reviewed_by UUID REFERENCES auth.users(id),
  reviewed_at TIMESTAMPTZ,
  rejection_reason TEXT,
  view_count INTEGER NOT NULL DEFAULT 0,
  watch_count INTEGER NOT NULL DEFAULT 0,
  is_paused BOOLEAN NOT NULL DEFAULT false,
  pause_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_listings_status ON public.listings(status);
CREATE INDEX idx_listings_seller ON public.listings(seller_id);
CREATE INDEX idx_listings_type ON public.listings(listing_type);
CREATE INDEX idx_listings_ends ON public.listings(auction_ends_at) WHERE auction_ends_at IS NOT NULL;
CREATE TRIGGER trg_listings_updated BEFORE UPDATE ON public.listings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============= LISTING IMAGES =============
CREATE TABLE public.listing_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.listing_images ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_listing_images_listing ON public.listing_images(listing_id);

-- ============= BIDS =============
CREATE TABLE public.bids (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  bidder_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount_cents INTEGER NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  is_voided BOOLEAN NOT NULL DEFAULT false,
  void_reason TEXT,
  voided_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.bids ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_bids_listing ON public.bids(listing_id);
CREATE INDEX idx_bids_bidder ON public.bids(bidder_id);

-- ============= BID ANOMALY FLAGS =============
CREATE TABLE public.bid_anomaly_flags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  bid_id UUID REFERENCES public.bids(id) ON DELETE CASCADE,
  bidder_id UUID REFERENCES auth.users(id),
  flag_type TEXT NOT NULL,
  severity public.flag_severity NOT NULL DEFAULT 'info',
  details JSONB,
  resolved BOOLEAN NOT NULL DEFAULT false,
  resolved_by UUID REFERENCES auth.users(id),
  resolved_at TIMESTAMPTZ,
  resolution_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.bid_anomaly_flags ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_flags_listing ON public.bid_anomaly_flags(listing_id);
CREATE INDEX idx_flags_unresolved ON public.bid_anomaly_flags(resolved) WHERE resolved = false;

-- ============= CONVERSATIONS & MESSAGES =============
CREATE TABLE public.conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID REFERENCES public.listings(id) ON DELETE SET NULL,
  buyer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  seller_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  contact_unlocked BOOLEAN NOT NULL DEFAULT false,
  buyer_paid_unlock BOOLEAN NOT NULL DEFAULT false,
  seller_paid_unlock BOOLEAN NOT NULL DEFAULT false,
  last_message_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(listing_id, buyer_id, seller_id)
);
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  read_at TIMESTAMPTZ,
  is_system BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_messages_conv ON public.messages(conversation_id);

-- ============= PHONE OTPS =============
CREATE TABLE public.phone_otps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  phone_e164 TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  verified_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.phone_otps ENABLE ROW LEVEL SECURITY;

-- ============= SIGNUP ATTEMPTS (IP rate limiting) =============
CREATE TABLE public.signup_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address TEXT NOT NULL,
  email TEXT,
  success BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.signup_attempts ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_signup_ip ON public.signup_attempts(ip_address, created_at);

-- ============= DISPOSABLE EMAIL DOMAINS =============
CREATE TABLE public.disposable_email_domains (
  domain TEXT PRIMARY KEY,
  added_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.disposable_email_domains ENABLE ROW LEVEL SECURITY;

-- ============= DUPLICATE REVIEW QUEUE =============
CREATE TABLE public.duplicate_review_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  matched_user_id UUID REFERENCES auth.users(id),
  match_reason TEXT NOT NULL,
  match_details JSONB,
  reviewed BOOLEAN NOT NULL DEFAULT false,
  reviewed_by UUID REFERENCES auth.users(id),
  reviewed_at TIMESTAMPTZ,
  decision TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.duplicate_review_queue ENABLE ROW LEVEL SECURITY;

-- ============= REPORTS =============
CREATE TABLE public.reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reported_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  reported_listing_id UUID REFERENCES public.listings(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  description TEXT,
  evidence_url TEXT,
  status public.report_status NOT NULL DEFAULT 'open',
  assigned_to UUID REFERENCES auth.users(id),
  resolution_notes TEXT,
  action_taken TEXT,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_reports_updated BEFORE UPDATE ON public.reports
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============= AUDIT LOG =============
CREATE TABLE public.audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID REFERENCES auth.users(id),
  action TEXT NOT NULL,
  target_type TEXT,
  target_id UUID,
  details JSONB,
  ip_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_audit_actor ON public.audit_log(actor_id, created_at DESC);
CREATE INDEX idx_audit_target ON public.audit_log(target_type, target_id);

-- ============= SUPPORT TICKETS =============
CREATE TABLE public.support_tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  category TEXT,
  status public.ticket_status NOT NULL DEFAULT 'open',
  priority TEXT DEFAULT 'normal',
  assigned_to UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_tickets_updated BEFORE UPDATE ON public.support_tickets
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.support_ticket_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL REFERENCES public.support_tickets(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  is_staff_reply BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.support_ticket_messages ENABLE ROW LEVEL SECURITY;

-- ============= LEGAL AGREEMENTS =============
CREATE TABLE public.legal_agreements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doc_type TEXT NOT NULL,
  version TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  effective_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  is_current BOOLEAN NOT NULL DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(doc_type, version)
);
ALTER TABLE public.legal_agreements ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_agreement_acceptances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  agreement_id UUID NOT NULL REFERENCES public.legal_agreements(id),
  doc_type TEXT NOT NULL,
  version TEXT NOT NULL,
  signed_name TEXT,
  ip_address TEXT,
  user_agent TEXT,
  accepted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.user_agreement_acceptances ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_uaa_user ON public.user_agreement_acceptances(user_id);

-- ============= ACCOUNT ACTIONS =============
CREATE TABLE public.account_actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  performed_by UUID REFERENCES auth.users(id),
  action TEXT NOT NULL,
  reason TEXT NOT NULL,
  duration_days INTEGER,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.account_actions ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_account_actions_user ON public.account_actions(user_id, created_at DESC);

-- ============= AUTO-CREATE PROFILE TRIGGER =============
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name, full_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'full_name'
  );
  -- default user role
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============= RLS POLICIES =============

-- profiles
CREATE POLICY "Profiles public read" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Staff update any profile" ON public.profiles FOR UPDATE USING (public.is_staff(auth.uid()));

-- user_roles
CREATE POLICY "Users see own roles" ON public.user_roles FOR SELECT USING (auth.uid() = user_id OR public.is_staff(auth.uid()));
CREATE POLICY "Admins manage roles" ON public.user_roles FOR ALL USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- admin_invitations
CREATE POLICY "Admins manage invitations" ON public.admin_invitations FOR ALL USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Anyone can view invitation by token" ON public.admin_invitations FOR SELECT USING (true);

-- listings
CREATE POLICY "Public can view approved/active listings" ON public.listings FOR SELECT
  USING (status IN ('approved','active','sold','expired') OR seller_id = auth.uid() OR public.is_staff(auth.uid()));
CREATE POLICY "Sellers create own listings" ON public.listings FOR INSERT WITH CHECK (auth.uid() = seller_id);
CREATE POLICY "Sellers update own listings" ON public.listings FOR UPDATE USING (auth.uid() = seller_id OR public.is_staff(auth.uid()));
CREATE POLICY "Sellers delete own draft" ON public.listings FOR DELETE USING (auth.uid() = seller_id AND status = 'draft');
CREATE POLICY "Staff delete any listing" ON public.listings FOR DELETE USING (public.is_staff(auth.uid()));

-- listing_images
CREATE POLICY "Listing images visible if listing visible" ON public.listing_images FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.listings l WHERE l.id = listing_id
    AND (l.status IN ('approved','active','sold','expired') OR l.seller_id = auth.uid() OR public.is_staff(auth.uid())))
);
CREATE POLICY "Sellers manage own listing images" ON public.listing_images FOR ALL USING (
  EXISTS (SELECT 1 FROM public.listings l WHERE l.id = listing_id AND (l.seller_id = auth.uid() OR public.is_staff(auth.uid())))
) WITH CHECK (
  EXISTS (SELECT 1 FROM public.listings l WHERE l.id = listing_id AND (l.seller_id = auth.uid() OR public.is_staff(auth.uid())))
);

-- bids
CREATE POLICY "Bids visible to listing parties + staff" ON public.bids FOR SELECT USING (
  bidder_id = auth.uid() OR public.is_staff(auth.uid())
  OR EXISTS (SELECT 1 FROM public.listings l WHERE l.id = listing_id AND l.seller_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.listings l WHERE l.id = listing_id AND l.status IN ('active','sold','expired'))
);
CREATE POLICY "Users place own bids" ON public.bids FOR INSERT WITH CHECK (auth.uid() = bidder_id);
CREATE POLICY "Staff can void bids" ON public.bids FOR UPDATE USING (public.is_staff(auth.uid()));

-- bid_anomaly_flags
CREATE POLICY "Staff view all flags" ON public.bid_anomaly_flags FOR SELECT USING (public.is_staff(auth.uid()));
CREATE POLICY "Staff manage flags" ON public.bid_anomaly_flags FOR ALL USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

-- conversations
CREATE POLICY "Conversation parties access" ON public.conversations FOR SELECT USING (
  buyer_id = auth.uid() OR seller_id = auth.uid() OR public.is_staff(auth.uid())
);
CREATE POLICY "Users create own conversations" ON public.conversations FOR INSERT WITH CHECK (
  buyer_id = auth.uid() OR seller_id = auth.uid()
);
CREATE POLICY "Parties update own conversations" ON public.conversations FOR UPDATE USING (
  buyer_id = auth.uid() OR seller_id = auth.uid() OR public.is_staff(auth.uid())
);

-- messages
CREATE POLICY "Conversation parties read messages" ON public.messages FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id
    AND (c.buyer_id = auth.uid() OR c.seller_id = auth.uid() OR public.is_staff(auth.uid())))
);
CREATE POLICY "Conversation parties send messages" ON public.messages FOR INSERT WITH CHECK (
  sender_id = auth.uid() AND EXISTS (
    SELECT 1 FROM public.conversations c WHERE c.id = conversation_id
      AND (c.buyer_id = auth.uid() OR c.seller_id = auth.uid())
      AND c.contact_unlocked = true
  )
);

-- phone_otps
CREATE POLICY "Users see own otps" ON public.phone_otps FOR SELECT USING (auth.uid() = user_id);

-- signup_attempts (server-only)
CREATE POLICY "Staff view signup attempts" ON public.signup_attempts FOR SELECT USING (public.is_staff(auth.uid()));

-- disposable_email_domains
CREATE POLICY "Anyone can read blocklist" ON public.disposable_email_domains FOR SELECT USING (true);
CREATE POLICY "Admins manage blocklist" ON public.disposable_email_domains FOR ALL USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- duplicate_review_queue
CREATE POLICY "Staff view dup queue" ON public.duplicate_review_queue FOR SELECT USING (public.is_staff(auth.uid()));
CREATE POLICY "Staff manage dup queue" ON public.duplicate_review_queue FOR UPDATE USING (public.is_staff(auth.uid()));

-- reports
CREATE POLICY "Users create reports" ON public.reports FOR INSERT WITH CHECK (auth.uid() = reporter_id);
CREATE POLICY "Reporter sees own reports" ON public.reports FOR SELECT USING (auth.uid() = reporter_id OR public.is_staff(auth.uid()));
CREATE POLICY "Staff manage reports" ON public.reports FOR UPDATE USING (public.is_staff(auth.uid()));

-- audit_log
CREATE POLICY "Staff view audit log" ON public.audit_log FOR SELECT USING (public.is_staff(auth.uid()));

-- support_tickets
CREATE POLICY "Users see own tickets" ON public.support_tickets FOR SELECT USING (auth.uid() = user_id OR public.is_staff(auth.uid()));
CREATE POLICY "Users create own tickets" ON public.support_tickets FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own tickets" ON public.support_tickets FOR UPDATE USING (auth.uid() = user_id OR public.is_staff(auth.uid()));

-- support_ticket_messages
CREATE POLICY "Ticket parties read messages" ON public.support_ticket_messages FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.support_tickets t WHERE t.id = ticket_id
    AND (t.user_id = auth.uid() OR public.is_staff(auth.uid())))
);
CREATE POLICY "Ticket parties post messages" ON public.support_ticket_messages FOR INSERT WITH CHECK (
  sender_id = auth.uid() AND EXISTS (
    SELECT 1 FROM public.support_tickets t WHERE t.id = ticket_id
      AND (t.user_id = auth.uid() OR public.is_staff(auth.uid()))
  )
);

-- legal_agreements
CREATE POLICY "Anyone reads legal docs" ON public.legal_agreements FOR SELECT USING (true);
CREATE POLICY "Admins manage legal docs" ON public.legal_agreements FOR ALL USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- user_agreement_acceptances
CREATE POLICY "Users see own acceptances" ON public.user_agreement_acceptances FOR SELECT USING (auth.uid() = user_id OR public.is_staff(auth.uid()));
CREATE POLICY "Users record own acceptance" ON public.user_agreement_acceptances FOR INSERT WITH CHECK (auth.uid() = user_id);

-- account_actions
CREATE POLICY "User sees own actions" ON public.account_actions FOR SELECT USING (auth.uid() = user_id OR public.is_staff(auth.uid()));
CREATE POLICY "Staff create account actions" ON public.account_actions FOR INSERT WITH CHECK (public.is_staff(auth.uid()));

-- ============= STORAGE BUCKETS =============
INSERT INTO storage.buckets (id, name, public) VALUES ('listing-photos','listing-photos',true) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars','avatars',true) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('verification-docs','verification-docs',false) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('report-evidence','report-evidence',false) ON CONFLICT DO NOTHING;

-- listing photos
CREATE POLICY "Listing photos public read" ON storage.objects FOR SELECT USING (bucket_id = 'listing-photos');
CREATE POLICY "Authed upload listing photos" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'listing-photos' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Owners delete own listing photos" ON storage.objects FOR DELETE USING (bucket_id = 'listing-photos' AND auth.uid()::text = (storage.foldername(name))[1]);

-- avatars
CREATE POLICY "Avatars public read" ON storage.objects FOR SELECT USING (bucket_id = 'avatars');
CREATE POLICY "Users upload own avatar" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users update own avatar" ON storage.objects FOR UPDATE USING (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

-- verification docs (private)
CREATE POLICY "Users see own verify docs" ON storage.objects FOR SELECT USING (bucket_id = 'verification-docs' AND (auth.uid()::text = (storage.foldername(name))[1] OR public.is_staff(auth.uid())));
CREATE POLICY "Users upload own verify docs" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'verification-docs' AND auth.uid()::text = (storage.foldername(name))[1]);

-- report evidence (private)
CREATE POLICY "Reporter and staff see report evidence" ON storage.objects FOR SELECT USING (bucket_id = 'report-evidence' AND (auth.uid()::text = (storage.foldername(name))[1] OR public.is_staff(auth.uid())));
CREATE POLICY "Users upload report evidence" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'report-evidence' AND auth.uid()::text = (storage.foldername(name))[1]);

-- ============= SEED DATA =============
INSERT INTO public.disposable_email_domains (domain) VALUES
('mailinator.com'),('tempmail.com'),('temp-mail.org'),('guerrillamail.com'),('10minutemail.com'),
('throwawaymail.com'),('yopmail.com'),('trashmail.com'),('getnada.com'),('dispostable.com'),
('mintemail.com'),('mohmal.com'),('sharklasers.com'),('grr.la'),('spam4.me'),
('maildrop.cc'),('fakeinbox.com'),('mailcatch.com'),('tempinbox.com'),('emailondeck.com'),
('moakt.com'),('tempr.email'),('mvrht.com'),('inboxbear.com'),('mytemp.email'),
('crazymailing.com'),('emltmp.com'),('throwaway.email'),('tmpmail.org'),('tmpeml.com'),
('rootfest.net'),('33mail.com'),('anonbox.net'),('byom.de'),('chacuo.net'),
('cuvox.de'),('deadaddress.com'),('discard.email'),('dropmail.me'),('emkei.cz'),
('fake-mail.net'),('grandmamail.com'),('harakirimail.com'),('imails.info'),('jetable.org'),
('koszmail.pl'),('letthemeatspam.com'),('mailnesia.com'),('mailtemp.info'),('nwldx.com'),
('owlpic.com'),('pokemail.net'),('quickinbox.com'),('rcpt.at'),('sneakemail.com'),
('spamgourmet.com'),('tempemail.net'),('thankyou2010.com'),('tradermail.info'),('wegwerfmail.de'),
('zetmail.com')
ON CONFLICT DO NOTHING;

-- Initial legal docs
INSERT INTO public.legal_agreements (doc_type, version, title, body) VALUES
('terms_of_service', '1.0.0', 'AuraSellAI Terms of Service',
'Welcome to AuraSellAI. By accessing or using our marketplace, you agree to these Terms of Service ("Terms"). Please read them carefully.

1. ELIGIBILITY: You must be at least 18 years old, legally capable of entering into binding contracts, and not prohibited from using AuraSellAI under applicable law.

2. ONE ACCOUNT PER PERSON: Each individual is permitted one account. Multiple accounts may be detected via email, phone, address, device fingerprint, and behavioral analysis. Duplicate or fraudulent accounts will be terminated.

3. ACCURATE INFORMATION: You agree to provide true, current, and complete information during registration and to keep your information updated. Misrepresentation is grounds for account termination.

4. PROHIBITED CONDUCT: You agree NOT to: shill bid (bid on your own listings or coordinate bids to inflate prices); harass, defraud, or threaten other users; list prohibited items (weapons, drugs, counterfeits, stolen goods, hazardous materials, regulated items, adult content, hate material, live animals, recalled products); circumvent platform fees by transacting off-platform; use bots, scrapers, or automated tools without permission; impersonate others; infringe intellectual property; engage in money laundering or sanctions evasion.

5. INTELLECTUAL PROPERTY: You retain ownership of content you submit but grant AuraSellAI a worldwide, royalty-free license to use, display, and distribute it in connection with the service.

6. AI-GENERATED LISTINGS: AuraSellAI uses AI to assist with listing creation and pricing. You remain solely responsible for the accuracy and legality of your listings, regardless of AI assistance.

7. PAYMENTS, FEES, AND TAXES: Fees are disclosed at checkout. You are responsible for any taxes arising from your transactions. AuraSellAI may withhold or report tax information as required by law.

8. DISPUTES: Buyer-seller disputes should first be resolved between parties. AuraSellAI may mediate at its sole discretion but is not a party to user transactions.

9. ACCOUNT TERMINATION: We may restrict, lock, disable, or permanently ban accounts that violate these Terms, our Community Guidelines, or applicable law. Banned users forfeit access and may have listings removed.

10. INDEMNIFICATION: You agree to indemnify and hold AuraSellAI harmless from any claims arising from your use of the service or violation of these Terms.

11. DISCLAIMERS: The service is provided "AS IS" without warranties of any kind. AuraSellAI does not guarantee the quality, safety, or legality of items listed.

12. LIMITATION OF LIABILITY: To the maximum extent permitted by law, AuraSellAI shall not be liable for indirect, incidental, special, or consequential damages.

13. ARBITRATION: Disputes between you and AuraSellAI shall be resolved by binding arbitration on an individual basis. You waive class-action rights.

14. GOVERNING LAW: These Terms are governed by the laws of the State of Delaware, USA.

15. CHANGES: We may update these Terms; continued use after notice constitutes acceptance.

By creating an account, you acknowledge that you have read, understood, and agree to be bound by these Terms.'),

('seller_agreement', '1.0.0', 'AuraSellAI Seller Agreement',
'This Seller Agreement governs your activity as a seller on AuraSellAI. It supplements the Terms of Service.

1. SELLER CONDUCT: As a seller you agree to:
- Accurately describe items, including condition, defects, and provenance
- Use genuine photographs of the actual item being sold
- Honor all sales at the listed/winning price
- Ship items promptly and as described
- Not engage in bait-and-switch tactics

2. PROHIBITED LISTINGS: The following are strictly prohibited and will result in listing removal and possible account action:
- Weapons, firearms, ammunition, explosives
- Illegal drugs, controlled substances, drug paraphernalia
- Counterfeit goods, replicas misrepresented as authentic
- Stolen property
- Hazardous materials, recalled products
- Live animals, ivory, endangered species products
- Human remains or body parts
- Adult/sexual content
- Hate or extremist material
- Tobacco, vaping products to minors
- Prescription medications
- Items violating IP rights (unauthorized brand replicas, pirated media)
- Personal information / identity documents
- Lottery tickets, gambling devices in restricted jurisdictions
- Regulated financial instruments

3. SHILL BIDDING & PRICE MANIPULATION: You will not bid on your own listings, coordinate with others to inflate prices, create secondary accounts to bid, or use bots. Detected manipulation results in immediate listing cancellation, fee penalty, and possible permanent ban.

4. LISTING REVIEW: All listings are submitted for review (AI-assisted and/or human). AuraSellAI may reject, edit, or remove listings at its sole discretion.

5. FEES: Sellers pay 5% of final sale price (4.5% for NextGen members). Fees are deducted from payouts. Unpaid fee balances over $25 will result in suspension of new listings.

6. LOCAL PICKUP: For local pickup listings, both buyer and seller pay an unlock fee before contact information is exchanged. AuraSellAI is not responsible for in-person transactions.

7. PAYOUTS: Payouts are processed via Stripe. You must complete identity verification (KYC) for payouts. Funds may be held during dispute investigation.

8. RETURNS & DISPUTES: You agree to good-faith resolution of buyer disputes. Failure to respond within 72 hours may result in automatic refund.

9. TAX RESPONSIBILITY: You are solely responsible for collecting and remitting any taxes on your sales. AuraSellAI may issue 1099-K forms as required by US law.

10. AGE VERIFICATION: You confirm you are at least 18 years old.

11. ACCOUNT ACTION GROUNDS: Your seller account may be RESTRICTED (no new sales), LOCKED (read-only), DISABLED (cannot log in), or BANNED (permanent + IP/email/phone blocklist) for: shill bidding, prohibited items, fraud, repeated buyer complaints, unpaid fees, fake reviews, harassment, off-platform transactions, identity fraud, or any breach of this Agreement.

12. INDEMNIFICATION: You indemnify AuraSellAI from any claims arising from items you sell, your conduct, or violations of law or this Agreement.

By signing below you confirm you have read, understood, and agree to comply with this Seller Agreement, the Terms of Service, the Community Guidelines, and the Prohibited Items policy.'),

('community_guidelines', '1.0.0', 'AuraSellAI Community Guidelines',
'Our community thrives on trust, fairness, and respect. These Guidelines apply to all users.

1. RESPECT: Treat every user with respect. No harassment, hate speech, threats, or discrimination based on race, gender, religion, sexual orientation, disability, or any protected characteristic.

2. HONESTY: Be honest in your dealings. No fake reviews, no misleading listings, no impersonation.

3. SAFETY: Meet in public places for local pickups. Bring a friend. Trust your gut. Report unsafe behavior.

4. FAIR PLAY: No shill bidding, no coordinated manipulation, no fee evasion.

5. PRIVACY: Do not share other users private information without consent.

6. REPORTING: If you see something, say something. Use the in-app report function.

Violations may result in account warnings, restrictions, or permanent bans.'),

('prohibited_items', '1.0.0', 'AuraSellAI Prohibited Items',
'The following items may NEVER be listed on AuraSellAI. Listing prohibited items will result in immediate removal and may lead to account termination.

WEAPONS: Firearms, ammunition, explosives, switchblades, brass knuckles, stun guns where regulated, replicas designed to deceive.

DRUGS & PARAPHERNALIA: Illegal drugs, controlled substances, prescription medications, drug paraphernalia, kratom in restricted states.

COUNTERFEITS & IP VIOLATIONS: Replicas, knockoffs, unauthorized reproductions, pirated media, bootleg recordings.

HAZARDOUS MATERIALS: Asbestos, lead paint, radioactive materials, pesticides, fireworks, batteries that fail shipping rules.

ANIMALS & ANIMAL PRODUCTS: Live animals, ivory, endangered species, hides of protected species.

HUMAN REMAINS: Bones, organs, body parts.

ADULT CONTENT: Pornography, sexual services, used intimate items.

HATE MATERIAL: Nazi memorabilia (some historical exceptions may apply with documentation), KKK material, content promoting violence against groups.

REGULATED ITEMS: Tobacco/vapes (online sale restricted), alcohol (cross-state restricted), prescription glasses without scrip, lottery tickets, gambling devices, financial instruments, lock-picking tools where illegal.

PERSONAL DATA: Identity documents (passports, driver licenses, SSN cards), credit cards, financial account info, mailing lists with personal data.

STOLEN PROPERTY: Anything you do not have legal title to sell.

RECALLED PRODUCTS: Items subject to active safety recalls.

DIGITAL GOODS LIMITS: No malware, hacking tools intended for illegal use, account sales for other platforms, fake reviews.

This list is non-exhaustive. AuraSellAI reserves the right to remove any listing at its sole discretion.');
