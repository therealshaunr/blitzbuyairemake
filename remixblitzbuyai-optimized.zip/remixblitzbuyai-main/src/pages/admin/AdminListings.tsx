import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

const AdminListings = () => {
  const { user: me } = useAuth();
  const [items, setItems] = useState<any[]>([]);
  const [target, setTarget] = useState<any | null>(null);
  const [reason, setReason] = useState("");
  const { toast } = useToast();

  const load = async () => {
    const { data } = await supabase
      .from("listings")
      .select("id,title,description,category,price_cents,seller_id,created_at,ai_review_score,ai_review_notes")
      .eq("status", "pending_review")
      .order("created_at", { ascending: true })
      .limit(50);
    setItems(data ?? []);
  };

  useEffect(() => { load(); }, []);

  const decide = async (id: string, approve: boolean) => {
    if (!me) return;
    if (!approve && !reason.trim()) return;
    const { error } = await supabase.from("listings").update({
      status: approve ? "active" : "rejected",
      reviewed_by: me.id,
      reviewed_at: new Date().toISOString(),
      rejection_reason: approve ? null : reason,
    }).eq("id", id);
    if (error) { toast({ title: "Failed", description: error.message, variant: "destructive" }); return; }
    await supabase.from("audit_log").insert({
      actor_id: me.id, action: approve ? "listing.approved" : "listing.rejected",
      target_type: "listing", target_id: id, details: approve ? null : { reason },
    });
    toast({ title: approve ? "Approved" : "Rejected" });
    setTarget(null); setReason("");
    load();
  };

  return (
    <AdminLayout title="Listings Review Queue">
      <div className="space-y-3">
        {items.map((l) => (
          <div key={l.id} className="glass rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <Badge variant="outline">{l.category || "Uncategorized"}</Badge>
                {l.ai_review_score != null && <Badge className={l.ai_review_score < 0.5 ? "bg-destructive/20 text-destructive border-destructive/40" : "bg-success/15 text-success border-success/40"}>AI {Math.round(l.ai_review_score * 100)}%</Badge>}
              </div>
              <div className="font-display font-semibold">{l.title}</div>
              <p className="text-sm text-muted-foreground line-clamp-2">{l.description}</p>
              {l.ai_review_notes && <p className="text-xs text-warning mt-1">⚠ {l.ai_review_notes}</p>}
              <div className="text-xs text-muted-foreground mt-2">
                ${((l.price_cents ?? 0) / 100).toFixed(2)} · submitted {new Date(l.created_at).toLocaleString()}
              </div>
            </div>
            <div className="flex sm:flex-col gap-2 shrink-0">
              <Button size="sm" className="bg-success text-success-foreground" onClick={() => decide(l.id, true)}>Approve</Button>
              <Button size="sm" variant="outline" onClick={() => setTarget(l)}>Reject</Button>
            </div>
          </div>
        ))}
        {items.length === 0 && (
          <div className="glass rounded-2xl p-10 text-center text-muted-foreground">Queue is empty. Nice work.</div>
        )}
      </div>

      <Dialog open={!!target} onOpenChange={(o) => !o && setTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject "{target?.title}"</DialogTitle>
          </DialogHeader>
          <Label>Reason (sent to seller)</Label>
          <Textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={4} placeholder="e.g. Photos look like stock images. Please re-upload originals." />
          <DialogFooter>
            <Button variant="outline" onClick={() => setTarget(null)}>Cancel</Button>
            <Button className="bg-destructive text-destructive-foreground" disabled={!reason.trim()} onClick={() => decide(target.id, false)}>Reject listing</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
};

export default AdminListings;
