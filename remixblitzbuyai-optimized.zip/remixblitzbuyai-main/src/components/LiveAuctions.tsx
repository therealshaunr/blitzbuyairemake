import { Clock, Flame, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const auctions = [
  { id: 1, title: "Vintage Leica M6 Film Camera", bid: 1240, bids: 23, ends: "00:14:22", tag: "Hot", img: "📷" },
  { id: 2, title: "Air Jordan 1 Retro High OG", bid: 385, bids: 17, ends: "01:42:08", tag: "Trending", img: "👟" },
  { id: 3, title: "MacBook Pro M3 14\" 1TB", bid: 1850, bids: 42, ends: "00:03:54", tag: "Ending", img: "💻" },
  { id: 4, title: "PSA 10 Charizard Holo 1999", bid: 4200, bids: 89, ends: "02:19:30", tag: "Hot", img: "🃏" },
];

const tagStyle: Record<string, string> = {
  Hot: "bg-destructive/15 text-destructive border-destructive/30",
  Trending: "bg-accent/15 text-accent border-accent/30",
  Ending: "bg-warning/15 text-warning border-warning/30",
};

const tagIcon: Record<string, typeof Flame> = {
  Hot: Flame,
  Trending: TrendingUp,
  Ending: Clock,
};

const LiveAuctions = () => {
  return (
    <section className="py-16 sm:py-24 relative">
      <div className="container">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-8 sm:mb-10">
          <div>
            <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 mb-3 sm:mb-4">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-destructive"></span>
              </span>
              <span className="text-xs font-medium text-muted-foreground">Live now</span>
            </div>
            <h2 className="font-display text-3xl sm:text-5xl font-bold">
              Ending <span className="text-gradient-brand">soon</span>
            </h2>
          </div>
          <Link to="/browse?type=auction">
            <Button variant="outline" className="rounded-xl glass h-11">View all</Button>
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
          {auctions.map((a) => {
            const Icon = tagIcon[a.tag];
            return (
              <Link
                key={a.id}
                to={`/listing/${a.id}`}
                className="glass rounded-2xl p-3 sm:p-5 group hover:border-primary/40 transition-all hover:-translate-y-1 shadow-card active:scale-[0.98]"
              >
                <div className="relative mb-3 sm:mb-4">
                  <div className="absolute inset-0 bg-gradient-primary opacity-30 blur-2xl rounded-xl group-hover:opacity-60 transition-opacity" />
                  <div className="relative aspect-square rounded-xl bg-gradient-glass border border-primary/20 grid place-items-center text-5xl sm:text-6xl overflow-hidden ring-1 ring-primary/20 group-hover:ring-primary/50 group-hover:shadow-glow transition-all">
                    <span className="group-hover:scale-110 transition-transform duration-500">{a.img}</span>
                    <div className={`absolute top-2 left-2 sm:top-3 sm:left-3 inline-flex items-center gap-1 px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-full border text-[10px] sm:text-xs font-medium ${tagStyle[a.tag]}`}>
                      <Icon className="h-3 w-3" />
                      {a.tag}
                    </div>
                  </div>
                </div>
                <h3 className="font-display font-semibold text-sm sm:text-base mb-2 sm:mb-3 line-clamp-2 min-h-[2.5rem] sm:min-h-[3rem]">{a.title}</h3>
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-[10px] sm:text-xs text-muted-foreground">Current bid</div>
                    <div className="font-display font-bold text-base sm:text-lg text-gradient truncate">${a.bid.toLocaleString()}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] sm:text-xs text-muted-foreground">{a.bids} bids</div>
                    <div className="font-mono text-xs sm:text-sm text-warning">{a.ends}</div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default LiveAuctions;
