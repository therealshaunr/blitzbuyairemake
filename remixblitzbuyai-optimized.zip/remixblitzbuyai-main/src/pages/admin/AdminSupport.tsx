import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";

const AdminSupport = () => {
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("support_tickets")
        .select("*")
        .in("status", ["open", "in_progress", "waiting_user"])
        .order("created_at", { ascending: false })
        .limit(100);
      setItems(data ?? []);
    })();
  }, []);

  return (
    <AdminLayout title="Support Tickets">
      <div className="space-y-3">
        {items.map((t) => (
          <div key={t.id} className="glass rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline">{t.category || "general"}</Badge>
              <Badge>{t.status}</Badge>
              <Badge variant="outline">{t.priority}</Badge>
              <span className="text-xs text-muted-foreground ml-auto">{new Date(t.created_at).toLocaleString()}</span>
            </div>
            <div className="font-display font-semibold">{t.subject}</div>
            <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{t.body}</p>
          </div>
        ))}
        {items.length === 0 && <div className="glass rounded-2xl p-10 text-center text-muted-foreground">Inbox zero. Beautiful.</div>}
      </div>
    </AdminLayout>
  );
};

export default AdminSupport;
