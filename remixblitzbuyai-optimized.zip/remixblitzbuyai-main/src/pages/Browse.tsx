import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Search, Gavel, MapPin, Package, Sparkles } from "lucide-react";
import Navbar from "@/components/Navbar";
import BottomTabBar from "@/components/BottomTabBar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";

type Row = {
  id: string;
  title: string;
  price_cents: number | null;
  current_bid_cents: number | null;
  starting_bid_cents: number | null;
  listing_type: "buy_now" | "auction" | "local";
  status: string;
  city: string | null;
  state: string | null;
  auction_ends_at: string | null;
  ai_assist_enabled: boolean;
  listing_images?: { url: string; position: number }[];
};

const PAGE_SIZE = 24;
const dollar = (cents: number | null) => (cents == null ? "\u2014" : `$${(cents / 100).toFixed(2)}`);

const Browse = () => {
  const [params, setParams] = useSearchParams();
  const [rows, setRows] = useState<Row[]>([]);
  const [q, setQ] = useState(params.get("q") ?? "");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const type = params.get("type");
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();

  const fetchListings = useCallback(async (search: string, listingType: string | null, offset = 0) => {
    setLoading(true);
    setError(null);
    let query = supabase
      .from("listings")
      .select("id,title,price_cents,current_bid_cents,starting_bid_cents,listing_type,status,city,state,auction_ends_at,ai_assist_enabled,listing_images(url,position)")
      .in("status", ["approved", "active"])
      .order("created_at", { ascending: false })
      .range(offset, offset + PAGE_SIZE - 1);

    if (listingType === "auction") query = query.eq("listing_type", "auction");
    if (listingType === "local") query = query.eq("listing_type", "local");

    // Server-side search instead of client-side filtering
    const needle = search.trim();
    if (needle) query = query.ilike("title", `%${needle}%`);

    const { data, error: err } = await query;
    if (err) {
      setError("Failed to load listings. Please try again.");
      setLoading(false);
      return;
    }
    const results = (data as Row[]) ?? [];
    if (offset === 0) {
      setRows(results);
    } else {
      setRows((prev) => [...prev, ...results]);
    }
    setHasMore(results.length === PAGE_SIZE);
    setLoading(false);
  }, []);

  // Refetch when type filter changes
  useEffect(() => {
    fetchListings(q, type);
  }, [type, fetchListings]); // eslint-disable-line react-hooks/exhaustive-deps

  // Debounced search (350ms after user stops typing)
  const handleSearch = (value: string) => {
    setQ(value);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      fetchListings(value, type);
    }, 350);
  };

  const loadMore = () => fetchListings(q, type, rows.length);

  const setType = (t: string | null) => {
    const next = new URLSearchParams(params);
    if (t) next.set("type", t); else next.delete("type");
    setParams(next, { replace: true });
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-24 pb-28 md:pb-12">
        <div className="container">
          <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
            <h1 className="font-display text-3xl sm:text-4xl font-bold">
              Browse the <span className="text-gradient-brand">Blitz</span>
            </h1>
            <Badge className="bg-yellow-400/15 text-yellow-400 border-yellow-400/30">
              <Sparkles className="h-3 w-3 mr-1" /> AI-curated marketplace
            </Badge>
          </div>

          <div className="glass rounded-2xl p-3 mb-5 flex flex-wrap gap-2 items-center">
            <div className="relative flex-1 min-w-[220px]">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input value={q} onChange={(e) => handleSearch(e.target.value)} placeholder="Search listings..." className="pl-9 rounded-xl" />
            </div>
            <div className="flex gap-1.5">
              <Chip active={!type} onClick={() => setType(null)}>All</Chip>
              <Chip active={type === "auction"} onClick={() => setType("auction")}><Gavel className="h-3 w-3" /> Auctions</Chip>
              <Chip active={type === "local"} onClick={() => setType("local")}><MapPin className="h-3 w-3" /> Local</Chip>
            </div>
          </div>

          {error && (
            <div className="glass rounded-2xl p-6 text-center text-red-400 mb-5">
              {error}
              <Button variant="ghost" className="ml-3" onClick={() => fetchListings(q, type)}>Retry</Button>
            </div>
          )}

          {loading && rows.length === 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="glass rounded-2xl aspect-[4/5] animate-pulse" />
              ))}
            </div>
          ) : !error && rows.length === 0 ? (
            <div className="glass rounded-2xl p-12 text-center">
              <Package className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
              <div className="font-display font-semibold">No listings yet</div>
              <p className="text-sm text-muted-foreground mt-1">Be the first — list something with AI in seconds.</p>
              <Link to="/sell" className="inline-block mt-4">
                <Button className="rounded-xl bg-gradient-primary shadow-glow"><Sparkles className="h-4 w-4" /> Sell with AI</Button>
              </Link>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                {rows.map((r) => {
                  const cover = (r.listing_images ?? []).sort((a, b) => a.position - b.position)[0]?.url;
                  const price = r.listing_type === "auction" ? (r.current_bid_cents ?? r.starting_bid_cents) : r.price_cents;
                  return (
                    <Link key={r.id} to={`/l/${r.id}`} className="group glass rounded-2xl overflow-hidden hover:ring-1 hover:ring-yellow-400/40 transition">
                      <div className="aspect-[4/3] bg-muted relative overflow-hidden">
                        {cover ? (
                          <img src={cover} alt={r.title} className="h-full w-full object-cover group-hover:scale-105 transition-transform" loading="lazy" />
                        ) : (
                          <div className="h-full w-full grid place-items-center text-muted-foreground"><Package className="h-8 w-8" /></div>
                        )}
                        {r.listing_type === "auction" && (
                          <Badge className="absolute top-2 left-2 bg-yellow-400 text-black border-0"><Gavel className="h-3 w-3 mr-1" />Auction</Badge>
                        )}
                        {r.listing_type === "local" && (
                          <Badge className="absolute top-2 left-2 bg-emerald-500 text-white border-0"><MapPin className="h-3 w-3 mr-1" />Local</Badge>
                        )}
                        {r.ai_assist_enabled && (
                          <Badge className="absolute top-2 right-2 bg-black/70 text-yellow-400 border-yellow-400/30"><Sparkles className="h-3 w-3" /></Badge>
                        )}
                      </div>
                      <div className="p-3">
                        <div className="text-sm font-medium line-clamp-1">{r.title}</div>
                        <div className="flex items-center justify-between mt-1">
                          <div className="font-display font-bold text-gradient-brand">{dollar(price)}</div>
                          {r.city && <div className="text-[11px] text-muted-foreground truncate">{r.city}{r.state ? `, ${r.state}` : ""}</div>}
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
              {hasMore && (
                <div className="mt-6 text-center">
                  <Button variant="outline" className="rounded-xl" onClick={loadMore} disabled={loading}>
                    {loading ? "Loading..." : "Load more"}
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </main>
      <BottomTabBar />
    </div>
  );
};

const Chip = ({ active, onClick, children }: { active?: boolean; onClick: () => void; children: React.ReactNode }) => (
  <button
    onClick={onClick}
    className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm transition ${
      active ? "bg-yellow-400 text-black" : "glass text-muted-foreground hover:text-foreground"
    }`}
  >
    {children}
  </button>
);

export default Browse;
