import { Link } from "react-router-dom";
import { Sparkles, Search, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

const Navbar = () => {
  const { user, loading } = useAuth();
  const isAuthed = !loading && !!user;

  return (
    <header className="fixed top-0 inset-x-0 z-50 pt-[env(safe-area-inset-top)]">
      <div className="container mt-3 sm:mt-4">
        <nav className="glass rounded-2xl px-3 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between shadow-card">
          <Link to="/" className="flex items-center gap-2 group min-w-0">
            <div className="relative h-9 w-9 shrink-0 rounded-xl bg-gradient-primary grid place-items-center shadow-glow group-hover:scale-105 transition-transform">
              <Sparkles className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-display font-bold text-base sm:text-lg tracking-tight truncate">
              Blitz<span className="text-gradient-brand">Buy.AI</span>
            </span>
          </Link>

          {isAuthed && (
            <div className="hidden md:flex items-center gap-1">
              <Link to="/browse" className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">Browse</Link>
              <Link to="/browse?type=auction" className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">Auctions</Link>
              <Link to="/browse?type=local" className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">Local</Link>
              <Link to="/messages" className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">Messages</Link>
            </div>
          )}

          <div className="flex items-center gap-1.5 sm:gap-2">
            {isAuthed ? (
              <>
                <Button variant="ghost" size="icon" className="h-11 w-11 rounded-xl" aria-label="Search">
                  <Search className="h-4 w-4" />
                </Button>
                <Link to="/account">
                  <Button variant="ghost" size="icon" className="h-11 w-11 rounded-xl" aria-label="Account">
                    <User className="h-4 w-4" />
                  </Button>
                </Link>
                <Link to="/sell" className="hidden sm:inline-flex">
                  <Button className="rounded-xl bg-gradient-primary hover:opacity-90 shadow-glow font-medium">
                    <Sparkles className="h-4 w-4" />
                    Sell with AI
                  </Button>
                </Link>
              </>
            ) : (
              <>
                <Link to="/auth">
                  <Button variant="ghost" className="rounded-xl text-sm font-medium hidden sm:inline-flex">
                    Sign in
                  </Button>
                </Link>
                <Link to="/auth">
                  <Button className="rounded-xl bg-gradient-primary hover:opacity-90 shadow-glow font-medium">
                    <Sparkles className="h-4 w-4" />
                    Join the Blitz
                  </Button>
                </Link>
              </>
            )}
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
