import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, Package, ShoppingBag, Gavel, Heart, MessageCircle, Star, Wallet, Settings, LogOut, Sparkles, AlertTriangle,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import BottomTabBar from "@/components/BottomTabBar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";

const Account = () => {
  const { user, profile, isStaff, signOut, loading } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({ active: 0, sold: 0, pending: 0, bids: 0 });

  useEffect(() => {
    if (!loading && !user) navigate("/auth");
  }, [user, loading, navigate]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [{ count: active }, { count: sold }, { count: pending }, { count: bids }] = await Promise.all([
        supabase.from("listings").select("*", { count: "exact", head: true }).eq("seller_id", user.id).in("status", ["active", "approved"]),
        supabase.from("listings").select("*", { count: "exact", head: true }).eq("seller_id", user.id).eq("status", "sold"),
        supabase.from("listings").select("*", { count: "exact", head: true }).eq("seller_id", user.id).eq("status", "pending_review"),
        supabase.from("bids").select("*", { count: "exact", head: true }).eq("bidder_id", user.id),
      ]);
      setStats({ active: active ?? 0, sold: sold ?? 0, pending: pending ?? 0, bids: bids ?? 0 });
    })();
  }, [user]);

  if (loading || !user || !profile) {
    return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;
  }

  const dollar = (cents: number) => `$${(cents / 100).toFixed(2)}`;
  const restricted = profile.account_status !== "active";

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-24 pb-28 md:pb-12">
        <div className="container">
          {restricted && (
            <div className="glass-strong border-warning/40 rounded-2xl p-4 mb-6 flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-warning shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="font-display font-semibold capitalize">Account {profile.account_status}</div>
                <p className="text-sm text-muted-foreground">{profile.restriction_reason || "Contact support for details."}</p>
              </div>
            </div>
          )}

          <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
            <div>
              <h1 className="font-display text-3xl sm:text-4xl font-bold">
                Hey, <span className="text-gradient-brand">{profile.display_name || "there"}</span>
              </h1>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                {profile.nextgen_status === "active" && (
                  <Badge className="bg-gradient-primary text-primary-foreground border-0">
                    <Sparkles className="h-3 w-3 mr-1" /> NextGen Member
                  </Badge>
                )}
                {!profile.phone_verified_at && <Badge variant="outline">Phone unverified</Badge>}
                {isStaff && (
                  <Link to="/admin">
                    <Badge className="bg-accent/20 text-accent border-accent/40 cursor-pointer">Staff Portal →</Badge>
                  </Link>
                )}
              </div>
            </div>
            <div className="flex gap-2">
              <Link to="/sell">
                <Button className="rounded-xl bg-gradient-primary shadow-glow h-11">
                  <Sparkles className="h-4 w-4" /> List item
                </Button>
              </Link>
              <Button variant="outline" onClick={signOut} className="rounded-xl glass h-11">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* KPI cards */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
            <Stat label="Active" value={stats.active} />
            <Stat label="Sold" value={stats.sold} />
            <Stat label="Pending review" value={stats.pending} />
            <Stat label="Active bids" value={stats.bids} />
            <Stat label="Fee balance" value={dollar(profile.unpaid_fee_balance_cents)} sub={profile.unpaid_fee_balance_cents > 2500 ? "Over $25 cap" : ""} alert={profile.unpaid_fee_balance_cents > 2500} />
          </div>

          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="glass rounded-xl flex w-full overflow-x-auto justify-start gap-1 p-1 h-auto">
              <Tab value="overview" icon={LayoutDashboard} label="Overview" />
              <Tab value="selling" icon={Package} label="Selling" />
              <Tab value="buying" icon={ShoppingBag} label="Buying" />
              <Tab value="bids" icon={Gavel} label="Bids" />
              <Tab value="watchlist" icon={Heart} label="Saved" />
              <Tab value="messages" icon={MessageCircle} label="Messages" />
              <Tab value="reviews" icon={Star} label="Reviews" />
              <Tab value="wallet" icon={Wallet} label="Wallet" />
              <Tab value="settings" icon={Settings} label="Settings" />
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              <div className="glass rounded-2xl p-6">
                <h3 className="font-display font-bold text-lg mb-3">Welcome to BlitzBuy.AI</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Verify your phone & email to unlock selling, then snap a photo to create your first AI listing.
                </p>
                <div className="grid sm:grid-cols-2 gap-3">
                  <Checklist done={!!profile.email_verified_at || !!user.email_confirmed_at} label="Verify email" />
                  <Checklist done={!!profile.phone_verified_at} label="Verify phone (SMS)" />
                  <Checklist done={!!profile.seller_agreement_accepted_at} label="Sign Seller Agreement" />
                  <Checklist done={profile.nextgen_status === "active"} label="Upgrade to NextGen" />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="selling" className="mt-6"><Empty title="Your listings live here" hint="Start with the Sell button above." /></TabsContent>
            <TabsContent value="buying" className="mt-6"><Empty title="Your purchases will show up here" /></TabsContent>
            <TabsContent value="bids" className="mt-6"><Empty title="No active bids" /></TabsContent>
            <TabsContent value="watchlist" className="mt-6"><Empty title="Save listings to watch them" /></TabsContent>
            <TabsContent value="messages" className="mt-6"><Empty title="No messages yet" /></TabsContent>
            <TabsContent value="reviews" className="mt-6"><Empty title="Complete a sale or purchase to leave/receive reviews" /></TabsContent>
            <TabsContent value="wallet" className="mt-6">
              <div className="glass rounded-2xl p-6 grid sm:grid-cols-3 gap-6">
                <div>
                  <div className="text-xs text-muted-foreground">Unpaid fees</div>
                  <div className="font-display font-bold text-2xl">{dollar(profile.unpaid_fee_balance_cents)}</div>
                  <div className="text-xs text-muted-foreground mt-1">Cap: $25</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">NextGen credit</div>
                  <div className="font-display font-bold text-2xl text-gradient">{dollar(profile.nextgen_credit_cents)}</div>
                  <div className="text-xs text-muted-foreground mt-1">For subscription / donations</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Membership</div>
                  <div className="font-display font-bold text-2xl capitalize">{profile.nextgen_status === "none" ? "Free" : profile.nextgen_status}</div>
                  <div className="text-xs text-muted-foreground mt-1">{profile.nextgen_status === "active" ? "0.5% fee discount" : "$9.99/mo to upgrade"}</div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="settings" className="mt-6">
              <div className="glass rounded-2xl p-6 space-y-3 text-sm">
                <Row label="Email" value={user.email ?? ""} />
                <Row label="Display name" value={profile.display_name ?? "—"} />
                <Row label="Full name" value={profile.full_name ?? "—"} />
                <Row label="Phone" value={profile.phone_verified_at ? "✓ verified" : "Not verified"} />
                <Row label="Account status" value={profile.account_status} />

                <div className="pt-3 border-t border-border flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-medium flex items-center gap-2"><Sparkles className="h-3.5 w-3.5 text-yellow-400" /> AI assist (global)</div>
                    <div className="text-xs text-muted-foreground">Default AI on/off for every new listing. You can override per-listing.</div>
                  </div>
                  <button
                    onClick={async () => {
                      const next = !profile.ai_assist_enabled_global;
                      const { error } = await supabase.from("profiles").update({ ai_assist_enabled_global: next }).eq("id", profile.id);
                      if (!error) (window as any).location.reload();
                    }}
                    role="switch"
                    aria-checked={profile.ai_assist_enabled_global}
                    className={`relative h-6 w-11 rounded-full transition shrink-0 ${profile.ai_assist_enabled_global ? "bg-yellow-400" : "bg-muted"}`}
                  >
                    <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-background shadow transition ${profile.ai_assist_enabled_global ? "left-[1.4rem]" : "left-0.5"}`} />
                  </button>
                </div>

                <div className="pt-3 border-t border-border">
                  <Link to="/subscription" className="text-sm text-yellow-400 hover:underline">Manage NextGen subscription →</Link>
                </div>

                <div className="pt-3 border-t border-border">
                  <Link to="/legal/terms" className="text-xs text-muted-foreground hover:text-foreground underline mr-4">Terms</Link>
                  <Link to="/legal/seller-agreement" className="text-xs text-muted-foreground hover:text-foreground underline mr-4">Seller Agreement</Link>
                  <Link to="/legal/community-guidelines" className="text-xs text-muted-foreground hover:text-foreground underline mr-4">Community Guidelines</Link>
                  <Link to="/legal/prohibited-items" className="text-xs text-muted-foreground hover:text-foreground underline">Prohibited Items</Link>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <BottomTabBar />
    </div>
  );
};

const Stat = ({ label, value, sub, alert }: { label: string; value: number | string; sub?: string; alert?: boolean }) => (
  <div className={`glass rounded-2xl p-4 ${alert ? "border-warning/50" : ""}`}>
    <div className="text-xs text-muted-foreground">{label}</div>
    <div className={`font-display font-bold text-2xl ${alert ? "text-warning" : "text-gradient"}`}>{value}</div>
    {sub && <div className="text-[10px] text-warning mt-0.5">{sub}</div>}
  </div>
);

const Tab = ({ value, icon: Icon, label }: { value: string; icon: typeof LayoutDashboard; label: string }) => (
  <TabsTrigger value={value} className="rounded-lg data-[state=active]:bg-primary/15 data-[state=active]:text-foreground gap-1.5 whitespace-nowrap">
    <Icon className="h-3.5 w-3.5" />
    <span className="text-xs">{label}</span>
  </TabsTrigger>
);

const Empty = ({ title, hint }: { title: string; hint?: string }) => (
  <div className="glass rounded-2xl p-10 text-center">
    <div className="font-display font-semibold mb-2">{title}</div>
    {hint && <p className="text-sm text-muted-foreground">{hint}</p>}
  </div>
);

const Checklist = ({ done, label }: { done: boolean; label: string }) => (
  <div className={`flex items-center gap-3 p-3 rounded-xl border ${done ? "border-success/40 bg-success/5" : "border-border"}`}>
    <div className={`h-5 w-5 rounded-full grid place-items-center ${done ? "bg-success" : "bg-muted"}`}>
      {done ? <span className="text-xs">✓</span> : <span className="text-xs text-muted-foreground">·</span>}
    </div>
    <span className="text-sm">{label}</span>
  </div>
);

const Row = ({ label, value }: { label: string; value: string }) => (
  <div className="flex justify-between gap-3 py-1">
    <span className="text-muted-foreground">{label}</span>
    <span className="font-medium capitalize text-right">{value}</span>
  </div>
);

export default Account;
