import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Gavel, MapPin, Package, Sparkles, Heart, MessageCircle, Lock, Clock, Loader2 } from "lucide-react";
import Navbar from "@/components/Navbar";
import BottomTabBar from "@/components/BottomTabBar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

type Listing = {
  id: string;
  seller_id: string;
  title: string;
  description: string | null;
  category: string | null;
  condition: string | null;
  tags: string[] | null;
  listing_type: "buy_now" | "auction" | "local";
  status: string;
  price_cents: number | null;
  starting_bid_cents: number | null;
  reserve_cents: number | null;
  current_bid_cents: number | null;
  current_bidder_id: string | null;
  bid_count: number;
  auction_ends_at: string | null;
  city: string | null;
  state: string | null;
  view_count: number;
  ai_assist_enabled: boolean;
};

const dollar = (cents: number | null | undefined) => (cents == null ? "—" : `$${(cents / 100).toFixed(2)}`);

function useCountdown(endsAt: string | null | undefined) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!endsAt) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [endsAt]);
  if (!endsAt) return null;
  const ms = new Date(endsAt).getTime() - now;
  if (ms <= 0) return "Ended";
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m ${sec}s`;
  return `${m}m ${sec}s`;
}

const ListingDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [listing, setListing] = useState<Listing | null>(null);
  const [images, setImages] = useState<{ url: string; position: number }[]>([]);
  const [seller, setSeller] = useState<{ display_name: string | null; seller_rating: number | null; total_sales: number | null } | null>(null);
  const [activeImg, setActiveImg] = useState(0);
  const [loading, setLoading] = useState(true);
  const [bidAmount, setBidAmount] = useState<string>("");
  const [bidding, setBidding] = useState(false);

  const remaining = useCountdown(listing?.auction_ends_at);

  useEffect(() => {
    if (!id) return;
    let alive = true;
    (async () => {
      setLoading(true);
      const { data: l } = await supabase.from("listings").select("*").eq("id", id).maybeSingle();
      if (!alive) return;
      if (!l) { setLoading(false); return; }
      setListing(l as Listing);
      const [{ data: imgs }, { data: s }] = await Promise.all([
        supabase.from("listing_images").select("url,position").eq("listing_id", id).order("position"),
        supabase.from("profiles").select("display_name,seller_rating,total_sales").eq("id", l.seller_id).maybeSingle(),
      ]);
      if (!alive) return;
      setImages((imgs as any) ?? []);
      setSeller(s as any);
      setLoading(false);
    })();
  }, [id]);

  // realtime bid updates
  useEffect(() => {
    if (!id || listing?.listing_type !== "auction") return;
    const ch = supabase
      .channel(`listing-${id}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "listings", filter: `id=eq.${id}` }, (payload) => {
        setListing((prev) => (prev ? { ...prev, ...(payload.new as any) } : prev));
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [id, listing?.listing_type]);

  const minBid = useMemo(() => {
    if (!listing) return 0;
    const cur = listing.current_bid_cents ?? listing.starting_bid_cents ?? 0;
    return Math.max(cur + 100, 100); // +$1 increment
  }, [listing]);

  if (loading) return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;
  if (!listing) return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-24 container max-w-xl text-center">
        <div className="glass rounded-2xl p-8">
          <Package className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
          <div className="font-display font-semibold">Listing not found</div>
          <Link to="/browse"><Button className="mt-4 rounded-xl">Browse marketplace</Button></Link>
        </div>
      </main>
    </div>
  );

  const isOwner = user?.id === listing.seller_id;
  const isAuction = listing.listing_type === "auction";
  const ended = isAuction && remaining === "Ended";

  const placeBid = async () => {
    if (!user) { navigate("/auth"); return; }
    const cents = Math.round(parseFloat(bidAmount) * 100);
    if (!cents || cents < minBid) {
      toast({ title: "Bid too low", description: `Minimum bid is ${dollar(minBid)}`, variant: "destructive" });
      return;
    }
    setBidding(true);
    try {
      const { error } = await supabase.from("bids").insert({
        listing_id: listing.id,
        bidder_id: user.id,
        amount_cents: cents,
      });
      if (error) throw error;
      // optimistic UI; trigger/edge function should authoritatively update listings
      await supabase.from("listings").update({
        current_bid_cents: cents,
        current_bidder_id: user.id,
        bid_count: listing.bid_count + 1,
      }).eq("id", listing.id).eq("listing_type", "auction");
      toast({ title: "Bid placed!", description: `You're the high bidder at ${dollar(cents)}.` });
      setBidAmount("");
    } catch (e: any) {
      toast({ title: "Couldn't place bid", description: e.message, variant: "destructive" });
    } finally {
      setBidding(false);
    }
  };

  const startConversation = async () => {
    if (!user) { navigate("/auth"); return; }
    if (isOwner) return;
    // find or create
    const { data: existing } = await supabase
      .from("conversations")
      .select("id")
      .eq("listing_id", listing.id)
      .eq("buyer_id", user.id)
      .eq("seller_id", listing.seller_id)
      .maybeSingle();
    let convId = existing?.id;
    if (!convId) {
      const { data: created, error } = await supabase
        .from("conversations")
        .insert({ listing_id: listing.id, buyer_id: user.id, seller_id: listing.seller_id })
        .select("id")
        .single();
      if (error) { toast({ title: "Couldn't start chat", description: error.message, variant: "destructive" }); return; }
      convId = created.id;
    }
    navigate(`/messages/${convId}`);
  };

  const cover = images[activeImg]?.url;

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-24 pb-28 md:pb-12">
        <div className="container max-w-6xl">
          <button onClick={() => navigate(-1)} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
            <ArrowLeft className="h-4 w-4" /> Back
          </button>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Gallery */}
            <div>
              <div className="glass rounded-2xl overflow-hidden aspect-square">
                {cover ? (
                  <img src={cover} alt={listing.title} className="h-full w-full object-cover" />
                ) : (
                  <div className="h-full w-full grid place-items-center text-muted-foreground"><Package className="h-12 w-12" /></div>
                )}
              </div>
              {images.length > 1 && (
                <div className="grid grid-cols-5 gap-2 mt-2">
                  {images.map((img, i) => (
                    <button key={i} onClick={() => setActiveImg(i)} className={`aspect-square rounded-xl overflow-hidden glass ${i === activeImg ? "ring-2 ring-yellow-400" : ""}`}>
                      <img src={img.url} alt="" className="h-full w-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Info */}
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {isAuction && <Badge className="bg-yellow-400 text-black border-0"><Gavel className="h-3 w-3 mr-1" />Auction</Badge>}
                {listing.listing_type === "local" && <Badge className="bg-emerald-500 text-white border-0"><MapPin className="h-3 w-3 mr-1" />Local</Badge>}
                {listing.listing_type === "buy_now" && <Badge variant="outline">Buy Now</Badge>}
                {listing.ai_assist_enabled && <Badge className="bg-yellow-400/15 text-yellow-400 border-yellow-400/30"><Sparkles className="h-3 w-3 mr-1" />AI-assisted</Badge>}
                {listing.condition && <Badge variant="outline" className="capitalize">{listing.condition.replace("_"," ")}</Badge>}
              </div>

              <h1 className="font-display text-3xl sm:text-4xl font-bold">{listing.title}</h1>

              {/* Price block */}
              {isAuction ? (
                <div className="glass-strong rounded-2xl p-5">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">Current bid</div>
                  <div className="font-display font-bold text-4xl text-gradient-brand">{dollar(listing.current_bid_cents ?? listing.starting_bid_cents)}</div>
                  <div className="flex items-center justify-between mt-2 text-sm text-muted-foreground">
                    <span>{listing.bid_count} bid{listing.bid_count === 1 ? "" : "s"}</span>
                    <span className="inline-flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" />{remaining ?? "—"}</span>
                  </div>
                  {!isOwner && !ended && (
                    <div className="mt-4 flex gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                        <Input
                          inputMode="decimal"
                          value={bidAmount}
                          onChange={(e) => setBidAmount(e.target.value)}
                          placeholder={`${(minBid / 100).toFixed(2)}+`}
                          className="pl-7 rounded-xl"
                        />
                      </div>
                      <Button onClick={placeBid} disabled={bidding} className="rounded-xl bg-gradient-primary shadow-glow">
                        {bidding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Gavel className="h-4 w-4" />}
                        Place bid
                      </Button>
                    </div>
                  )}
                  {ended && <div className="mt-3 text-sm text-warning">This auction has ended.</div>}
                  {isOwner && <div className="mt-3 text-sm text-muted-foreground">You're the seller — bids show in your dashboard.</div>}
                </div>
              ) : (
                <div className="glass-strong rounded-2xl p-5">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">Price</div>
                  <div className="font-display font-bold text-4xl text-gradient-brand">{dollar(listing.price_cents)}</div>
                  {!isOwner && (
                    <Button className="w-full mt-4 rounded-xl bg-gradient-primary shadow-glow h-12" onClick={startConversation}>
                      {listing.listing_type === "local" ? "Contact for pickup" : "Buy now"}
                    </Button>
                  )}
                </div>
              )}

              <div className="glass rounded-2xl p-5">
                <h3 className="font-display font-semibold mb-2">Description</h3>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">{listing.description || "No description provided."}</p>
                {listing.tags && listing.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {listing.tags.map((t) => <Badge key={t} variant="outline" className="text-xs">{t}</Badge>)}
                  </div>
                )}
              </div>

              <div className="glass rounded-2xl p-5 flex items-center justify-between">
                <div>
                  <div className="text-xs text-muted-foreground">Seller</div>
                  <div className="font-display font-semibold">{seller?.display_name ?? "Anonymous"}</div>
                  <div className="text-xs text-muted-foreground">★ {Number(seller?.seller_rating ?? 0).toFixed(1)} · {seller?.total_sales ?? 0} sales</div>
                </div>
                {!isOwner && (
                  <Button variant="outline" className="rounded-xl glass" onClick={startConversation}>
                    <MessageCircle className="h-4 w-4" /> Message
                  </Button>
                )}
              </div>

              <div className="text-xs text-muted-foreground flex items-center gap-3">
                <span className="inline-flex items-center gap-1"><Lock className="h-3 w-3" /> Messaging unlocks after both fees clear</span>
                <span>·</span>
                <span>{listing.view_count} views</span>
              </div>
            </div>
          </div>
        </div>
      </main>
      <BottomTabBar />
    </div>
  );
};

export default ListingDetail;
