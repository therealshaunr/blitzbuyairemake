-- Auto-grant admin role to shaun.russell@gmail.com on signup, and apply if account exists.
-- Update handle_new_user trigger to detect this email and grant admin.
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.profiles (id, display_name, full_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'full_name'
  );
  -- default user role
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  -- power administrator: shaun.russell@gmail.com always becomes admin
  IF lower(NEW.email) = 'shaun.russell@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$function$;

-- If the user already exists, retroactively grant admin
INSERT INTO public.user_roles (user_id, role)
SELECT u.id, 'admin'::app_role
FROM auth.users u
WHERE lower(u.email) = 'shaun.russell@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;