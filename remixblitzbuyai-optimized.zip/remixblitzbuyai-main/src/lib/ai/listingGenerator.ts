/**
 * AI Listing Generation Service
 *
 * In production (Vercel), uses the Supabase Edge Function "generate-listing".
 * In local dev, can optionally use Ollama for direct LLM inference.
 */

import { supabase } from "@/integrations/supabase/client";

export interface ListingInput {
  images: string[];
  sellerId: string;
}

export interface GeneratedListing {
  title: string;
  description: string;
  category: string;
  condition: "new" | "like_new" | "good" | "fair" | "poor";
  priceRange: { min: number; max: number; recommended: number };
  tags: string[];
}

// Fixed: use import.meta.env (Vite), not process.env (Node)
const OLLAMA_BASE_URL = import.meta.env.VITE_OLLAMA_URL || "http://localhost:11434";
const IS_PRODUCTION = import.meta.env.PROD;

/**
 * Generate a listing.
 * Production: Supabase Edge Function.
 * Dev: Ollama first, then Edge Function, then static fallback.
 */
export async function generateListing(input: ListingInput): Promise<GeneratedListing> {
  if (IS_PRODUCTION) {
    return generateViaEdgeFunction(input);
  }

  const ollamaAvailable = await checkOllamaHealth();
  if (ollamaAvailable) {
    try {
      return await generateViaOllama(input);
    } catch (error) {
      console.warn("Ollama failed, trying Edge Function:", error);
    }
  }

  return generateViaEdgeFunction(input);
}

async function generateViaEdgeFunction(input: ListingInput): Promise<GeneratedListing> {
  try {
    const { data, error } = await supabase.functions.invoke("generate-listing", {
      body: { images: input.images, sellerId: input.sellerId },
    });

    if (error) {
      console.error("Edge Function error:", error);
      return generateFallbackListing();
    }

    return {
      title: data.title || "Untitled Listing",
      description: data.description || "No description provided",
      category: validateCategory(data.category),
      condition: validateCondition(data.condition),
      priceRange: {
        min: Math.max(1, data.priceRange?.min || 10),
        max: Math.max(data.priceRange?.min || 10, data.priceRange?.max || 100),
        recommended: data.priceRange?.recommended || Math.round(((data.priceRange?.min || 10) + (data.priceRange?.max || 100)) / 2),
      },
      tags: Array.isArray(data.tags) ? data.tags.slice(0, 5) : [],
    };
  } catch (error) {
    console.error("Edge Function call failed:", error);
    return generateFallbackListing();
  }
}

async function generateViaOllama(input: ListingInput): Promise<GeneratedListing> {
  const response = await fetch(`${OLLAMA_BASE_URL}/api/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "llava",
      prompt: buildListingPrompt(),
      stream: false,
    }),
  });

  if (!response.ok) throw new Error(`Ollama error: ${response.status}`);

  const result = await response.json();
  return parseListingResponse(result.response);
}

export async function checkOllamaHealth(): Promise<boolean> {
  if (IS_PRODUCTION) return false;
  try {
    const response = await fetch(`${OLLAMA_BASE_URL}/api/tags`, {
      method: "GET",
      signal: AbortSignal.timeout(2000),
    });
    return response.ok;
  } catch {
    return false;
  }
}

export async function getAvailableModels(): Promise<string[]> {
  if (IS_PRODUCTION) return [];
  try {
    const response = await fetch(`${OLLAMA_BASE_URL}/api/tags`);
    if (!response.ok) return [];
    const data = await response.json();
    return data.models?.map((m: any) => m.name) || [];
  } catch {
    return [];
  }
}

function buildListingPrompt(): string {
  return `You are an expert e-commerce listing generator. Analyze the item and generate a complete listing.

Generate a JSON response with these exact fields:
{
  "title": "A compelling, searchable title (max 80 chars)",
  "description": "A detailed description highlighting key features (2-3 paragraphs)",
  "category": "One of: electronics, clothing, shoes, accessories, home, sports, collectibles, toys, books, other",
  "condition": "One of: new, like_new, good, fair, poor",
  "priceRange": { "min": number, "max": number, "recommended": number },
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"]
}

Respond ONLY with valid JSON, no other text.`;
}

function parseListingResponse(response: string): GeneratedListing {
  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return generateFallbackListing();

    const parsed = JSON.parse(jsonMatch[0]);
    return {
      title: parsed.title || "Untitled Listing",
      description: parsed.description || "No description provided",
      category: validateCategory(parsed.category),
      condition: validateCondition(parsed.condition),
      priceRange: {
        min: Math.max(1, parsed.priceRange?.min || 10),
        max: Math.max(parsed.priceRange?.min || 10, parsed.priceRange?.max || 100),
        recommended: parsed.priceRange?.recommended || Math.round((parsed.priceRange?.min + parsed.priceRange?.max) / 2) || 50,
      },
      tags: Array.isArray(parsed.tags) ? parsed.tags.slice(0, 5) : [],
    };
  } catch {
    return generateFallbackListing();
  }
}

function validateCategory(cat: string): string {
  const valid = ["electronics", "clothing", "shoes", "accessories", "home", "sports", "collectibles", "toys", "books", "other"];
  return valid.includes(cat?.toLowerCase()) ? cat.toLowerCase() : "other";
}

function validateCondition(cond: string): GeneratedListing["condition"] {
  const valid: GeneratedListing["condition"][] = ["new", "like_new", "good", "fair", "poor"];
  const lower = (cond ?? "").toLowerCase() as GeneratedListing["condition"];
  return valid.includes(lower) ? lower : "good";
}

function generateFallbackListing(): GeneratedListing {
  return {
    title: "Item for Sale",
    description: "Contact seller for more details about this item.",
    category: "other",
    condition: "good",
    priceRange: { min: 25, max: 100, recommended: 50 },
    tags: ["for-sale", "misc"],
  };
}
