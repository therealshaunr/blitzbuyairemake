import { useNavigate } from "react-router-dom";
import { Sparkles, Check, X, Zap, ArrowLeft } from "lucide-react";
import Navbar from "@/components/Navbar";
import BottomTabBar from "@/components/BottomTabBar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useEffect } from "react";

const features = [
  { label: "Listings per week", free: "50", pro: "100" },
  { label: "Outstanding seller-fee allowance", free: "$25", pro: "$100" },
  { label: "Cashback on completed sales", free: "—", pro: "1%" },
  { label: "AI listing generation", free: true, pro: true },
  { label: "Priority AI processing", free: false, pro: true },
  { label: "Featured placement boost", free: false, pro: true },
  { label: "Auctions & local pickups", free: true, pro: true },
];

const Subscription = () => {
  const { user, profile, loading, refreshProfile } = useAuth() as any;
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => { if (!loading && !user) navigate("/auth"); }, [user, loading, navigate]);

  if (loading || !profile) return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;

  const isActive = profile.nextgen_status === "active";

  // Placeholder upgrade — wires to payment provider later.
  const upgrade = async () => {
    const renews = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
    const { error } = await supabase.from("profiles").update({
      nextgen_status: "active",
      nextgen_renews_at: renews,
    }).eq("id", profile.id);
    if (error) { toast({ title: "Couldn't upgrade", description: error.message, variant: "destructive" }); return; }
    toast({ title: "Welcome to NextGen!", description: "Your perks are active for 30 days." });
    refreshProfile?.();
  };

  const cancel = async () => {
    const { error } = await supabase.from("profiles").update({ nextgen_status: "canceled" }).eq("id", profile.id);
    if (error) { toast({ title: "Couldn't cancel", description: error.message, variant: "destructive" }); return; }
    toast({ title: "Membership cancelled", description: "Perks remain active until your renewal date." });
    refreshProfile?.();
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-24 pb-28 md:pb-12">
        <div className="container max-w-4xl">
          <button onClick={() => navigate(-1)} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
            <ArrowLeft className="h-4 w-4" /> Back
          </button>

          <div className="text-center mb-8">
            <Badge className="bg-yellow-400/15 text-yellow-400 border-yellow-400/30 mb-3">
              <Sparkles className="h-3 w-3 mr-1" /> Subscription
            </Badge>
            <h1 className="font-display text-3xl sm:text-5xl font-bold">
              Go <span className="text-gradient-brand">NextGen</span>. Sell faster.
            </h1>
            <p className="text-muted-foreground mt-2">More listings, bigger fee headroom, 1% cashback — all powered by the same AI engine.</p>
          </div>

          <div className="grid md:grid-cols-2 gap-4 mb-8">
            <PlanCard
              title="Free"
              price="$0"
              tagline="Get started in seconds."
              cta={isActive ? "Downgrade after renewal" : "Current plan"}
              disabled
              current={!isActive}
            />
            <PlanCard
              title="NextGen"
              price="$10"
              priceSub="/month"
              tagline="For people who actually move stuff."
              highlight
              current={isActive}
              cta={isActive ? "Cancel membership" : "Upgrade to NextGen"}
              onClick={isActive ? cancel : upgrade}
            />
          </div>

          <div className="glass rounded-2xl overflow-hidden">
            <div className="grid grid-cols-3 px-5 py-3 text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
              <div>Feature</div>
              <div className="text-center">Free</div>
              <div className="text-center text-yellow-400">NextGen</div>
            </div>
            {features.map((f) => (
              <div key={f.label} className="grid grid-cols-3 px-5 py-3 border-b border-border/50 last:border-0 text-sm">
                <div>{f.label}</div>
                <div className="text-center">
                  {typeof f.free === "boolean" ? (f.free ? <Check className="h-4 w-4 inline text-success" /> : <X className="h-4 w-4 inline text-muted-foreground" />) : f.free}
                </div>
                <div className="text-center font-medium">
                  {typeof f.pro === "boolean" ? (f.pro ? <Check className="h-4 w-4 inline text-yellow-400" /> : <X className="h-4 w-4 inline text-muted-foreground" />) : f.pro}
                </div>
              </div>
            ))}
          </div>

          {isActive && profile.nextgen_renews_at && (
            <p className="text-xs text-muted-foreground text-center mt-4">
              Renews on {new Date(profile.nextgen_renews_at).toLocaleDateString()}.
            </p>
          )}
        </div>
      </main>
      <BottomTabBar />
    </div>
  );
};

const PlanCard = ({ title, price, priceSub, tagline, cta, onClick, disabled, highlight, current }: {
  title: string; price: string; priceSub?: string; tagline: string; cta: string; onClick?: () => void; disabled?: boolean; highlight?: boolean; current?: boolean;
}) => (
  <div className={`glass rounded-2xl p-6 relative ${highlight ? "ring-2 ring-yellow-400/50 shadow-glow" : ""}`}>
    {current && <Badge className="absolute -top-2 right-4 bg-success text-success-foreground border-0">Current</Badge>}
    {highlight && !current && <Badge className="absolute -top-2 right-4 bg-yellow-400 text-black border-0"><Zap className="h-3 w-3 mr-1" />Best value</Badge>}
    <div className="font-display font-semibold text-lg">{title}</div>
    <div className="mt-2 flex items-end gap-1">
      <span className="font-display font-bold text-4xl">{price}</span>
      {priceSub && <span className="text-muted-foreground mb-1">{priceSub}</span>}
    </div>
    <p className="text-sm text-muted-foreground mt-1 mb-5">{tagline}</p>
    <Button
      onClick={onClick}
      disabled={disabled}
      className={`w-full rounded-xl h-11 ${highlight ? "bg-gradient-primary shadow-glow" : "glass"}`}
      variant={highlight ? "default" : "outline"}
    >
      {cta}
    </Button>
  </div>
);

export default Subscription;
