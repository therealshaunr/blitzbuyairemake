import { Link, useLocation } from "react-router-dom";
import { Home, Search, MessageCircle, User, Sparkles } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

const tabs = [
  { to: "/", label: "Home", icon: Home },
  { to: "/browse", label: "Browse", icon: Search },
  { to: "/sell", label: "Sell", icon: Sparkles, primary: true },
  { to: "/messages", label: "Inbox", icon: MessageCircle },
  { to: "/account", label: "Account", icon: User },
];

const BottomTabBar = () => {
  const { pathname } = useLocation();
  const { user, loading } = useAuth();

  // Logged-out: render a single signup CTA bar instead of the full app tabs
  if (!loading && !user) {
    return (
      <nav
        aria-label="Sign up"
        className="md:hidden fixed bottom-0 inset-x-0 z-40 pb-[env(safe-area-inset-bottom)]"
      >
        <div className="mx-3 mb-3">
          <Link to="/auth" className="block">
            <Button className="w-full h-14 rounded-2xl bg-gradient-primary shadow-glow font-display font-semibold text-base">
              <Sparkles className="h-5 w-5" />
              Join the Blitz — it's free
            </Button>
          </Link>
        </div>
      </nav>
    );
  }

  return (
    <nav
      aria-label="Primary"
      className="md:hidden fixed bottom-0 inset-x-0 z-40 pb-[env(safe-area-inset-bottom)]"
    >
      <div className="mx-3 mb-3 glass-strong rounded-2xl shadow-elevated">
        <ul className="grid grid-cols-5">
          {tabs.map((t) => {
            const active = pathname === t.to;
            const Icon = t.icon;
            if (t.primary) {
              return (
                <li key={t.to} className="flex justify-center">
                  <Link
                    to={t.to}
                    aria-label={t.label}
                    className="-mt-6 h-14 w-14 rounded-2xl bg-gradient-primary grid place-items-center shadow-glow active:scale-95 transition-transform"
                  >
                    <Icon className="h-6 w-6 text-primary-foreground" />
                  </Link>
                </li>
              );
            }
            return (
              <li key={t.to}>
                <Link
                  to={t.to}
                  aria-label={t.label}
                  className={`flex flex-col items-center justify-center gap-1 min-h-[56px] py-2 text-[10px] font-medium transition-colors ${
                    active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Icon className={`h-5 w-5 ${active ? "text-primary" : ""}`} />
                  {t.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
};

export default BottomTabBar;
