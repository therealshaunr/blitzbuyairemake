#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   ./scripts/update-vercel-envs.sh [path-to-env-file]
#
# Examples (run locally; do NOT paste secrets into chat):
#   VERCEL_TOKEN=... VERCEL_PROJECT_ID=... ./scripts/update-vercel-envs.sh ./secrets.local
#   or
#   VERCEL_TOKEN=... VERCEL_PROJECT_ID=... NEW_SUPABASE_URL=... NEW_SUPABASE_KEY=... NEW_SUPABASE_SERVICE_KEY=... ./scripts/update-vercel-envs.sh
#
# The script will upsert these environment variables in Vercel for preview+production:
#  - VITE_SUPABASE_URL
#  - VITE_SUPABASE_PUBLISHABLE_KEY
#  - SUPABASE_SERVICE_ROLE_KEY (optional)

set -euo pipefail

ENV_FILE="${1:-}"
if [ -n "${ENV_FILE}" ] && [ -f "${ENV_FILE}" ]; then
  echo "Sourcing env file: $ENV_FILE (values will be read into the environment locally for this run)"
  # shellcheck disable=SC1090
  set -a
  . "$ENV_FILE"
  set +a
fi

if [ -z "${VERCEL_TOKEN:-}" ] || [ -z "${VERCEL_PROJECT_ID:-}" ]; then
  cat <<EOF
Usage: VERCEL_TOKEN=xxx VERCEL_PROJECT_ID=proj_abc [NEW_SUPABASE_URL=...] [NEW_SUPABASE_KEY=...] [NEW_SUPABASE_SERVICE_KEY=...] $0 [optional-env-file]

This script UPDATES or CREATES the following Vercel environment variables for the given project (targets preview+production):
 - VITE_SUPABASE_URL
 - VITE_SUPABASE_PUBLISHABLE_KEY
 - SUPABASE_SERVICE_ROLE_KEY (optional)

You can either pass values in the environment, or provide a local env file path as the first argument which will be sourced for this run.
Example env file (do NOT commit):
  NEW_SUPABASE_URL=https://<project>.supabase.co
  NEW_SUPABASE_KEY=public-xxxxxxxx
  NEW_SUPABASE_SERVICE_KEY=service-xxxxxxxx

EOF
  exit 1
fi

API="https://api.vercel.com/v9/projects/${VERCEL_PROJECT_ID}/env"

echo "Upserting Vercel envs for project ${VERCEL_PROJECT_ID}"

upsert_env() {
  local key="$1"; local value="$2"; local type="${3:-encrypted}"
  if [ -z "${value:-}" ]; then
    echo "Skipping $key because value is empty"
    return 0
  fi

  # Fetch existing envs and attempt to find an existing id for this key.
  payload=$(curl -s -H "Authorization: Bearer ${VERCEL_TOKEN}" "$API")
  env_id=$(echo "$payload" | jq -r --arg KEY "$key" '(.env[]? // .envs[]? // .items[]? // .[]?) | select(.key==$KEY) | .id' 2>/dev/null | head -n1 || true)

  if [ -n "$env_id" ] && [ "$env_id" != "null" ]; then
    echo "Found existing env var for $key (id=$env_id). Updating..."
    curl -s -X PATCH "$API/$env_id" \
      -H "Authorization: Bearer ${VERCEL_TOKEN}" \
      -H "Content-Type: application/json" \
      -d "{\"value\": \"${value}\", \"target\": [\"preview\",\"production\"], \"type\": \"${type}\" }" \
      | jq .
  else
    echo "Creating $key..."
    curl -s -X POST "$API" \
      -H "Authorization: Bearer ${VERCEL_TOKEN}" \
      -H "Content-Type: application/json" \
      -d "{\"key\": \"${key}\", \"value\": \"${value}\", \"target\": [\"preview\",\"production\"], \"type\": \"${type}\" }" \
      | jq .
  fi
}

# Upsert the required vars (if present)
upsert_env "VITE_SUPABASE_URL" "${NEW_SUPABASE_URL:-}"
upsert_env "VITE_SUPABASE_PUBLISHABLE_KEY" "${NEW_SUPABASE_KEY:-}"
upsert_env "SUPABASE_SERVICE_ROLE_KEY" "${NEW_SUPABASE_SERVICE_KEY:-}"

echo "Done. It may take a minute for Vercel to propagate the new env values to active deployments."
