import { useEffect, useState } from "react";
import { MailWarning, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const EmailVerifyBanner = () => {
  const { user } = useAuth();
  const [dismissed, setDismissed] = useState(false);
  const [sending, setSending] = useState(false);

  const verified = Boolean(user && (user as any).email_confirmed_at);

  useEffect(() => {
    setDismissed(false);
  }, [user?.id]);

  if (!user || verified || dismissed) return null;

  const resend = async () => {
    if (!user.email) return;
    setSending(true);
    const { error } = await supabase.auth.resend({ type: "signup", email: user.email });
    setSending(false);
    if (error) toast.error(error.message);
    else toast.success("Verification email sent. Check your inbox.");
  };

  return (
    <div className="sticky top-0 z-40 bg-warning/15 border-b border-warning/30 backdrop-blur">
      <div className="container flex items-center gap-3 py-2.5 text-sm">
        <MailWarning className="h-4 w-4 text-warning shrink-0" />
        <p className="flex-1 text-foreground/90">
          Verify your email to buy or sell on BlitzBuy.AI. We sent a link to <span className="font-medium">{user.email}</span>.
        </p>
        <Button size="sm" variant="outline" className="h-8 rounded-lg" onClick={resend} disabled={sending}>
          {sending ? "Sending…" : "Resend"}
        </Button>
        <button
          aria-label="Dismiss"
          onClick={() => setDismissed(true)}
          className="p-1 rounded hover:bg-foreground/10"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

export default EmailVerifyBanner;
