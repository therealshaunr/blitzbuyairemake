export interface DemoListing {
  id: string;
  title: string;
  description: string;
  price_cents?: number;
  listing_type?: string;
  status?: string;
  seller_display?: string;
  images?: string[];
}

export const demoListings: DemoListing[] = [
  {
    id: "demo-1",
    title: "Vintage Fender Stratocaster — Sunburst",
    description: "A beautifully aged 1978 Fender Stratocaster with original pickups. Plays like butter.",
    price_cents: 2499900,
    listing_type: "buy_now",
    status: "active",
    seller_display: "RiffMaster",
    images: ["/assets/demo/strat.jpg"]
  },
  {
    id: "demo-2",
    title: "Apple MacBook Pro 14" + " — M1 Pro",
    description: "Lightly used M1 Pro, 16GB RAM, 1TB SSD. Perfect for production workloads.",
    price_cents: 1799900,
    listing_type: "buy_now",
    status: "active",
    seller_display: "JaneDoe",
    images: ["/assets/demo/macbook.jpg"]
  },
  {
    id: "demo-3",
    title: "Signed Basketball — Limited Edition",
    description: "Collector's item. Comes with COA and original box.",
    price_cents: 49900,
    listing_type: "auction",
    status: "active",
    seller_display: "HoopsFan",
    images: ["/assets/demo/ball.jpg"]
  }
];

export const demoProfiles = [
  { id: "demo-user-1", display_name: "RiffMaster", full_name: "Sam Player" },
  { id: "demo-user-2", display_name: "JaneDoe", full_name: "Jane Doe" },
  { id: "demo-user-3", display_name: "HoopsFan", full_name: "Alex Courts" },
];
