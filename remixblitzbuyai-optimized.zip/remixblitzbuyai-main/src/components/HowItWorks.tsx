import { Camera, Brain, Rocket } from "lucide-react";

const steps = [
  {
    icon: Camera,
    title: "Snap photos",
    desc: "Open the camera, take 1–8 shots of your item. That's it from you.",
    step: "01",
  },
  {
    icon: Brain,
    title: "AI builds the listing",
    desc: "Title, description, condition, category, and a fair price range — generated in seconds.",
    step: "02",
  },
  {
    icon: Rocket,
    title: "Pick how to sell",
    desc: "Run a 1, 3, or 5-day auction, set a Buy Now price, or list locally for pickup.",
    step: "03",
  },
];

const HowItWorks = () => {
  return (
    <section className="py-16 sm:py-24 relative">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-16">
          <div className="inline-flex glass rounded-full px-4 py-1.5 mb-4">
            <span className="text-xs font-medium text-muted-foreground">How it works</span>
          </div>
          <h2 className="font-display text-3xl sm:text-5xl font-bold mb-4">
            Listing in <span className="text-gradient-brand">three taps</span>
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg">
            No more typing descriptions, guessing prices, or fighting forms. Let the AI do the heavy lifting.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
          {steps.map((s, i) => (
            <div
              key={s.step}
              className="glass rounded-2xl p-6 sm:p-8 relative group hover:border-primary/40 transition-all hover:-translate-y-1 shadow-card"
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              <div className="absolute top-5 right-5 sm:top-6 sm:right-6 font-display font-bold text-4xl sm:text-5xl text-primary/10">
                {s.step}
              </div>
              <div className="h-12 w-12 sm:h-14 sm:w-14 rounded-2xl bg-gradient-primary grid place-items-center mb-5 sm:mb-6 group-hover:shadow-glow transition-shadow">
                <s.icon className="h-6 w-6 sm:h-7 sm:w-7 text-primary-foreground" />
              </div>
              <h3 className="font-display font-bold text-lg sm:text-xl mb-2">{s.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
