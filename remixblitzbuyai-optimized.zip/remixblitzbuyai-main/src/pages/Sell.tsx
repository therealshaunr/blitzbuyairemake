import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Camera, Type, Wrench, Sparkles, Upload, Loader2, X, ArrowLeft, ArrowRight, AlertTriangle, CheckCircle2 } from "lucide-react";
import Navbar from "@/components/Navbar";
import BottomTabBar from "@/components/BottomTabBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

type Mode = "photo" | "text" | "manual";

interface DraftListing {
  title: string;
  description: string;
  category: string;
  condition: "new" | "like_new" | "good" | "fair" | "poor";
  price_recommended_cents: number;
  price_min_cents: number;
  price_max_cents: number;
  tags: string[];
  flags: string[];
  confidence: number;
}

const BLANK: DraftListing = {
  title: "",
  description: "",
  category: "other",
  condition: "good",
  price_recommended_cents: 0,
  price_min_cents: 0,
  price_max_cents: 0,
  tags: [],
  flags: [],
  confidence: 1,
};

const Sell = () => {
  const navigate = useNavigate();
  const { user, profile, loading } = useAuth();
  const { toast } = useToast();

  const [mode, setMode] = useState<Mode | null>(null);
  const [step, setStep] = useState<"pick" | "input" | "review">("pick");
  const [photos, setPhotos] = useState<{ file: File; preview: string; uploadedUrl?: string }[]>([]);
  const [textInput, setTextInput] = useState("");
  const [generating, setGenerating] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [draft, setDraft] = useState<DraftListing>(BLANK);
  const [listingType, setListingType] = useState<"buy_now" | "auction" | "local">("buy_now");
  const [auctionDays, setAuctionDays] = useState(3);
  const [aiEnabled, setAiEnabled] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // honor the user's global AI preference
  useEffect(() => {
    if (profile && profile.ai_assist_enabled_global === false) setAiEnabled(false);
  }, [profile]);

  useEffect(() => {
    if (!loading && !user) navigate("/auth");
  }, [user, loading, navigate]);

  // ----- gating -----
  if (loading) return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;
  if (!user || !profile) return null;

  const verifiedToSell = !!profile.email_verified_at || !!user.email_confirmed_at;

  if (!verifiedToSell) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <main className="pt-24 pb-28 md:pb-12 container max-w-xl">
          <div className="glass-strong rounded-2xl p-8 text-center">
            <AlertTriangle className="h-10 w-10 mx-auto text-warning mb-3" />
            <h1 className="font-display text-2xl font-bold mb-2">Verify your email to sell</h1>
            <p className="text-sm text-muted-foreground mb-5">
              Check your inbox for the verification link we sent. Verified sellers protect the marketplace from spam and scams.
            </p>
            <Button onClick={() => navigate("/account")} className="rounded-xl bg-gradient-primary shadow-glow">Go to account</Button>
          </div>
        </main>
        <BottomTabBar />
      </div>
    );
  }

  // ----- helpers -----
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []).slice(0, 8 - photos.length);
    const next = files.map((file) => ({ file, preview: URL.createObjectURL(file) }));
    setPhotos((p) => [...p, ...next]);
  };

  const removePhoto = (i: number) => {
    setPhotos((p) => p.filter((_, idx) => idx !== i));
  };

  const uploadPhotos = async (): Promise<string[]> => {
    const urls: string[] = [];
    for (const p of photos) {
      if (p.uploadedUrl) { urls.push(p.uploadedUrl); continue; }
      const ext = p.file.name.split(".").pop() || "jpg";
      const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from("listing-photos").upload(path, p.file, { upsert: false });
      if (error) throw error;
      const { data: pub } = supabase.storage.from("listing-photos").getPublicUrl(path);
      urls.push(pub.publicUrl);
    }
    return urls;
  };

  const generate = async () => {
    setGenerating(true);
    try {
      let payload: any = { mode };
      if (mode === "photo") {
        if (photos.length === 0) {
          toast({ title: "Add at least one photo", variant: "destructive" });
          return;
        }
        const urls = await uploadPhotos();
        setPhotos((p) => p.map((ph, i) => ({ ...ph, uploadedUrl: urls[i] })));
        payload.imageUrls = urls;
      } else if (mode === "text") {
        if (textInput.trim().length < 10) {
          toast({ title: "Tell us more", description: "At least 10 characters please.", variant: "destructive" });
          return;
        }
        payload.text = textInput;
      }
      payload.zip = profile.zip ?? undefined;

      const { data, error } = await supabase.functions.invoke("generate-listing", { body: payload });
      if (error) throw error;
      if (data?.error) {
        toast({ title: "AI generation failed", description: data.error, variant: "destructive" });
        return;
      }

      const l = data.listing as DraftListing;
      setDraft(l);

      // hard-block prohibited flags
      const blocking = (l.flags || []).filter((f) => ["nsfw", "weapon", "counterfeit", "recalled", "prohibited"].includes(f));
      if (blocking.length > 0) {
        toast({
          title: "This item can't be listed",
          description: `Detected: ${blocking.join(", ")}. See our prohibited items policy.`,
          variant: "destructive",
        });
        return;
      }
      setStep("review");
    } catch (e) {
      console.error(e);
      const msg = e instanceof Error ? e.message : "Something went wrong";
      toast({ title: "Couldn't generate listing", description: msg, variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  const startManual = async () => {
    // For manual we still upload photos so they're attached
    let urls: string[] = [];
    if (photos.length > 0) {
      try { urls = await uploadPhotos(); } catch (e: any) {
        toast({ title: "Photo upload failed", description: e.message, variant: "destructive" }); return;
      }
      setPhotos((p) => p.map((ph, i) => ({ ...ph, uploadedUrl: urls[i] })));
    }
    setDraft(BLANK);
    setStep("review");
  };

  const publish = async () => {
    if (!draft.title.trim() || !draft.description.trim()) {
      toast({ title: "Title and description are required", variant: "destructive" });
      return;
    }
    if (draft.price_recommended_cents < 100) {
      toast({ title: "Set a price of at least $1.00", variant: "destructive" });
      return;
    }
    setPublishing(true);
    try {
      const auctionEnd = listingType === "auction"
        ? new Date(Date.now() + auctionDays * 24 * 60 * 60 * 1000).toISOString()
        : null;

      const { data: listing, error } = await supabase.from("listings").insert({
        seller_id: user.id,
        title: draft.title.trim(),
        description: draft.description.trim(),
        category: draft.category,
        condition: draft.condition,
        tags: draft.tags,
        listing_type: listingType,
        status: "pending_review",
        price_cents: listingType === "auction" ? null : draft.price_recommended_cents,
        starting_bid_cents: listingType === "auction" ? draft.price_recommended_cents : null,
        auction_ends_at: auctionEnd,
        auction_duration_days: listingType === "auction" ? auctionDays : null,
        zip: profile.zip,
        city: profile.city,
        state: profile.state,
        ai_review_score: draft.confidence,
        ai_review_notes: draft.flags.join(", "),
        ai_assist_enabled: aiEnabled && mode !== "manual",
      }).select().single();

      if (error) throw error;

      // attach photos
      const uploaded = photos.filter((p) => p.uploadedUrl);
      if (uploaded.length > 0 && listing) {
        await supabase.from("listing_images").insert(
          uploaded.map((p, i) => ({ listing_id: listing.id, url: p.uploadedUrl!, position: i })),
        );
      }

      toast({ title: "Listing submitted!", description: "We'll review and publish within minutes." });
      navigate("/account");
    } catch (e) {
      console.error(e);
      const msg = e instanceof Error ? e.message : "Something went wrong";
      toast({ title: "Couldn't publish", description: msg, variant: "destructive" });
    } finally {
      setPublishing(false);
    }
  };

  // ----- render -----
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-24 pb-28 md:pb-12">
        <div className="container max-w-3xl">
          {step !== "pick" && (
            <button
              onClick={() => { if (step === "review") { setStep("input"); } else { setStep("pick"); setMode(null); } }}
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4"
            >
              <ArrowLeft className="h-4 w-4" /> Back
            </button>
          )}

          {/* STEP 1 — pick mode */}
          {step === "pick" && (
            <>
              <div className="text-center mb-8">
                <div className="inline-flex items-center gap-2 bg-primary/15 border border-primary/30 rounded-full px-3 py-1 mb-4">
                  <Sparkles className="h-3.5 w-3.5 text-primary-glow" />
                  <span className="text-xs font-medium text-primary-glow">Powered by AI</span>
                </div>
                <h1 className="font-display text-3xl sm:text-5xl font-bold mb-2">List something. <span className="text-gradient-brand">Fast.</span></h1>
                <p className="text-muted-foreground">Pick how you want to start.</p>
              </div>

              {/* Per-listing AI toggle */}
              <div className="glass rounded-2xl p-4 mb-5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`h-9 w-9 rounded-xl grid place-items-center shrink-0 ${aiEnabled ? "bg-yellow-400/15 text-yellow-400" : "bg-muted text-muted-foreground"}`}>
                    <Sparkles className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-medium text-sm">AI assist for this listing</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {aiEnabled ? "AI will help write title, price & description." : "You'll write everything yourself."}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setAiEnabled((v) => !v)}
                  role="switch"
                  aria-checked={aiEnabled}
                  className={`relative h-6 w-11 rounded-full transition shrink-0 ${aiEnabled ? "bg-yellow-400" : "bg-muted"}`}
                >
                  <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-background shadow transition ${aiEnabled ? "left-[1.4rem]" : "left-0.5"}`} />
                </button>
              </div>

              <div className="grid sm:grid-cols-3 gap-4">
                <ModeCard
                  icon={Camera}
                  title="📸 AI Photo"
                  desc="Snap photos. AI writes the listing."
                  recommended
                  disabled={!aiEnabled}
                  onClick={() => { setMode("photo"); setStep("input"); }}
                />
                <ModeCard
                  icon={Type}
                  title="✍️ AI Text"
                  desc="Describe it. AI polishes it."
                  disabled={!aiEnabled}
                  onClick={() => { setMode("text"); setStep("input"); }}
                />
                <ModeCard
                  icon={Wrench}
                  title="🛠️ Manual"
                  desc="Type it all yourself."
                  onClick={() => { setMode("manual"); setStep("input"); }}
                />
              </div>
            </>
          )}

          {/* STEP 2 — input */}
          {step === "input" && mode === "photo" && (
            <div className="glass rounded-2xl p-6 space-y-5">
              <div>
                <h2 className="font-display text-2xl font-bold mb-1">Add photos</h2>
                <p className="text-sm text-muted-foreground">Up to 8. First photo is the cover. Bright, in-focus, multiple angles = higher price.</p>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {photos.map((p, i) => (
                  <div key={i} className="relative aspect-square rounded-xl overflow-hidden glass-strong">
                    <img src={p.preview} alt={`Photo ${i+1}`} className="h-full w-full object-cover" />
                    <button onClick={() => removePhoto(i)} aria-label="Remove" className="absolute top-1 right-1 h-7 w-7 rounded-full bg-background/80 grid place-items-center hover:bg-destructive hover:text-destructive-foreground">
                      <X className="h-3.5 w-3.5" />
                    </button>
                    {i === 0 && <Badge className="absolute bottom-1 left-1 text-[10px]">Cover</Badge>}
                  </div>
                ))}
                {photos.length < 8 && (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="aspect-square rounded-xl glass border-2 border-dashed border-border hover:border-primary grid place-items-center gap-1 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <Upload className="h-5 w-5" />
                    <span className="text-xs">Add</span>
                  </button>
                )}
                <input ref={fileInputRef} type="file" accept="image/*" multiple capture="environment" className="hidden" onChange={handlePhotoSelect} />
              </div>

              <Button onClick={generate} disabled={generating || photos.length === 0} className="w-full h-12 rounded-xl bg-gradient-primary shadow-glow font-medium">
                {generating ? <><Loader2 className="h-4 w-4 animate-spin" /> AI is writing your listing…</> : <><Sparkles className="h-4 w-4" /> Generate listing</>}
              </Button>
            </div>
          )}

          {step === "input" && mode === "text" && (
            <div className="glass rounded-2xl p-6 space-y-5">
              <div>
                <h2 className="font-display text-2xl font-bold mb-1">Describe your item</h2>
                <p className="text-sm text-muted-foreground">A sentence or two is enough. AI will write the title, price, and full description.</p>
              </div>
              <Textarea
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                placeholder="e.g. Nike Air Max 90 size 10, white/grey, worn maybe 5 times, original box"
                rows={5}
                maxLength={2000}
                className="resize-none"
              />
              <p className="text-xs text-muted-foreground text-right">{textInput.length}/2000</p>
              <Button onClick={generate} disabled={generating || textInput.trim().length < 10} className="w-full h-12 rounded-xl bg-gradient-primary shadow-glow font-medium">
                {generating ? <><Loader2 className="h-4 w-4 animate-spin" /> Polishing…</> : <><Sparkles className="h-4 w-4" /> Generate listing</>}
              </Button>
            </div>
          )}

          {step === "input" && mode === "manual" && (
            <div className="glass rounded-2xl p-6 space-y-5">
              <div>
                <h2 className="font-display text-2xl font-bold mb-1">Manual mode</h2>
                <p className="text-sm text-muted-foreground">Add photos (optional), then fill in everything yourself on the next screen.</p>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {photos.map((p, i) => (
                  <div key={i} className="relative aspect-square rounded-xl overflow-hidden glass-strong">
                    <img src={p.preview} alt={`Photo ${i+1}`} className="h-full w-full object-cover" />
                    <button onClick={() => removePhoto(i)} aria-label="Remove" className="absolute top-1 right-1 h-7 w-7 rounded-full bg-background/80 grid place-items-center">
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
                {photos.length < 8 && (
                  <button onClick={() => fileInputRef.current?.click()} className="aspect-square rounded-xl glass border-2 border-dashed border-border grid place-items-center text-muted-foreground">
                    <Upload className="h-5 w-5" />
                  </button>
                )}
                <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoSelect} />
              </div>
              <Button onClick={startManual} className="w-full h-12 rounded-xl bg-gradient-primary shadow-glow font-medium">
                Continue <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          )}

          {/* STEP 3 — review/edit/publish */}
          {step === "review" && (
            <div className="space-y-5">
              {mode !== "manual" && (
                <div className="glass rounded-2xl p-4 flex items-center gap-3 text-sm">
                  <CheckCircle2 className="h-5 w-5 text-success shrink-0" />
                  <div className="flex-1">
                    AI confidence: <span className="font-semibold">{Math.round(draft.confidence * 100)}%</span>. Edit anything before publishing.
                  </div>
                </div>
              )}

              <div className="glass rounded-2xl p-6 space-y-4">
                <Field label="Title">
                  <Input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} maxLength={80} placeholder="Eye-catching title" />
                </Field>

                <Field label="Description">
                  <Textarea value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} rows={6} placeholder="Condition, features, included items, flaws…" />
                </Field>

                <div className="grid grid-cols-2 gap-3">
                  <Field label="Category">
                    <Select value={draft.category} onValueChange={(v) => setDraft({ ...draft, category: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {["electronics","clothing","shoes","accessories","home","sports","collectibles","toys","books","tools","auto","other"].map((c) => (
                          <SelectItem key={c} value={c}>{c}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Condition">
                    <Select value={draft.condition} onValueChange={(v: any) => setDraft({ ...draft, condition: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="like_new">Like new</SelectItem>
                        <SelectItem value="good">Good</SelectItem>
                        <SelectItem value="fair">Fair</SelectItem>
                        <SelectItem value="poor">Poor</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                </div>

                <Field label="Sale type">
                  <div className="grid grid-cols-3 gap-2">
                    {(["buy_now","auction","local"] as const).map((t) => (
                      <button
                        key={t}
                        onClick={() => setListingType(t)}
                        className={`rounded-xl px-3 py-2.5 text-sm font-medium border transition-colors ${listingType === t ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:text-foreground"}`}
                      >
                        {t === "buy_now" ? "Buy Now" : t === "auction" ? "Auction" : "Local"}
                      </button>
                    ))}
                  </div>
                </Field>

                {listingType === "auction" && (
                  <Field label="Auction length">
                    <Select value={String(auctionDays)} onValueChange={(v) => setAuctionDays(Number(v))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {[1,3,5,7,10].map((d) => <SelectItem key={d} value={String(d)}>{d} day{d>1?"s":""}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </Field>
                )}

                <Field label={listingType === "auction" ? "Starting bid (USD)" : "Price (USD)"}>
                  <div className="flex items-center gap-3">
                    <Input
                      type="number"
                      step="0.01"
                      min="1"
                      value={(draft.price_recommended_cents / 100).toFixed(2)}
                      onChange={(e) => setDraft({ ...draft, price_recommended_cents: Math.round(Number(e.target.value) * 100) })}
                    />
                    {draft.price_min_cents > 0 && (
                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                        AI range: ${(draft.price_min_cents/100).toFixed(0)}–${(draft.price_max_cents/100).toFixed(0)}
                      </span>
                    )}
                  </div>
                </Field>

                {draft.tags.length > 0 && (
                  <Field label="Tags">
                    <div className="flex flex-wrap gap-1.5">
                      {draft.tags.map((t) => <Badge key={t} variant="outline">{t}</Badge>)}
                    </div>
                  </Field>
                )}
              </div>

              <Button onClick={publish} disabled={publishing} className="w-full h-12 rounded-xl bg-gradient-primary shadow-glow font-medium">
                {publishing ? <><Loader2 className="h-4 w-4 animate-spin" /> Publishing…</> : <>Publish listing <ArrowRight className="h-4 w-4" /></>}
              </Button>
              <p className="text-[11px] text-muted-foreground text-center">Listings go through a quick AI safety review (usually under a minute).</p>
            </div>
          )}
        </div>
      </main>
      <BottomTabBar />
    </div>
  );
};

const ModeCard = ({ icon: Icon, title, desc, recommended, disabled, onClick }: { icon: typeof Camera; title: string; desc: string; recommended?: boolean; disabled?: boolean; onClick: () => void }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className="text-left glass hover:glass-strong rounded-2xl p-5 transition-all hover:scale-[1.02] hover:shadow-glow group relative disabled:opacity-40 disabled:hover:scale-100 disabled:cursor-not-allowed"
  >
    {recommended && !disabled && <Badge className="absolute -top-2 right-3 bg-gradient-primary text-primary-foreground border-0 text-[10px]">Recommended</Badge>}
    <div className="h-10 w-10 rounded-xl bg-gradient-primary grid place-items-center mb-3 shadow-glow">
      <Icon className="h-5 w-5 text-primary-foreground" />
    </div>
    <div className="font-display font-bold text-lg mb-1">{title}</div>
    <div className="text-sm text-muted-foreground">{desc}</div>
  </button>
);

const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <div className="space-y-1.5">
    <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
    {children}
  </div>
);

export default Sell;
