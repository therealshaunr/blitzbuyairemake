import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

type Profile = {
  id: string;
  display_name: string | null;
  full_name: string | null;
  account_status: "active" | "restricted" | "locked" | "disabled" | "banned";
  nextgen_status: string;
  unpaid_fee_balance_cents: number;
  created_at: string;
  city: string | null;
  state: string | null;
};

const statusColor: Record<string, string> = {
  active: "bg-success/15 text-success border-success/30",
  restricted: "bg-warning/15 text-warning border-warning/30",
  locked: "bg-warning/15 text-warning border-warning/30",
  disabled: "bg-destructive/15 text-destructive border-destructive/30",
  banned: "bg-destructive/15 text-destructive border-destructive/30",
};

const AdminUsers = () => {
  const { user: me } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [search, setSearch] = useState("");
  const [target, setTarget] = useState<Profile | null>(null);
  const [action, setAction] = useState<"restricted" | "locked" | "disabled" | "banned" | "active">("restricted");
  const [reason, setReason] = useState("");
  const { toast } = useToast();

  const load = async () => {
    let q = supabase.from("profiles").select("id,display_name,full_name,account_status,nextgen_status,unpaid_fee_balance_cents,created_at,city,state").order("created_at", { ascending: false }).limit(100);
    if (search.trim()) {
      q = q.or(`display_name.ilike.%${search}%,full_name.ilike.%${search}%`);
    }
    const { data } = await q;
    setUsers((data ?? []) as Profile[]);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const applyAction = async () => {
    if (!target || !reason.trim() || !me) return;
    const { error } = await supabase.from("profiles").update({
      account_status: action,
      restriction_reason: reason,
    }).eq("id", target.id);
    if (error) { toast({ title: "Failed", description: error.message, variant: "destructive" }); return; }
    await supabase.from("account_actions").insert({
      user_id: target.id, performed_by: me.id, action, reason,
    });
    await supabase.from("audit_log").insert({
      actor_id: me.id, action: `user.${action}`, target_type: "user", target_id: target.id, details: { reason },
    });
    toast({ title: `User marked ${action}` });
    setTarget(null); setReason(""); setAction("restricted");
    load();
  };

  return (
    <AdminLayout title="Users">
      <div className="flex gap-3 mb-4">
        <Input placeholder="Search by name…" value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load()} />
        <Button onClick={load} className="rounded-xl">Search</Button>
      </div>

      <div className="glass rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-card/60 text-xs uppercase text-muted-foreground">
              <tr>
                <th className="text-left p-3">Name</th>
                <th className="text-left p-3">Location</th>
                <th className="text-left p-3">Status</th>
                <th className="text-left p-3">Tier</th>
                <th className="text-left p-3">Fees owed</th>
                <th className="text-left p-3">Joined</th>
                <th className="text-right p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-t border-border hover:bg-secondary/30">
                  <td className="p-3">
                    <div className="font-medium">{u.display_name || "—"}</div>
                    <div className="text-xs text-muted-foreground">{u.full_name}</div>
                  </td>
                  <td className="p-3 text-xs text-muted-foreground">{[u.city, u.state].filter(Boolean).join(", ") || "—"}</td>
                  <td className="p-3"><Badge className={statusColor[u.account_status]}>{u.account_status}</Badge></td>
                  <td className="p-3 text-xs">{u.nextgen_status === "active" ? <span className="text-gradient-brand font-semibold">NextGen</span> : "Free"}</td>
                  <td className="p-3 text-xs">${(u.unpaid_fee_balance_cents / 100).toFixed(2)}</td>
                  <td className="p-3 text-xs text-muted-foreground">{new Date(u.created_at).toLocaleDateString()}</td>
                  <td className="p-3 text-right">
                    <Button size="sm" variant="outline" onClick={() => setTarget(u)}>Manage</Button>
                  </td>
                </tr>
              ))}
              {users.length === 0 && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No users.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      <Dialog open={!!target} onOpenChange={(o) => !o && setTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Manage {target?.display_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Account action</Label>
              <Select value={action} onValueChange={(v: any) => setAction(v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Reinstate (active)</SelectItem>
                  <SelectItem value="restricted">Restrict — can't sell or bid</SelectItem>
                  <SelectItem value="locked">Lock — read-only</SelectItem>
                  <SelectItem value="disabled">Disable — can't log in</SelectItem>
                  <SelectItem value="banned">Ban — permanent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Reason (visible to user, kept in audit log)</Label>
              <Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Required" rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTarget(null)}>Cancel</Button>
            <Button onClick={applyAction} disabled={!reason.trim()} className="bg-destructive text-destructive-foreground">Apply</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
};

export default AdminUsers;
