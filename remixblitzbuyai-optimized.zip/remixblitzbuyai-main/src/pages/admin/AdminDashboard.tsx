import { useEffect, useState } from "react";
import { Users, ListChecks, Gavel, Flag, AlertTriangle, Sparkles } from "lucide-react";
import AdminLayout from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";

const AdminDashboard = () => {
  const [k, setK] = useState({
    users: 0, pendingListings: 0, activeAuctions: 0, openReports: 0, criticalFlags: 0, nextgen: 0,
  });

  useEffect(() => {
    (async () => {
      const [u, pl, aa, or_, cf, ng] = await Promise.all([
        supabase.from("profiles").select("*", { count: "exact", head: true }),
        supabase.from("listings").select("*", { count: "exact", head: true }).eq("status", "pending_review"),
        supabase.from("listings").select("*", { count: "exact", head: true }).eq("listing_type", "auction").eq("status", "active"),
        supabase.from("reports").select("*", { count: "exact", head: true }).eq("status", "open"),
        supabase.from("bid_anomaly_flags").select("*", { count: "exact", head: true }).eq("severity", "critical").eq("resolved", false),
        supabase.from("profiles").select("*", { count: "exact", head: true }).eq("nextgen_status", "active"),
      ]);
      setK({
        users: u.count ?? 0,
        pendingListings: pl.count ?? 0,
        activeAuctions: aa.count ?? 0,
        openReports: or_.count ?? 0,
        criticalFlags: cf.count ?? 0,
        nextgen: ng.count ?? 0,
      });
    })();
  }, []);

  return (
    <AdminLayout title="Dashboard">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
        <Kpi icon={Users} label="Total users" value={k.users} />
        <Kpi icon={ListChecks} label="Pending review" value={k.pendingListings} highlight={k.pendingListings > 0} />
        <Kpi icon={Gavel} label="Live auctions" value={k.activeAuctions} />
        <Kpi icon={Flag} label="Open reports" value={k.openReports} highlight={k.openReports > 0} />
        <Kpi icon={AlertTriangle} label="Critical flags" value={k.criticalFlags} alert={k.criticalFlags > 0} />
        <Kpi icon={Sparkles} label="NextGen members" value={k.nextgen} />
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="font-display font-bold text-lg mb-2">Operating principles</h3>
        <ul className="text-sm text-muted-foreground space-y-1.5 list-disc pl-5">
          <li>Approve listings within 24 hours.</li>
          <li>Critical bid-anomaly flags auto-pause auctions — clear or void within 1 hour.</li>
          <li>Always document the reason on user actions (restrict / lock / disable / ban).</li>
          <li>Treat reporters and reportees with equal respect during investigation.</li>
        </ul>
      </div>
    </AdminLayout>
  );
};

const Kpi = ({ icon: Icon, label, value, highlight, alert }: any) => (
  <div className={`glass rounded-2xl p-4 ${alert ? "border-destructive/50" : highlight ? "border-warning/50" : ""}`}>
    <Icon className={`h-5 w-5 mb-2 ${alert ? "text-destructive" : highlight ? "text-warning" : "text-muted-foreground"}`} />
    <div className="text-xs text-muted-foreground">{label}</div>
    <div className={`font-display font-bold text-2xl ${alert ? "text-destructive" : highlight ? "text-warning" : "text-gradient"}`}>{value}</div>
  </div>
);

export default AdminDashboard;
