import { ReactNode } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, Users, ListChecks, Gavel, Flag, Headphones, UserPlus, BarChart3, FileText, Activity, ArrowLeft, Sparkles,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";

const nav = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/admin/users", label: "Users", icon: Users },
  { to: "/admin/listings", label: "Listings Review", icon: ListChecks },
  { to: "/admin/auctions", label: "Auctions Monitor", icon: Gavel },
  { to: "/admin/reports", label: "Reports", icon: Flag },
  { to: "/admin/support", label: "Support Tickets", icon: Headphones },
  { to: "/admin/team", label: "Team", icon: UserPlus, adminOnly: true },
  { to: "/admin/exports", label: "Reports Generator", icon: BarChart3 },
  { to: "/admin/legal", label: "Legal Docs", icon: FileText, adminOnly: true },
  { to: "/admin/audit", label: "Audit Log", icon: Activity },
];

const AdminLayout = ({ children, title }: { children: ReactNode; title: string }) => {
  const { user, isStaff, isAdmin, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && (!user || !isStaff)) navigate("/");
  }, [user, isStaff, loading, navigate]);

  if (loading || !isStaff) {
    return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;
  }

  return (
    <div className="min-h-screen flex">
      <aside className="hidden md:flex flex-col w-64 shrink-0 border-r border-border bg-card/40 backdrop-blur-xl">
        <div className="p-5 border-b border-border">
          <NavLink to="/" className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-xl bg-gradient-primary grid place-items-center shadow-glow">
              <Sparkles className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <div className="font-display font-bold text-sm">BlitzBuy.AI</div>
              <div className="text-[10px] uppercase tracking-wider text-accent font-semibold">Staff Portal</div>
            </div>
          </NavLink>
        </div>
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {nav.filter((i) => !i.adminOnly || isAdmin).map((i) => (
            <NavLink
              key={i.to}
              to={i.to}
              end={i.end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                  isActive ? "bg-primary/15 text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-secondary/40"
                }`
              }
            >
              <i.icon className="h-4 w-4" />
              {i.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t border-border">
          <NavLink to="/account" className="flex items-center gap-2 px-3 py-2 text-xs text-muted-foreground hover:text-foreground rounded-lg">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to your account
          </NavLink>
        </div>
      </aside>

      <main className="flex-1 min-w-0">
        <header className="sticky top-0 z-20 border-b border-border bg-background/80 backdrop-blur-xl">
          <div className="px-4 sm:px-8 h-14 flex items-center justify-between gap-3">
            <h1 className="font-display font-bold text-base sm:text-lg truncate">{title}</h1>
            <div className="text-xs text-muted-foreground hidden sm:block">{user?.email}</div>
          </div>
          {/* mobile nav scroller */}
          <div className="md:hidden border-t border-border overflow-x-auto">
            <div className="flex gap-1 p-2 min-w-max">
              {nav.filter((i) => !i.adminOnly || isAdmin).map((i) => (
                <NavLink
                  key={i.to}
                  to={i.to}
                  end={i.end}
                  className={({ isActive }) =>
                    `flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs whitespace-nowrap ${
                      isActive ? "bg-primary/15 text-foreground" : "text-muted-foreground"
                    }`
                  }
                >
                  <i.icon className="h-3.5 w-3.5" />
                  {i.label}
                </NavLink>
              ))}
            </div>
          </div>
        </header>
        <div className="p-4 sm:p-8">{children}</div>
      </main>
    </div>
  );
};

export default AdminLayout;
