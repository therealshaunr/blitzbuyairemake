import { lazy, Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import EmailVerifyBanner from "@/components/EmailVerifyBanner";
import AIBanner from "@/components/AIBanner";
import AIPromoModal from "@/components/AIPromoModal";

// Critical-path pages loaded eagerly (user sees these first)
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";

// Everything else lazy-loaded (only downloaded when navigated to)
const Account = lazy(() => import("./pages/Account"));
const Sell = lazy(() => import("./pages/Sell"));
const Browse = lazy(() => import("./pages/Browse"));
const ListingDetail = lazy(() => import("./pages/ListingDetail"));
const Messages = lazy(() => import("./pages/Messages"));
const MessageThread = lazy(() => import("./pages/MessageThread"));
const Subscription = lazy(() => import("./pages/Subscription"));
const Demo = lazy(() => import("./pages/Demo"));
const LegalDoc = lazy(() => import("./pages/legal/LegalDoc"));

// Admin pages (heavy, rarely loaded by most users)
const AdminDashboard = lazy(() => import("./pages/admin/AdminDashboard"));
const AdminUsers = lazy(() => import("./pages/admin/AdminUsers"));
const AdminListings = lazy(() => import("./pages/admin/AdminListings"));
const AdminAuctions = lazy(() => import("./pages/admin/AdminAuctions"));
const AdminReports = lazy(() => import("./pages/admin/AdminReports"));
const AdminSupport = lazy(() => import("./pages/admin/AdminSupport"));
const AdminTeam = lazy(() => import("./pages/admin/AdminTeam"));
const AdminAudit = lazy(() => import("./pages/admin/AdminAudit"));
const AdminLegal = lazy(() => import("./pages/admin/AdminLegal"));
const AdminExports = lazy(() => import("./pages/admin/AdminExports"));
const AcceptInvite = lazy(() => import("./pages/admin/AcceptInvite"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 2, // 2 min — avoid refetching on every mount
      retry: 1,
    },
  },
});

const PageLoader = () => (
  <div className="min-h-screen grid place-items-center">
    <div className="text-center">
      <div className="h-8 w-8 mx-auto border-2 border-yellow-400 border-t-transparent rounded-full animate-spin" />
      <p className="text-sm text-muted-foreground mt-3">Loading...</p>
    </div>
  </div>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <AIBanner />
          <EmailVerifyBanner />
          <AIPromoModal />
          <Suspense fallback={<PageLoader />}>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/demo" element={<Demo />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/account" element={<Account />} />
              <Route path="/sell" element={<Sell />} />
              <Route path="/browse" element={<Browse />} />
              <Route path="/l/:id" element={<ListingDetail />} />
              <Route path="/messages" element={<Messages />} />
              <Route path="/messages/:id" element={<MessageThread />} />
              <Route path="/subscription" element={<Subscription />} />
              <Route path="/legal/:slug" element={<LegalDoc />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/users" element={<AdminUsers />} />
              <Route path="/admin/listings" element={<AdminListings />} />
              <Route path="/admin/auctions" element={<AdminAuctions />} />
              <Route path="/admin/reports" element={<AdminReports />} />
              <Route path="/admin/support" element={<AdminSupport />} />
              <Route path="/admin/team" element={<AdminTeam />} />
              <Route path="/admin/exports" element={<AdminExports />} />
              <Route path="/admin/legal" element={<AdminLegal />} />
              <Route path="/admin/audit" element={<AdminAudit />} />
              <Route path="/admin/accept" element={<AcceptInvite />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
