import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Lock, Send, Sparkles, CheckCircle2, CreditCard } from "lucide-react";
import Navbar from "@/components/Navbar";
import BottomTabBar from "@/components/BottomTabBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

type Conv = {
  id: string;
  listing_id: string | null;
  buyer_id: string;
  seller_id: string;
  contact_unlocked: boolean;
  buyer_paid_unlock: boolean;
  seller_paid_unlock: boolean;
};
type Msg = { id: string; sender_id: string; body: string; created_at: string; is_system: boolean };

const MessageThread = () => {
  const { id } = useParams();
  const { user, loading } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [conv, setConv] = useState<Conv | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [listingTitle, setListingTitle] = useState<string>("");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (!loading && !user) navigate("/auth"); }, [user, loading, navigate]);

  useEffect(() => {
    if (!id || !user) return;
    let alive = true;
    (async () => {
      const { data: c } = await supabase.from("conversations").select("*").eq("id", id).maybeSingle();
      if (!alive) return;
      setConv(c as Conv);
      if (c?.listing_id) {
        const { data: l } = await supabase.from("listings").select("title").eq("id", c.listing_id).maybeSingle();
        if (alive) setListingTitle((l as any)?.title ?? "");
      }
      const { data: m } = await supabase.from("messages").select("*").eq("conversation_id", id).order("created_at");
      if (alive) setMsgs((m as Msg[]) ?? []);
    })();

    const ch = supabase
      .channel(`thread-${id}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `conversation_id=eq.${id}` }, (payload) => {
        setMsgs((prev) => [...prev, payload.new as Msg]);
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "conversations", filter: `id=eq.${id}` }, (payload) => {
        setConv((prev) => (prev ? { ...prev, ...(payload.new as any) } : prev));
      })
      .subscribe();

    return () => { alive = false; supabase.removeChannel(ch); };
  }, [id, user]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs.length]);

  const send = async () => {
    if (!conv || !user || !body.trim()) return;
    setSending(true);
    const { error } = await supabase.from("messages").insert({
      conversation_id: conv.id,
      sender_id: user.id,
      body: body.trim(),
    });
    if (error) {
      toast({ title: "Couldn't send", description: error.message, variant: "destructive" });
    } else {
      setBody("");
      await supabase.from("conversations").update({ last_message_at: new Date().toISOString() }).eq("id", conv.id);
    }
    setSending(false);
  };

  // Demo: simulate paying unlock fee. Real impl wires to payment provider.
  const payUnlock = async () => {
    if (!conv || !user) return;
    const isBuyer = conv.buyer_id === user.id;
    const patch: any = {};
    if (isBuyer) patch.buyer_paid_unlock = true; else patch.seller_paid_unlock = true;
    const otherPaid = isBuyer ? conv.seller_paid_unlock : conv.buyer_paid_unlock;
    if (otherPaid) patch.contact_unlocked = true;
    const { error } = await supabase.from("conversations").update(patch).eq("id", conv.id);
    if (error) { toast({ title: "Payment failed", description: error.message, variant: "destructive" }); return; }
    toast({ title: "Fee paid", description: otherPaid ? "Chat unlocked!" : "Waiting on the other party to pay their 5%." });
  };

  if (!user || !conv) return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;

  const role = conv.buyer_id === user.id ? "buyer" : "seller";
  const myPaid = role === "buyer" ? conv.buyer_paid_unlock : conv.seller_paid_unlock;
  const otherPaid = role === "buyer" ? conv.seller_paid_unlock : conv.buyer_paid_unlock;
  const unlocked = conv.contact_unlocked;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="pt-24 pb-28 md:pb-12 flex-1">
        <div className="container max-w-3xl flex flex-col h-[calc(100vh-9rem)]">
          <div className="flex items-center justify-between mb-3">
            <Link to="/messages" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-4 w-4" /> All messages
            </Link>
            {unlocked
              ? <Badge className="bg-success/20 text-success border-success/30"><CheckCircle2 className="h-3 w-3 mr-1" />Unlocked</Badge>
              : <Badge variant="outline"><Lock className="h-3 w-3 mr-1" />Locked</Badge>}
          </div>

          {conv.listing_id && (
            <Link to={`/l/${conv.listing_id}`} className="glass rounded-2xl p-3 mb-3 flex items-center gap-3 hover:ring-1 hover:ring-yellow-400/40 transition">
              <div className="h-10 w-10 rounded-xl bg-gradient-primary grid place-items-center"><Sparkles className="h-5 w-5 text-primary-foreground" /></div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-muted-foreground">Listing</div>
                <div className="font-medium truncate">{listingTitle || "View listing"}</div>
              </div>
            </Link>
          )}

          <div className="flex-1 glass rounded-2xl p-4 overflow-y-auto space-y-2">
            {msgs.length === 0 && (
              <div className="text-center text-sm text-muted-foreground py-10">
                No messages yet — say hi once chat is unlocked.
              </div>
            )}
            {msgs.map((m) => {
              const mine = m.sender_id === user.id;
              return (
                <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[75%] rounded-2xl px-4 py-2 text-sm ${mine ? "bg-yellow-400 text-black" : "glass-strong"}`}>
                    {m.body}
                    <div className={`text-[10px] mt-1 ${mine ? "text-black/60" : "text-muted-foreground"}`}>
                      {new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={endRef} />
          </div>

          {/* Composer / locked overlay */}
          {unlocked ? (
            <div className="mt-3 flex gap-2">
              <Input
                value={body}
                onChange={(e) => setBody(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
                placeholder="Type a message…"
                className="rounded-xl"
              />
              <Button onClick={send} disabled={sending || !body.trim()} className="rounded-xl bg-gradient-primary shadow-glow">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div className="mt-3 glass-strong rounded-2xl p-5 border-yellow-400/30">
              <div className="flex items-start gap-3">
                <Lock className="h-5 w-5 text-yellow-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="font-display font-semibold mb-1">Chat is locked until both fees clear</div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Each party pays their 5% — that's how BlitzBuy.AI keeps lowballers and scammers out and protects real deals.
                    Address sharing & meetup details unlock at the same time.
                  </p>
                  <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                    <div className={`rounded-lg p-2 border ${role === "buyer" ? (myPaid ? "border-success/40 bg-success/10" : "border-yellow-400/40") : (otherPaid ? "border-success/40 bg-success/10" : "border-border")}`}>
                      Buyer fee {role === "buyer" ? (myPaid ? "✓ paid" : "— due") : (otherPaid ? "✓ paid" : "— pending")}
                    </div>
                    <div className={`rounded-lg p-2 border ${role === "seller" ? (myPaid ? "border-success/40 bg-success/10" : "border-yellow-400/40") : (otherPaid ? "border-success/40 bg-success/10" : "border-border")}`}>
                      Seller fee {role === "seller" ? (myPaid ? "✓ paid" : "— due") : (otherPaid ? "✓ paid" : "— pending")}
                    </div>
                  </div>
                  {!myPaid ? (
                    <Button onClick={payUnlock} className="rounded-xl bg-gradient-primary shadow-glow">
                      <CreditCard className="h-4 w-4" /> Pay your 5% to unlock
                    </Button>
                  ) : (
                    <p className="text-xs text-muted-foreground">You're paid up. Waiting on the other party.</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      <BottomTabBar />
    </div>
  );
};

export default MessageThread;
