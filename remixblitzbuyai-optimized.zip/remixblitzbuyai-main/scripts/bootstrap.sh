#!/usr/bin/env bash
set -euo pipefail

# Bootstrap script for new developer machines (Linux/macOS).
# - Installs nvm + Node LTS (if missing)
# - Installs npm dependencies
# - Copies .env.example -> .env.local (if missing)

ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT_DIR"

echo "Bootstrapping BlitzBuyAI in $ROOT_DIR"

command_exists() { command -v "$1" >/dev/null 2>&1; }

if ! command_exists nvm; then
  echo "nvm not found. Installing nvm..."
  curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.6/install.sh | bash
  # shellcheck disable=SC1090
  export NVM_DIR="$HOME/.nvm"
  # shellcheck disable=SC1090
  [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
else
  echo "nvm found"
  # shellcheck disable=SC1090
  export NVM_DIR="$HOME/.nvm"
  [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
fi

echo "Installing Node LTS and setting as default..."
nvm install --lts
nvm use --lts

echo "Node: $(node -v)  npm: $(npm -v)"

if [ -f package-lock.json ]; then
  echo "Installing dependencies with npm ci..."
  npm ci
else
  echo "Installing dependencies with npm install..."
  npm install
fi

if [ ! -f .env.local ]; then
  if [ -f .env.example ]; then
    echo "Creating .env.local from .env.example (please update values)"
    cp .env.example .env.local
    echo "Created .env.local — edit it and add your Supabase values before running the app."
  else
    echo "No .env.example found. Please create .env.local with VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY"
  fi
else
  echo ".env.local found — skipping creation."
fi

echo "Bootstrap complete. Next steps:"
echo "  1) Ensure .env.local has VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY"
echo "  2) (Optional) gh auth login  # authenticate GitHub CLI"
echo "  3) (Optional) vercel login    # if you use Vercel CLI"
echo "  4) Start dev server: npm run dev"

exit 0
