import AdminLayout from "./AdminLayout";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const reports = [
  { id: "users", label: "All users", table: "profiles", select: "id,display_name,full_name,city,state,zip,account_status,nextgen_status,unpaid_fee_balance_cents,created_at" },
  { id: "listings", label: "All listings", table: "listings", select: "id,seller_id,title,category,listing_type,status,price_cents,created_at,reviewed_at" },
  { id: "bids", label: "All bids", table: "bids", select: "id,listing_id,bidder_id,amount_cents,is_voided,created_at" },
  { id: "audit", label: "Audit log", table: "audit_log", select: "id,actor_id,action,target_type,target_id,created_at" },
  { id: "actions", label: "Account actions", table: "account_actions", select: "id,user_id,performed_by,action,reason,created_at" },
];

const toCsv = (rows: any[]) => {
  if (!rows.length) return "";
  const cols = Object.keys(rows[0]);
  const esc = (v: any) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [cols.join(","), ...rows.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\n");
};

const AdminExports = () => {
  const { toast } = useToast();
  const [busy, setBusy] = useState<string | null>(null);

  const run = async (r: typeof reports[number]) => {
    setBusy(r.id);
    try {
      const { data, error } = await supabase.from(r.table as any).select(r.select).limit(10000);
      if (error) throw error;
      const csv = toCsv(data ?? []);
      const blob = new Blob([csv], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `${r.id}-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
      URL.revokeObjectURL(url);
      toast({ title: `Exported ${data?.length ?? 0} rows` });
    } catch (e: any) {
      toast({ title: "Export failed", description: e.message, variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  return (
    <AdminLayout title="Reports Generator">
      <div className="grid sm:grid-cols-2 gap-3">
        {reports.map((r) => (
          <div key={r.id} className="glass rounded-2xl p-5 flex items-center justify-between">
            <div>
              <div className="font-display font-semibold">{r.label}</div>
              <div className="text-xs text-muted-foreground">CSV · up to 10k rows</div>
            </div>
            <Button onClick={() => run(r)} disabled={busy === r.id} className="rounded-xl">
              <Download className="h-4 w-4" />
              {busy === r.id ? "Exporting…" : "Export"}
            </Button>
          </div>
        ))}
      </div>
    </AdminLayout>
  );
};

export default AdminExports;
