
-- Replace overly broad SELECT policies on public buckets with file-specific reads.
-- We keep them publicly readable (for listing photos and avatars), but require the caller
-- to know the exact object path — they can't list the bucket contents.

DROP POLICY IF EXISTS "Listing photos public read" ON storage.objects;
DROP POLICY IF EXISTS "Avatars public read" ON storage.objects;

-- Allow public read on individual objects only when the bucket is public.
-- The CDN URL pattern still works for direct file fetches; bucket listing is blocked.
CREATE POLICY "Listing photos read by exact path"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'listing-photos' AND name IS NOT NULL);

CREATE POLICY "Avatars read by exact path"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'avatars' AND name IS NOT NULL);
