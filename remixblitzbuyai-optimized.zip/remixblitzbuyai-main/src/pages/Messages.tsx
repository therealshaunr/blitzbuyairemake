import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { MessageCircle, Lock, Sparkles } from "lucide-react";
import Navbar from "@/components/Navbar";
import BottomTabBar from "@/components/BottomTabBar";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

type Conv = {
  id: string;
  listing_id: string | null;
  buyer_id: string;
  seller_id: string;
  contact_unlocked: boolean;
  last_message_at: string | null;
  created_at: string;
};

const Messages = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [convs, setConvs] = useState<Conv[]>([]);
  const [titles, setTitles] = useState<Record<string, string>>({});

  useEffect(() => { if (!loading && !user) navigate("/auth"); }, [user, loading, navigate]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from("conversations")
        .select("*")
        .or(`buyer_id.eq.${user.id},seller_id.eq.${user.id}`)
        .order("last_message_at", { ascending: false, nullsFirst: false })
        .order("created_at", { ascending: false });
      const list = (data as Conv[]) ?? [];
      setConvs(list);
      const ids = list.map((c) => c.listing_id).filter(Boolean) as string[];
      if (ids.length) {
        const { data: ls } = await supabase.from("listings").select("id,title").in("id", ids);
        const map: Record<string, string> = {};
        (ls ?? []).forEach((l: any) => { map[l.id] = l.title; });
        setTitles(map);
      }
    })();
  }, [user]);

  if (!user) return null;

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-24 pb-28 md:pb-12">
        <div className="container max-w-3xl">
          <h1 className="font-display text-3xl font-bold mb-1">Messages</h1>
          <p className="text-sm text-muted-foreground mb-5">
            Chat unlocks once both buyer & seller fees are paid — keeps the marketplace clean.
          </p>

          {convs.length === 0 ? (
            <div className="glass rounded-2xl p-10 text-center">
              <MessageCircle className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
              <div className="font-display font-semibold">No conversations yet</div>
              <p className="text-sm text-muted-foreground mt-1">Start one from any listing.</p>
              <Link to="/browse" className="inline-block mt-4 text-sm text-yellow-400 hover:underline">Browse marketplace →</Link>
            </div>
          ) : (
            <div className="space-y-2">
              {convs.map((c) => (
                <Link key={c.id} to={`/messages/${c.id}`} className="glass rounded-2xl p-4 flex items-center gap-3 hover:ring-1 hover:ring-yellow-400/40 transition">
                  <div className="h-10 w-10 rounded-xl bg-gradient-primary grid place-items-center shrink-0">
                    <Sparkles className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{c.listing_id ? titles[c.listing_id] || "Listing" : "Direct message"}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {c.buyer_id === user.id ? "You're the buyer" : "You're the seller"}
                      {c.last_message_at && ` · ${new Date(c.last_message_at).toLocaleDateString()}`}
                    </div>
                  </div>
                  {c.contact_unlocked ? (
                    <Badge className="bg-success/20 text-success border-success/30">Unlocked</Badge>
                  ) : (
                    <Badge variant="outline" className="text-muted-foreground"><Lock className="h-3 w-3 mr-1" />Locked</Badge>
                  )}
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>
      <BottomTabBar />
    </div>
  );
};

export default Messages;
