// Generates listing fields (title, description, category, condition, price range, tags)
// from photos (multimodal) or text (text-only) using Lovable AI Gateway.
import { z } from "https://esm.sh/zod@3.23.8";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const BodySchema = z.object({
  mode: z.enum(["photo", "text"]),
  imageUrls: z.array(z.string().url()).max(8).optional(),
  text: z.string().max(2000).optional(),
  zip: z.string().max(20).optional(),
});

const TOOL = {
  type: "function",
  function: {
    name: "create_listing",
    description: "Return a complete marketplace listing extracted from the input.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string", description: "Searchable title, max 80 chars" },
        description: { type: "string", description: "2-3 paragraph description" },
        category: {
          type: "string",
          enum: ["electronics","clothing","shoes","accessories","home","sports","collectibles","toys","books","tools","auto","other"],
        },
        condition: {
          type: "string",
          enum: ["new","like_new","good","fair","poor"],
        },
        price_min_cents: { type: "integer", minimum: 100 },
        price_max_cents: { type: "integer", minimum: 100 },
        price_recommended_cents: { type: "integer", minimum: 100 },
        tags: { type: "array", items: { type: "string" }, maxItems: 6 },
        flags: {
          type: "array",
          items: { type: "string", enum: ["nsfw","weapon","counterfeit","recalled","prohibited","unclear","none"] },
          description: "Moderation flags. Use ['none'] if clean.",
        },
        confidence: { type: "number", minimum: 0, maximum: 1 },
      },
      required: ["title","description","category","condition","price_min_cents","price_max_cents","price_recommended_cents","tags","flags","confidence"],
      additionalProperties: false,
    },
  },
} as const;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY missing");

    const parsed = BodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return new Response(JSON.stringify({ error: parsed.error.flatten().fieldErrors }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const { mode, imageUrls, text, zip } = parsed.data;

    if (mode === "photo" && (!imageUrls || imageUrls.length === 0)) {
      return new Response(JSON.stringify({ error: "imageUrls required for photo mode" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (mode === "text" && !text?.trim()) {
      return new Response(JSON.stringify({ error: "text required for text mode" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const system = `You are BlitzBuy.AI's expert listing generator for a US peer-to-peer marketplace.
Generate a complete, honest, search-friendly listing.
Price in CENTS based on real US resale market value (eBay sold comps, OfferUp, Mercari).
Be conservative on condition — buyers value honesty.
Flag anything prohibited (weapons, drugs, recalled items, obvious counterfeits, NSFW).${zip ? ` Seller is in ZIP ${zip}.` : ""}
Always call the create_listing tool. Never respond with prose.`;

    const userContent: any[] = [];
    if (mode === "photo") {
      userContent.push({ type: "text", text: "Analyze these photos and create the listing." });
      for (const url of imageUrls!) {
        userContent.push({ type: "image_url", image_url: { url } });
      }
    } else {
      userContent.push({ type: "text", text: `Create a listing from this seller description:\n\n${text}` });
    }

    const model = mode === "photo" ? "google/gemini-2.5-pro" : "google/gemini-2.5-flash";

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: system },
          { role: "user", content: userContent },
        ],
        tools: [TOOL],
        tool_choice: { type: "function", function: { name: "create_listing" } },
      }),
    });

    if (aiRes.status === 429) {
      return new Response(JSON.stringify({ error: "Rate limit hit, try again in a moment." }), {
        status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (aiRes.status === 402) {
      return new Response(JSON.stringify({ error: "AI credits exhausted. Add funds in workspace settings." }), {
        status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!aiRes.ok) {
      const body = await aiRes.text();
      console.error("AI gateway error", aiRes.status, body);
      return new Response(JSON.stringify({ error: `AI gateway ${aiRes.status}` }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await aiRes.json();
    const call = data?.choices?.[0]?.message?.tool_calls?.[0];
    if (!call?.function?.arguments) {
      return new Response(JSON.stringify({ error: "No tool call returned" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const listing = JSON.parse(call.function.arguments);

    return new Response(JSON.stringify({ listing }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("generate-listing error", e);
    const msg = e instanceof Error ? e.message : "Unknown error";
    return new Response(JSON.stringify({ error: msg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
