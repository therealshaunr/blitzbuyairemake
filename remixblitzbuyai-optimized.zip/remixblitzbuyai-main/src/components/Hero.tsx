import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

const heroVariants = [
  {
    headline: "BlitzBuy.AI",
    subheadline: "Deals that hit fast. Offers that close faster.",
    buttonText: "Blitz a Listing"
  },
  {
    headline: "Buy. Sell. Blitz.",
    subheadline: "Instant offers • Lightning auctions • Real local pickups",
    buttonText: "Start Blitzing"
  },
  {
    headline: "The Fastest Marketplace",
    subheadline: "Snap it. Price it. Sell it in seconds.",
    buttonText: "Blitz a Listing"
  },
  {
    headline: "Lightning Deals Live",
    subheadline: "No waiting. Just blitz.",
    buttonText: "+ Sell Something Fast"
  },
  {
    headline: "Where Deals Get Done",
    subheadline: "Local pickups • Instant offers • Real people",
    buttonText: "Join the Blitz"
  }
];

export default function Hero() {
  const [current, setCurrent] = useState(0);
  const { user, loading } = useAuth();
  const isAuthed = !loading && !!user;

  useEffect(() => {
    const randomIndex = Math.floor(Math.random() * heroVariants.length);
    setCurrent(randomIndex);
  }, []);

  const variant = heroVariants[current];
  const ctaTo = isAuthed ? "/sell" : "/auth";
  const ctaLabel = isAuthed ? variant.buttonText : "Sign up — it's free";

  return (
    <div className="relative bg-zinc-950 pt-20 pb-16 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <div className="inline-flex items-center gap-2 bg-yellow-400/10 border border-yellow-400/30 rounded-full px-4 py-1.5 mb-6">
          <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
          <span className="text-sm font-semibold text-yellow-400 uppercase tracking-wider">The first AI-native marketplace</span>
        </div>

        <h1 className="text-6xl md:text-7xl font-bold tracking-tight text-white mb-6">
          {variant.headline}
        </h1>

        <p className="text-xl md:text-2xl text-zinc-400 max-w-3xl mx-auto mb-4">
          {variant.subheadline}
        </p>
        <p className="text-base md:text-lg text-yellow-400/90 max-w-2xl mx-auto mb-10 font-medium">
          ⚡ Snap a photo or just talk — our AI writes your listing in <span className="underline">seconds</span>, not hours.
        </p>

        <Link
          to={ctaTo}
          className="bg-yellow-400 hover:bg-yellow-300 transition-all text-black font-semibold text-lg px-10 py-4 rounded-2xl inline-flex items-center gap-3 mx-auto group"
        >
          {ctaLabel}
          <span className="group-hover:rotate-45 transition-transform">⚡</span>
        </Link>

        {!isAuthed && (
          <p className="text-zinc-500 text-sm mt-6">
            Free to join. Verified to sell. <Link to="/auth" className="text-yellow-400 hover:underline">Sign in</Link>
          </p>
        )}
        {isAuthed && (
          <p className="text-zinc-500 text-sm mt-6">
            Thousands of deals closing every hour
          </p>
        )}
      </div>

      <div className="absolute inset-0 bg-[radial-gradient(at_center,#eab30810_0%,transparent_70%)] pointer-events-none"></div>
    </div>
  );
}
