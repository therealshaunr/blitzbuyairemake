import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

const AdminReports = () => {
  const { user: me } = useAuth();
  const [items, setItems] = useState<any[]>([]);
  const { toast } = useToast();

  const load = async () => {
    const { data } = await supabase
      .from("reports")
      .select("*")
      .in("status", ["open", "investigating"])
      .order("created_at", { ascending: false })
      .limit(100);
    setItems(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const resolve = async (id: string, action_taken: string) => {
    if (!me) return;
    await supabase.from("reports").update({
      status: "resolved", action_taken, resolved_at: new Date().toISOString(), assigned_to: me.id,
    }).eq("id", id);
    await supabase.from("audit_log").insert({ actor_id: me.id, action: "report.resolved", target_type: "report", target_id: id, details: { action_taken } });
    toast({ title: "Report resolved" });
    load();
  };

  return (
    <AdminLayout title="Reports">
      <div className="space-y-3">
        {items.map((r) => (
          <div key={r.id} className="glass rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline">{r.category}</Badge>
              <Badge className="bg-warning/15 text-warning border-warning/40">{r.status}</Badge>
              <span className="text-xs text-muted-foreground ml-auto">{new Date(r.created_at).toLocaleString()}</span>
            </div>
            <p className="text-sm">{r.description || "—"}</p>
            <div className="text-xs text-muted-foreground mt-1">
              {r.reported_listing_id && `Listing: ${r.reported_listing_id.slice(0, 8)}…`}
              {r.reported_user_id && ` · User: ${r.reported_user_id.slice(0, 8)}…`}
            </div>
            <div className="flex gap-2 mt-3">
              <Button size="sm" variant="outline" onClick={() => resolve(r.id, "Dismissed - no violation")}>Dismiss</Button>
              <Button size="sm" className="bg-warning text-warning-foreground" onClick={() => resolve(r.id, "Warned user")}>Warn</Button>
              <Button size="sm" className="bg-destructive text-destructive-foreground" onClick={() => resolve(r.id, "Removed content / restricted user")}>Take action</Button>
            </div>
          </div>
        ))}
        {items.length === 0 && <div className="glass rounded-2xl p-10 text-center text-muted-foreground">No open reports.</div>}
      </div>
    </AdminLayout>
  );
};

export default AdminReports;
