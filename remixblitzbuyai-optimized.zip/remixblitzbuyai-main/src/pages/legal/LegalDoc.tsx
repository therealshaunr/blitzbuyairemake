import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import BottomTabBar from "@/components/BottomTabBar";

const titleMap: Record<string, string> = {
  terms: "terms_of_service",
  "seller-agreement": "seller_agreement",
  "community-guidelines": "community_guidelines",
  "prohibited-items": "prohibited_items",
  privacy: "privacy_policy",
};

const LegalDoc = () => {
  const { slug } = useParams<{ slug: string }>();
  const [doc, setDoc] = useState<{ title: string; body: string; version: string; effective_at: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const docType = titleMap[slug ?? ""];
    if (!docType) { setLoading(false); return; }
    (async () => {
      const { data } = await supabase
        .from("legal_agreements")
        .select("title, body, version, effective_at")
        .eq("doc_type", docType)
        .eq("is_current", true)
        .maybeSingle();
      setDoc(data);
      setLoading(false);
    })();
  }, [slug]);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-24 pb-28 md:pb-12">
        <div className="container max-w-3xl">
          <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Link>
          {loading ? (
            <div className="text-muted-foreground">Loading…</div>
          ) : !doc ? (
            <div className="glass rounded-2xl p-10 text-center">
              <FileText className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
              <p className="font-display font-semibold">Document not found</p>
            </div>
          ) : (
            <article className="glass-strong rounded-2xl p-6 sm:p-10">
              <div className="flex items-center gap-3 mb-2 text-xs text-muted-foreground">
                <FileText className="h-4 w-4" />
                <span>v{doc.version}</span>
                <span>·</span>
                <span>Effective {new Date(doc.effective_at).toLocaleDateString()}</span>
              </div>
              <h1 className="font-display text-3xl sm:text-4xl font-bold mb-6">{doc.title}</h1>
              <div className="prose prose-invert max-w-none whitespace-pre-wrap text-sm sm:text-base leading-relaxed text-muted-foreground">
                {doc.body}
              </div>
            </article>
          )}
        </div>
      </main>
      <BottomTabBar />
    </div>
  );
};

export default LegalDoc;
